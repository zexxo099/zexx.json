// config.js
module.exports = {
    BOT_TOKEN: "8490057313:AAFVVyUC65eddRakVDQpdF_pOC8MJchdZuM", 
    ADMIN_ID: 7422905746  
};