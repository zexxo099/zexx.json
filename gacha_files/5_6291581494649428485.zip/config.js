// config.js
module.exports = {
    BOT_TOKEN: "7705639693:AAE4N_fPcYXycyw7lyhXKU-r06VaXUJgoF0", 
    ADMIN_ID: 7581700518  
};