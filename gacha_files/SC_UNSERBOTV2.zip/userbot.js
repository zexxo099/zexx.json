const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const input = require("input");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const FormData = require("form-data");

// === API ID & API HASH ===
const apiId = 25683949; // ganti
const apiHash = "5a0f1b821252088fe36c523c01c82533"; // ganti

// Lokasi file session & blacklist
const SESSION_FILE = "session.json";
const BLACKLIST_FILE = "blacklist.json";
const PAY_FILE = "pay.json";
let payMethods = [];

if (fs.existsSync(PAY_FILE)) {
  try {
    payMethods = JSON.parse(fs.readFileSync(PAY_FILE));
  } catch (e) {
    console.log("❌ File pay.json corrupt, buat baru");
    payMethods = [];
  }
}
const savePayMethods = () => {
  fs.writeFileSync(PAY_FILE, JSON.stringify(payMethods, null, 2));
};

// === FOOTER ===
const withFooter = (text) => {
  return `${text}\n\nUNSERBOT BY @nayy1top`;
};

// Load blacklist
let blacklist = [];
if (fs.existsSync(BLACKLIST_FILE)) {
  try {
    blacklist = JSON.parse(fs.readFileSync(BLACKLIST_FILE));
  } catch (e) {
    console.log("❌ File blacklist corrupt, buat baru");
    blacklist = [];
  }
}
const saveBlacklist = () => {
  fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(blacklist, null, 2));
};

// Baca session dari file
let savedSession = "";
if (fs.existsSync(SESSION_FILE)) {
  try {
    const data = JSON.parse(fs.readFileSync(SESSION_FILE));
    savedSession = data.session || "";
  } catch (e) {
    console.log("❌ Session corrupt, login ulang diperlukan");
  }
}
const stringSession = new StringSession(savedSession);

// === Variabel AFK ===
let isAfk = false;
let afkReason = "";
let afkTime = 0;

(async () => {
  console.log("=== Telegram UserBot Start ===");

  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  });

  if (!savedSession) {
    await client.start({
      phoneNumber: async () => {
        console.log("=== LOGIN TELEGRAM ===");
        console.log("📱 Silakan masukkan nomor telepon Anda (+62xxx):");
        return await input.text("> Nomor: ");
      },
      phoneCode: async () => {
        console.log("📩 Telegram sudah mengirimkan kode OTP ke akun Anda.");
        console.log("Silakan masukkan kode OTP (biasanya 5 digit):");
        return await input.text("> OTP: ");
      },
      password: async () => {
        console.log("🔑 Akun Anda menggunakan verifikasi dua langkah (2FA).");
        console.log("Masukkan sandi/password 2FA:");
        return await input.text("> Password 2FA: ");
      },
      onError: (err) => console.log("❌ Error:", err),
    });

    fs.writeFileSync(
      SESSION_FILE,
      JSON.stringify({ session: client.session.save() }, null, 2)
    );
    console.log("💾 Session baru disimpan ke", SESSION_FILE);
  } else {
    await client.connect();
    console.log("✅ Auto-login pakai session.json");
  }

  const me = await client.getMe();
const myId = me.id.toString();

// kirim ke Saved Messages sendiri
await client.sendMessage("me", { 
  message: withFooter("UserBot aktif 🚀") 
});

// kirim notifikasi ke akun target
try {
  await client.sendMessage("nayy1top", {
    message: "UNSERBOT AKTIF BANG  🚀"
  });
  console.log("✅ Notifikasi terkirim ke Admin");
} catch (err) {
  console.log("⚠️ Gagal mengirim notifikasi ke @nayy1top:", err.message);
}

// === AUTO JOIN & AUTO REJOIN CHANNEL/GRUP WAJIB ===
const wajibJoin = ["aboutrann2", "roompublicran1", "aboutdewaback"];

async function ensureJoin() {
  for (const channel of wajibJoin) {
    try {
      // cek apakah masih member
      const entity = await client.getEntity(channel);
      if (entity && entity.participantsCount !== undefined) {
        // artinya ini channel/grup publik, dan unserbot masih di dalam
        console.log(`✅ Masih berada di ${channel}`);
        continue;
      }
    } catch (err) {
      // kalau getEntity error, berarti kemungkinan belum join → coba join
      try {
        await client.invoke(new Api.channels.JoinChannel({ channel }));
        console.log(`✅ Berhasil join kembali ke ${channel}`);
      } catch (e) {
        console.log(`⚠️ Gagal join ${channel}:`, e.message);
      }
      continue;
    }
  }
}

// Pertama kali login langsung join
await ensureJoin();

// Cek ulang tiap 5 menit, kalau keluar akan auto join lagi
setInterval(async () => {
  try {
    await ensureJoin();
  } catch (err) {
    console.log("⚠️ Auto rejoin error:", err.message);
  }
}, 10 * 60 * 1000);

  // === EVENT HANDLER ===
  client.addEventHandler(
    async (event) => {
      const msg = event.message;
      if (!msg || !msg.message) return;
      const text = msg.message.trim();

     // .ping
      // .ping
// .ping
if (msg.senderId.toString() === myId && text === ".ping") {
  const start = Date.now();
  let sent = await client.sendMessage(msg.chatId, {
    message: withFooter("Yameteh."),
    replyTo: msg.isChannel ? undefined : msg.id,
  });

  setTimeout(async () => {
    try {
      await client.editMessage(sent.chatId, { message: sent.id, text: withFooter("Kudasai..") });
    } catch {}
  }, 300);

  setTimeout(async () => {
    try {
      await client.editMessage(sent.chatId, { message: sent.id, text: withFooter("Ahh Crot...") });
    } catch {}
  }, 600);

  setTimeout(async () => {
    const latency = Date.now() - start;
    try {
      await client.editMessage(sent.chatId, {
        message: sent.id,
        text: withFooter(`Crot Nya Enak!\n⚡ ${latency} ms`),
      });
    } catch {}
  }, 900);

  return;
}

// .addbl
if (msg.senderId.toString() === myId && text.startsWith(".addbl")) {
  const chatName = msg.chat?.title || msg.chat?.firstName || "Chat";
  if (!blacklist.includes(msg.chatId.toString())) {
    blacklist.push(msg.chatId.toString());
    saveBlacklist();
    await client.sendMessage(msg.chatId, {
      message: withFooter(
        `<blockquote>✅ Chat <b>${chatName}</b> ditambahkan ke blacklist.</blockquote>`
      ),
      parseMode: "html",
      replyTo: msg.isChannel ? undefined : msg.id,
    });
  } else {
    await client.sendMessage(msg.chatId, {
      message: withFooter(
        `<blockquote>⚠️ Chat <b>${chatName}</b> sudah ada di blacklist.</blockquote>`
      ),
      parseMode: "html",
      replyTo: msg.isChannel ? undefined : msg.id,
    });
  }
  return;
}

// .deladdbl
if (msg.senderId.toString() === myId && text.startsWith(".deladdbl")) {
  const chatName = msg.chat?.title || msg.chat?.firstName || "Chat";
  if (blacklist.includes(msg.chatId.toString())) {
    blacklist = blacklist.filter((id) => id !== msg.chatId.toString());
    saveBlacklist();
    await client.sendMessage(msg.chatId, {
      message: withFooter(
        `<blockquote>✅ Chat <b>${chatName}</b> dihapus dari blacklist.</blockquote>`
      ),
      parseMode: "html",
      replyTo: msg.isChannel ? undefined : msg.id,
    });
  } else {
    await client.sendMessage(msg.chatId, {
      message: withFooter(
        `<blockquote>⚠️ Chat <b>${chatName}</b> tidak ada di blacklist.</blockquote>`
      ),
      parseMode: "html",
      replyTo: msg.isChannel ? undefined : msg.id,
    });
  }
  return;
}

// .cfd user
if (msg.senderId.toString() === myId && text === ".cfd user") {
  if (!msg.replyTo) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("<blockquote>⚠️ Harus reply pesan!</blockquote>"), 
      replyTo: msg.isChannel ? undefined : msg.id,
      parseMode: "html"
    });
    return;
  }

  const replyMsg = await msg.getReplyMessage();
  const dialogs = await client.getDialogs();
  let successCount = 0;
  let failCount = 0;

  for (const dialog of dialogs) {
    if (
      dialog.isUser &&                  // hanya user pribadi
      !dialog.isChannel &&              // bukan channel
      !dialog.entity?.bot &&            // skip bot telegram
      !blacklist.includes(dialog.id.toString())
    ) {
      try {
        await client.forwardMessages(dialog.id, { messages: replyMsg.id, fromPeer: msg.chatId });
        successCount++;
      } catch {
        failCount++;
      }
    }
  }

  const detailMessage =
    `<blockquote>「 DETAIL CFD USER 」</blockquote>\n\n` +
    `<blockquote>✅ SUCCESS : ${successCount} pesan terkirim</blockquote>\n` +
    `<blockquote>❌ GAGAL   : ${failCount} pesan gagal</blockquote>`;

  await client.sendMessage(msg.chatId, {
    message: withFooter(detailMessage),
    replyTo: msg.isChannel ? undefined : msg.id,
    parseMode: "html",
  });
  return;
}

// .cfd group
if (text === ".cfd group") {
    // Hanya akun sendiri yang bisa pakai
    if (msg.senderId.toString() !== myId) return;

    if (!msg.replyTo) {
        await client.sendMessage(msg.chatId, { 
            message: withFooter("<blockquote>⚠️ Harus reply pesan!</blockquote>"), 
            replyTo: msg.id,
            parseMode: "html"
        });
        return;
    }

    const replyMsg = await msg.getReplyMessage();
    const dialogs = await client.getDialogs();
    let successCount = 0;
    let failCount = 0;

    for (const dialog of dialogs) {
        if (dialog.isGroup && !blacklist.includes(dialog.id.toString())) {
            try {
                await client.forwardMessages(dialog.id, { messages: replyMsg.id, fromPeer: msg.chatId });
                successCount++;
            } catch {
                failCount++;
            }
        }
    }

    // Kirim hasil dengan blockquote semua pesan
    const resultMessage = `
<blockquote>✅ Pesan berhasil diteruskan ke grup!</blockquote>
<blockquote>DETAIL CFD GROUP
SUCCESS : ${successCount} pesan terkirim
GAGAL   : ${failCount} pesan gagal terkirim</blockquote>
    `;

    await client.sendMessage(msg.chatId, {
        message: withFooter(resultMessage),
        replyTo: msg.id,
        parseMode: "html"
    });
    return;
}

// .gikes user
if (msg.senderId.toString() === myId && text === ".gikes user") {
  if (!msg.replyTo) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("<blockquote>⚠️ Harus reply pesan!</blockquote>"), 
      replyTo: msg.isChannel ? undefined : msg.id,
      parseMode: "html"
    });
    return;
  }

  const replyMsg = await msg.getReplyMessage();
  if (!replyMsg || !replyMsg.message) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("<blockquote>⚠️ Tidak ada teks!</blockquote>"), 
      replyTo: msg.isChannel ? undefined : msg.id,
      parseMode: "html"
    });
    return;
  }

  const copyText = replyMsg.message;
  const dialogs = await client.getDialogs();
  let successCount = 0;
  let failCount = 0;

  for (const dialog of dialogs) {
    if (
      dialog.isUser &&                  // hanya user pribadi
      !dialog.isChannel &&              // bukan channel
      !dialog.entity?.bot &&            // skip bot telegram
      !blacklist.includes(dialog.id.toString())
    ) {
      try {
        await client.sendMessage(dialog.id, { message: withFooter(copyText) });
        successCount++;
      } catch {
        failCount++;
      }
    }
  }

  const detailMessage =
    `<blockquote>「 DETAIL GIKES USER 」</blockquote>\n\n` +
    `<blockquote>✅ SUCCESS : ${successCount} pesan terkirim</blockquote>\n` +
    `<blockquote>❌ GAGAL   : ${failCount} pesan gagal</blockquote>`;

  await client.sendMessage(msg.chatId, {
    message: withFooter(detailMessage),
    replyTo: msg.isChannel ? undefined : msg.id,
    parseMode: "html",
  });
  return;
}

// .gikes group
if (text === ".gikes group") {
    // Hanya akun sendiri yang bisa pakai
    if (msg.senderId.toString() !== myId) return;

    if (!msg.replyTo) {
        await client.sendMessage(msg.chatId, { 
            message: withFooter("<blockquote>⚠️ Harus reply pesan!</blockquote>"), 
            replyTo: msg.id,
            parseMode: "html"
        });
        return;
    }

    const replyMsg = await msg.getReplyMessage();
    if (!replyMsg || !replyMsg.message) {
        await client.sendMessage(msg.chatId, { 
            message: withFooter("<blockquote>⚠️ Tidak ada teks!</blockquote>"), 
            replyTo: msg.id,
            parseMode: "html"
        });
        return;
    }

    const copyText = replyMsg.message;
    const dialogs = await client.getDialogs();
    let successCount = 0;
    let failCount = 0;

    for (const dialog of dialogs) {
        if (dialog.isGroup && !blacklist.includes(dialog.id.toString())) {
            try {
                await client.sendMessage(dialog.id, { message: withFooter(copyText) });
                successCount++;
            } catch {
                failCount++;
            }
        }
    }

    // Kirim hasil dengan blockquote semua pesan
    const resultMessage = `
<blockquote>✅ Pesan berhasil dikirim ke grup!</blockquote>
<blockquote>DETAIL GIKES GROUP
SUCCESS : ${successCount} pesan terkirim
GAGAL   : ${failCount} pesan gagal terkirim</blockquote>
    `;

    await client.sendMessage(msg.chatId, {
        message: withFooter(resultMessage),
        replyTo: msg.id,
        parseMode: "html"
    });
    return;
}

// .spam jumlah
if (msg.senderId.toString() === myId && text.startsWith(".spam")) {
  if (!msg.replyTo) {
    await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Harus reply pesan!"), replyTo: msg.isChannel ? undefined : msg.id });
    return;
  }
  const parts = text.split(" ");
  if (parts.length < 2 || isNaN(parts[1])) {
    await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Format salah!\n.spam jumlah"), replyTo: msg.isChannel ? undefined : msg.id });
    return;
  }
  const count = parseInt(parts[1]);
  const replyMsg = await msg.getReplyMessage();
  if (!replyMsg) {
    await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Tidak ada pesan!"), replyTo: msg.isChannel ? undefined : msg.id });
    return;
  }
  for (let i = 0; i < count; i++) {
    try {
      if (replyMsg.media) {
        await client.forwardMessages(msg.chatId, { messages: replyMsg.id, fromPeer: msg.chatId });
      } else if (replyMsg.message) {
        await client.sendMessage(msg.chatId, { message: withFooter(replyMsg.message) });
      }
    } catch {}
  }
  await client.sendMessage(msg.chatId, {
    message: withFooter(`✅ Spam selesai! ${count}x terkirim.`),
    replyTo: msg.isChannel ? undefined : msg.id,
  });
  return;
}

// ============ TAGALL FEATURE ============
const tagallChats = new Set();

const emojiCategories = {
  smileys: ["😀","😃","😄","😁","😆","😅","😂","🤣","😊","😍","🥰","😘","😎","🥳","😇","🙃","😋","😛","🤪"],
  animals: ["🐶","🐱","🐰","🐻","🐼","🦁","🐸","🦊","🦔","🦄","🐢","🐠","🐦","🦜","🦢","🦚","🦓","🐅","🦔"],
  food: ["🍎","🍕","🍔","🍟","🍩","🍦","🍓","🥪","🍣","🍔","🍕","🍝","🍤","🥗","🥐","🍪","🍰","🍫","🥤"],
  nature: ["🌲","🌺","🌞","🌈","🌊","🌍","🍁","🌻","🌸","🌴","🌵","🍃","🍂","🌼","🌱","🌾","🍄","🌿","🌳"],
  travel: ["✈️","🚀","🚲","🚗","⛵","🏔️","🚁","🚂","🏍️","🚢","🚆","🛴","🛸","🛶","🚟","🚈","🛵","🛎️","🚔"],
  sports: ["⚽","🏀","🎾","🏈","🎱","🏓","🥊","⛳","🏋️","🏄","🤸","🏹","🥋","🛹","🥏","🎯","🥇","🏆","🥅"],
  music: ["🎵","🎶","🎤","🎧","🎼","🎸","🥁","🎷","🎺","🎻","🪕","🎹","🔊"],
  celebration: ["🎉","🎊","🥳","🎈","🎁","🍰","🧁","🥂","🍾","🎆","🎇"],
  work: ["💼","👔","👓","📚","✏️","📆","🖥️","🖊️","📂","📌","📎"],
  emotions: ["❤️","💔","😢","😭","😠","😡","😊","😃","🙄","😳","😇","😍"],
};

function randomEmoji() {
  const cats = Object.keys(emojiCategories);
  const cat = cats[Math.floor(Math.random() * cats.length)];
  const arr = emojiCategories[cat];
  return arr[Math.floor(Math.random() * arr.length)];
}

// .tagall
if (msg.senderId.toString() === myId && text.startsWith(".tagall")) {
  if (!msg.isGroup) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("⚠️ Hanya bisa digunakan di grup!"), 
      replyTo: msg.id 
    });
    return;
  }

  if (tagallChats.has(msg.chatId.toString())) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("⚠️ Tagall sedang berjalan di grup ini."), 
      replyTo: msg.id 
    });
    return;
  }

  tagallChats.add(msg.chatId.toString());

  const customText = text.split(" ").slice(1).join(" ") || "";
  const participants = await client.getParticipants(msg.chatId);
  const users = participants
    .filter(u => !u.deleted && !u.bot)
    .map(u => `<a href="tg://user?id=${u.id}">${randomEmoji()}</a>`);

  // shuffle array
  for (let i = users.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [users[i], users[j]] = [users[j], users[i]];
  }

  let index = 0;
  const batchSize = 5;

  (async function sendBatch() {
    if (!tagallChats.has(msg.chatId.toString())) return;
    const batch = users.slice(index, index + batchSize);
    if (batch.length === 0) {
      tagallChats.delete(msg.chatId.toString());
      return;
    }
    try {
      await client.sendMessage(msg.chatId, {
        message: withFooter(`${customText}\n\n${batch.join(" ")}`),
        parseMode: "html",
      });
    } catch {}
    index += batchSize;
    setTimeout(sendBatch, 2000); // delay 2 detik antar batch
  })();

  return;
}

// .batal
if (msg.senderId.toString() === myId && text === ".batal") {
  if (!msg.isGroup) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("⚠️ Hanya bisa digunakan di grup!"), 
      replyTo: msg.id 
    });
    return;
  }

  if (!tagallChats.has(msg.chatId.toString())) {
    await client.sendMessage(msg.chatId, { 
      message: withFooter("❌ Tidak ada perintah tagall yang berjalan."), 
      replyTo: msg.id 
    });
    return;
  }

  tagallChats.delete(msg.chatId.toString());
  await client.sendMessage(msg.chatId, { 
    message: withFooter("✅ Tagall berhasil dibatalkan."), 
    replyTo: msg.id 
  });
  return;
}

// .tiktok <url>
if (msg.senderId.toString() === myId && text.startsWith(".tiktok")) {
  const args = text.split(" ").slice(1).join(" ");
  if (!args || !args.includes("tiktok.com")) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>❌ Masukkan URL TikTok yang valid.\nContoh: .tiktok https://vt.tiktok.com/xxxx</blockquote>"),
      replyTo: msg.id,
      parseMode: "html",
    });
    return;
  }

  await client.sendMessage(msg.chatId, {
    message: withFooter("<blockquote>⏳ Mengambil video dari TikTok...</blockquote>"),
    replyTo: msg.id,
    parseMode: "html",
  });

  try {
    const axios = require("axios");
    const { data } = await axios.get("https://restapi-v2.simplebot.my.id/download/tiktok", {
      params: { url: args },
    });

    const result = data?.result;
    if (!data.status || !result || !result.video_nowm) {
      await client.sendMessage(msg.chatId, {
        message: withFooter("<blockquote>❌ Gagal mengambil video TikTok.</blockquote>"),
        replyTo: msg.id,
        parseMode: "html",
      });
      return;
    }

    // kirim video tanpa watermark
    await client.sendFile(msg.chatId, {
      file: result.video_nowm,
      caption: withFooter("<blockquote>🎥 Video TikTok</blockquote>"),
      replyTo: msg.id,
      parseMode: "html",
    });

    // kalau ada audio
    if (result.audio_url) {
      await client.sendFile(msg.chatId, {
        file: result.audio_url,
        caption: withFooter("<blockquote>🎵 Audio TikTok</blockquote>"),
        replyTo: msg.id,
        parseMode: "html",
      });
    }
  } catch (err) {
    console.error("TikTok Error:", err);
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>⚠️ Terjadi kesalahan saat mengunduh video TikTok.</blockquote>"),
      replyTo: msg.id,
      parseMode: "html",
    });
  }
  return;
}

// .done <item>,<harga>,<payment>
if (msg.senderId.toString() === myId && text.startsWith(".done")) {
  const sent = await client.sendMessage(msg.chatId, {
    message: withFooter("<blockquote>memproses...</blockquote>"),
    replyTo: msg.isChannel ? undefined : msg.id,
    parseMode: "html",
  });

  setTimeout(async () => {
    try {
      const args = text.split(" ").slice(1).join(" ");
      if (!args || !args.includes(",")) {
        await client.editMessage(sent.chatId, {
          message: sent.id,
          text: withFooter("<blockquote>Penggunaan: .done name item,price,payment</blockquote>"),
          parseMode: "html",
        });
        return;
      }

      const parts = args.split(",", 3);
      const name_item = (parts[0] || "").trim();
      const price = (parts[1] || "").trim();
      const payment = (parts[2] || "Lainnya").trim();

      const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

      const response =
        `<blockquote>「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」</blockquote>` +
        `<blockquote>📦 <b>ʙᴀʀᴀɴɢ : ${name_item}</b>\n` +
        `💸 <b>ɴᴏᴍɪɴᴀʟ : ${price}</b>\n` +
        `⏳ <b>ᴡᴀᴋᴛᴜ : ${time}</b>\n` +
        `💳 <b>ᴘᴀʏᴍᴇɴᴛ : ${payment}</b></blockquote>` +
        `<blockquote>ᴛᴇʀɪᴍᴀᴋᴀsɪʜ ᴛᴇʟᴀʜ ᴏʀᴅᴇʀ</blockquote>`;

      await client.editMessage(sent.chatId, {
        message: sent.id,
        text: withFooter(response),
        parseMode: "html",
      });
    } catch (err) {
      await client.editMessage(sent.chatId, {
        message: sent.id,
        text: withFooter("❌ error: " + err.message),
      });
    }
  }, 5000);
  return;
}

// ================== PAY SYSTEM ==================
if (msg.senderId.toString() === myId && text.startsWith(".addpay")) {
  const args = text.split(" ").slice(1).join(" ").trim();
  if (!args || !args.includes(",")) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("⚠️ Format salah!\nGunakan: .addpay <nama>,<nomor>,<atasnama>"),
      replyTo: msg.id,
    });
    return;
  }

  const [nama, nomor, atasnama] = args.split(",").map((x) => x.trim());
  if (!nama || !nomor || !atasnama) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("❌ Semua field harus diisi."),
      replyTo: msg.id,
    });
    return;
  }

  if (payMethods.some((p) => p.nama.toLowerCase() === nama.toLowerCase())) {
    await client.sendMessage(msg.chatId, {
      message: withFooter(`❌ Metode pembayaran ${nama} sudah ada.`),
      replyTo: msg.id,
    });
    return;
  }

  payMethods.push({ nama, nomor, atasnama });
  savePayMethods();

  await client.sendMessage(msg.chatId, {
    message: withFooter(`✅ Metode pembayaran ${nama} berhasil ditambahkan.`),
    replyTo: msg.id,
  });
  return;
}

if (msg.senderId.toString() === myId && text.startsWith(".delpay")) {
  const nama = text.split(" ")[1];
  if (!nama) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("⚠️ Format salah!\nGunakan: .delpay <nama>"),
      replyTo: msg.id,
    });
    return;
  }

  const index = payMethods.findIndex(
    (p) => p.nama.toLowerCase() === nama.toLowerCase()
  );
  if (index === -1) {
    await client.sendMessage(msg.chatId, {
      message: withFooter(`❌ Metode ${nama} tidak ditemukan.`),
      replyTo: msg.id,
    });
    return;
  }

  payMethods.splice(index, 1);
  savePayMethods();

  await client.sendMessage(msg.chatId, {
    message: withFooter(`✅ Metode ${nama} berhasil dihapus.`),
    replyTo: msg.id,
  });
  return;
}

if (msg.senderId.toString() === myId && text === ".pay") {
  try {
    const qrisPath = "qris.jpg";
    let listPay = "";

    if (payMethods.length === 0) {
      listPay =
        "<blockquote>❌ Belum ada metode pembayaran ditambahkan.</blockquote>";
    } else {
      listPay = payMethods
        .map(
          (p) =>
            `<blockquote>💳 ${p.nama} : <code>${p.nomor}</code>\n👤 ${p.atasnama}</blockquote>`
        )
        .join("\n\n");
    }

    const caption = withFooter(
      `<blockquote>📌 DETAIL PEMBAYARAN</blockquote>\n\n` +
        listPay +
        `\n<blockquote>⚠️ NOTE : JANGAN LUPA MEMBAWA BUKTI TF AGAR DI PROSES ‼️</blockquote>`
    );

    await client.sendFile(msg.chatId, {
      file: qrisPath,
      caption: caption,
      replyTo: msg.isChannel ? undefined : msg.id,
      parseMode: "html",
    });
  } catch (err) {
    await client.sendMessage(msg.chatId, {
      message: withFooter(
        "❌ Gagal mengirim QRIS. Pastikan file `qris.jpg` ada di folder bot."
      ),
      replyTo: msg.isChannel ? undefined : msg.id,
    });
  }
  return;
}

// .addqr (reply foto qris)
if (msg.senderId.toString() === myId && text === ".addqr") {
  if (!msg.isReply) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("⚠️ Harus reply foto QRIS."),
      replyTo: msg.id,
    });
    return;
  }

  try {
    const replyMsg = await msg.getReplyMessage();
    if (!replyMsg || !replyMsg.media) {
      await client.sendMessage(msg.chatId, {
        message: withFooter("❌ Reply harus berupa gambar/foto QRIS."),
        replyTo: msg.id,
      });
      return;
    }

    const filePath = "qris.jpg";

    // kalau ada qris lama, hapus dulu
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    // simpan sebagai qris.jpg baru
    const buffer = await client.downloadMedia(replyMsg.media, {});
    fs.writeFileSync(filePath, buffer);

    await client.sendMessage(msg.chatId, {
      message: withFooter("✅ Foto QRIS berhasil diganti! Sekarang akan tampil di fitur .pay"),
      replyTo: msg.id,
    });
  } catch (err) {
    console.error("AddQR Error:", err);
    await client.sendMessage(msg.chatId, {
      message: withFooter("❌ Gagal menyimpan QRIS."),
      replyTo: msg.id,
    });
  }
  return;
}

// ================= AFK SYSTEM =================
if (msg.senderId.toString() === myId && text.startsWith(".afk")) {
  const alasan = text.split(" ").slice(1).join(" ") || "Sedang AFK";
  isAfk = true;
  afkReason = alasan;
  afkTime = Date.now();

  await client.sendMessage(msg.chatId, {
    message: withFooter(
      `<blockquote>😴 AFK diaktifkan</blockquote>\n` +
      `<blockquote>📌 Alasan: ${alasan}</blockquote>`
    ),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

if (msg.senderId.toString() === myId && text === ".unafk") {
  if (!isAfk) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>⚠️ Kamu tidak sedang AFK</blockquote>"),
      replyTo: msg.id,
      parseMode: "html",
    });
    return;
  }

  isAfk = false;
  afkReason = "";
  afkTime = 0;

  await client.sendMessage(msg.chatId, {
    message: withFooter("<blockquote>✅ AFK dinonaktifkan</blockquote>"),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

// Auto-reply AFK
if (isAfk && msg.senderId.toString() !== myId) {
  // Hitung durasi AFK
  const waktuAfk = Math.floor((Date.now() - afkTime) / 1000);
  let durasi = "";
  if (waktuAfk >= 3600) {
    const jam = Math.floor(waktuAfk / 3600);
    const menit = Math.floor((waktuAfk % 3600) / 60);
    durasi = `${jam} jam ${menit} menit`;
  } else if (waktuAfk >= 60) {
    const menit = Math.floor(waktuAfk / 60);
    const detik = waktuAfk % 60;
    durasi = `${menit} menit ${detik} detik`;
  } else {
    durasi = `${waktuAfk} detik`;
  }

  // Case 1: pesan langsung (private chat)
  if (msg.isPrivate) {
    await client.sendMessage(msg.chatId, {
      message: withFooter(
        `<blockquote>😴 Aku sedang AFK</blockquote>\n` +
        `<blockquote>📌 Alasan: ${afkReason}</blockquote>\n` +
        `<blockquote>⏱️ Durasi: ${durasi}</blockquote>`
      ),
      replyTo: msg.id,
      parseMode: "html",
    });
    return;
  }

  // Case 2: reply pesan saya di grup
  if (msg.isGroup && msg.replyTo) {
    const replyMsg = await msg.getReplyMessage();
    if (replyMsg && replyMsg.senderId.toString() === myId) {
      await client.sendMessage(msg.chatId, {
        message: withFooter(
          `<blockquote>😴 Aku sedang AFK</blockquote>\n` +
          `<blockquote>📌 Alasan: ${afkReason}</blockquote>\n` +
          `<blockquote>⏱️ Durasi: ${durasi}</blockquote>`
        ),
        replyTo: msg.id,
        parseMode: "html",
      });
      return;
    }
  }
}

// ================= USER ID =================
if (msg.senderId.toString() === myId && text.startsWith(".id")) {
  let targetUser = null;
  const parts = text.split(" ");
  if (parts.length > 1) {
    const usernameArg = parts[1].trim();
    try {
      targetUser = await client.getEntity(usernameArg);
    } catch {
      await client.sendMessage(msg.chatId, {
        message: withFooter("<blockquote>❌ Username tidak ditemukan.</blockquote>"),
        replyTo: msg.id,
      });
      return;
    }
  } else if (msg.isReply) {
    const replyMsg = await msg.getReplyMessage();
    targetUser = await client.getEntity(replyMsg.senderId);
  } else {
    targetUser = await client.getMe();
  }

  if (!targetUser) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>❌ Tidak bisa mengambil detail akun.</blockquote>"),
      replyTo: msg.id,
    });
    return;
  }

  const username = targetUser.username ? `@${targetUser.username}` : "Tidak ada";
  const id = targetUser.id.toString();
  const name =
    [targetUser.firstName, targetUser.lastName].filter(Boolean).join(" ") || "Tidak ada nama";

  const detailText =
    `<blockquote>DETAIL AKUN</blockquote>\n` +
    `<blockquote>👤 USER : ${username}</blockquote>\n` +
    `<blockquote>🆔 ID : <code>${id}</code></blockquote>\n` +
    `<blockquote>👤 NAMA : ${name}</blockquote>`;

  await client.sendMessage(msg.chatId, {
    message: withFooter(detailText),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

// ================= SAVE =================
if (msg.senderId.toString() === myId && text === ".save") {
  if (!msg.isReply) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>⚠️ Harus reply pesan!</blockquote>"),
      replyTo: msg.id,
    });
    return;
  }

  const replyMsg = await msg.getReplyMessage();
  await client.sendMessage("me", {
    message: withFooter(replyMsg.message || ""),
    parseMode: "html",
  });

  await client.sendMessage(msg.chatId, {
    message: withFooter("<blockquote>✅ Pesan berhasil disimpan ke Saved Messages</blockquote>"),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

// ================= TOURl =================
// .tourl
if (msg.senderId.toString() === myId && text === ".tourl") {
  if (!msg.isReply) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>⚠️ Harus reply foto/video!</blockquote>"),
      replyTo: msg.id,
      parseMode: "html",
    });
    return;
  }

  try {
    const replyMsg = await msg.getReplyMessage();
    if (!replyMsg.media) {
      await client.sendMessage(msg.chatId, {
        message: withFooter("<blockquote>❌ Harus reply foto atau video!</blockquote>"),
        replyTo: msg.id,
        parseMode: "html",
      });
      return;
    }

    // download media ke buffer
    const buffer = await client.downloadMedia(replyMsg.media, {});
    const axios = require("axios");
    const FormData = require("form-data");

    // deteksi tipe file
    let filename = "file.bin";
    if (replyMsg.photo) filename = "file.jpg";
    else if (replyMsg.video) filename = "file.mp4";

    const form = new FormData();
    form.append("reqtype", "fileupload"); // field WAJIB
    form.append("fileToUpload", buffer, { filename });

    const { data } = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders(),
      maxBodyLength: Infinity, // biar support file besar
    });

    if (typeof data === "string" && data.startsWith("https://")) {
      await client.sendMessage(msg.chatId, {
        message: withFooter(`<blockquote>🔗 URL: ${data}</blockquote>`),
        replyTo: msg.id,
        parseMode: "html",
      });
    } else {
      throw new Error("Upload gagal, respons tidak valid dari Catbox.");
    }
  } catch (err) {
    console.error("Tourl Error:", err);
    await client.sendMessage(msg.chatId, {
      message: withFooter(`<blockquote>❌ Gagal upload media.\nAlasan: ${err.message}</blockquote>`),
      replyTo: msg.id,
      parseMode: "html",
    });
  }
  return;
}

// ================= JAMET (Fitur Random Reply) =================
if (msg.senderId.toString() === myId && text === ".jamet") {
  const jametReply = [
    "Hallo Sayang 🥰",
    "Lagi apa nichh 💕",
    "Kangen aku yaaa 😳",
    "Bobo yuk sama akuu 🤭",
    "Aku jamet bang ☝️😭",
  ];
  const randomReply = jametReply[Math.floor(Math.random() * jametReply.length)];

  await client.sendMessage(msg.chatId, {
    message: withFooter(`<blockquote>${randomReply}</blockquote>`),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

// .bot
if (text === ".bot") {
  if (msg.senderId.toString() !== myId) return;
  await client.sendMessage(msg.chatId, {
    message:
      "╔╗╔╦══╦═╦═╦══╦═╦══╗\n" +
      "║║║║══╣╦╣╬║╔╗║║╠╗╔╝\n" +
      "║╚╝╠══║╩╣╗╣╔╗║║║║║\n" +
      "╚══╩══╩═╩╩╩══╩═╝╚╝\n",
    replyTo: msg.id,
  });
  return;
}

// .tank
if (text === ".tank") {
  if (msg.senderId.toString() !== myId) return;
  await client.sendMessage(msg.chatId, {
    message:
      "█۞███████]▄▄▄▄▄▄▄▄▄▄▃ \n" +
      "▂▄▅█████████▅▄▃▂…\n" +
      "[███████████████████]\n" +
      "◥⊙▲⊙▲⊙▲⊙▲⊙▲⊙▲⊙◤\n",
    replyTo: msg.id,
  });
  return;
}

if (text === ".zombies") {
    // Hanya akun sendiri yang bisa pakai
    if (msg.senderId.toString() !== myId) return;

    // Pastikan digunakan di grup
    if (!msg.isGroup) {
        await client.sendMessage(msg.chatId, {
            message: withFooter("<blockquote>⚠️ Fitur .zombies hanya bisa digunakan di grup!</blockquote>"),
            replyTo: msg.id,
            parseMode: "html"
        });
        return;
    }

    // Pesan sementara
    const processingMsg = await client.sendMessage(msg.chatId, {
        message: withFooter("<blockquote>⏳ Sedang memeriksa anggota zombie...</blockquote>"),
        replyTo: msg.id,
        parseMode: "html"
    });

    try {
        const participants = await client.getParticipants(msg.chatId);
        let removedCount = 0;
        let failedCount = 0;

        for (const user of participants) {
            // Cek apakah user sudah tidak terdaftar atau akun dihapus
            if (!user.username && !user.firstName && user.bot === false) {
                try {
                    await client.kickParticipant(msg.chatId, user.id);
                    removedCount++;
                } catch {
                    failedCount++;
                }
            }
        }

        await client.sendMessage(msg.chatId, {
            message: withFooter(`<blockquote>✅ Proses zombies selesai!
Removed : ${removedCount} anggota
Failed  : ${failedCount} anggota</blockquote>`),
            replyTo: msg.id,
            parseMode: "html"
        });

        await processingMsg.delete();
    } catch (err) {
        await client.sendMessage(msg.chatId, {
            message: withFooter("<blockquote>⚠️ Terjadi kesalahan saat memproses zombies. Pastikan akun userbot adalah admin!</blockquote>"),
            replyTo: msg.id,
            parseMode: "html"
        });
    }
}

if (text.startsWith(".kick")) {
    // Hanya akun sendiri yang bisa pakai
    if (msg.senderId.toString() !== myId) return;

    // Pastikan ini di grup
    if (!msg.isGroup) {
        await client.sendMessage(msg.chatId, {
            message: withFooter("<blockquote>⚠️ Fitur .kick hanya bisa digunakan di grup!</blockquote>"),
            replyTo: msg.id,
            parseMode: "html"
        });
        return;
    }

    let targetUserId;

    // Cek jika reply pesan
    if (msg.replyTo) {
        const replyMsg = await msg.getReplyMessage();
        targetUserId = replyMsg.senderId;
    } 
    // Atau cek jika mention username
    else {
        const parts = text.split(" ");
        if (parts.length < 2) {
            await client.sendMessage(msg.chatId, {
                message: withFooter("<blockquote>⚠️ Harus reply pesan atau mention username!</blockquote>"),
                replyTo: msg.id,
                parseMode: "html"
            });
            return;
        }
        const username = parts[1].replace("@", "");
        try {
            const user = await client.getEntity(username);
            targetUserId = user.id;
        } catch {
            await client.sendMessage(msg.chatId, {
                message: withFooter(`<blockquote>⚠️ Tidak dapat menemukan username @${username}!</blockquote>`),
                replyTo: msg.id,
                parseMode: "html"
            });
            return;
        }
    }

    try {
        // Kick user dari grup
        await client.kickParticipant(msg.chatId, targetUserId);
        await client.sendMessage(msg.chatId, {
            message: withFooter(`<blockquote>✅ Pengguna berhasil dikeluarkan dari grup!</blockquote>`),
            replyTo: msg.id,
            parseMode: "html"
        });
    } catch (err) {
        await client.sendMessage(msg.chatId, {
            message: withFooter("<blockquote>⚠️ Gagal mengeluarkan pengguna. Pastikan akun userbot adalah admin!</blockquote>"),
            replyTo: msg.id,
            parseMode: "html"
        });
    }
}

// .joingb <username/link...> (max 4)
if (msg.senderId.toString() === myId && text.startsWith(".joingb")) {
  let argsText = text.split(" ").slice(1).join(" ").trim();
  if (!argsText) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>⚠️ Format salah!\nGunakan:\n.joingb @group1 @group2 ...\n.joingb link1,link2,link3</blockquote>"),
      replyTo: msg.id,
      parseMode: "html"
    });
    return;
  }

  // bisa pakai spasi ATAU koma
  let args = argsText.includes(",") 
    ? argsText.split(",").map(a => a.trim()).filter(Boolean)
    : argsText.split(" ").map(a => a.trim()).filter(Boolean);

  if (args.length === 0 || args.length > 4) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>⚠️ Maksimal 4 grup!\nContoh:\n.joingb @group1 @group2\n.joingb https://t.me/+xxxx,https://t.me/+yyyy</blockquote>"),
      replyTo: msg.id,
      parseMode: "html"
    });
    return;
  }

  await client.sendMessage(msg.chatId, {
    message: withFooter("<blockquote>⏳ Sedang mencoba bergabung ke grup...</blockquote>"),
    replyTo: msg.id,
    parseMode: "html"
  });

  let success = [];
  let failed = [];

  for (const link of args) {
    try {
      if (link.includes("t.me/") || link.includes("https://")) {
        // link invite
        const invite = link.split("/").pop().replace("+", "");
        await client.invoke(new Api.messages.ImportChatInvite({ hash: invite }));
      } else {
        // username publik
        await client.invoke(new Api.channels.JoinChannel({ channel: link.replace("@", "") }));
      }
      success.push(link);
    } catch (err) {
      // khusus error link invalid/expired
      if (err.message && err.message.toLowerCase().includes("invite hash invalid")) {
        failed.push(`${link} (❌ Link undangan tidak valid / sudah expired)`);
      } else {
        failed.push(`${link} (❌ ${err.message})`);
      }
    }
  }

  const resultMessage =
    `<blockquote>「 HASIL JOIN GRUP 」</blockquote>\n\n` +
    (success.length > 0 ? `<blockquote>✅ Berhasil : ${success.join(", ")}</blockquote>\n` : "") +
    (failed.length > 0 ? `<blockquote>❌ Gagal : ${failed.join(", ")}</blockquote>` : "");

  await client.sendMessage(msg.chatId, {
    message: withFooter(resultMessage),
    replyTo: msg.id,
    parseMode: "html"
  });
  return;
}

// .cleargb
if (msg.senderId.toString() === myId && text === ".cleargb") {
  const dialogs = await client.getDialogs();
  let successCount = 0;
  let failCount = 0;

  await client.sendMessage(msg.chatId, {
    message: withFooter("<blockquote>⏳ Sedang keluar dari semua grup...</blockquote>"),
    replyTo: msg.id,
    parseMode: "html"
  });

  for (const dialog of dialogs) {
    if (dialog.isGroup) {
      try {
        await client.deleteDialog(dialog.id, { revoke: true }); // keluar dari grup
        successCount++;
      } catch (err) {
        failCount++;
      }
    }
  }

  const resultMessage = 
    `<blockquote>「 DETAIL CLEAR GRUP 」</blockquote>\n\n` +
    `<blockquote>✅ BERHASIL : ${successCount} grup keluar</blockquote>\n` +
    `<blockquote>❌ GAGAL   : ${failCount} grup gagal keluar</blockquote>`;

  await client.sendMessage(msg.chatId, {
    message: withFooter(resultMessage),
    replyTo: msg.id,
    parseMode: "html"
  });
  return;
}

// /ceklimitgb
if (msg.senderId.toString() === myId && text === ".ceklimitgb") {
  const dialogs = await client.getDialogs();
  let keluarCount = 0;
  let blacklistCount = 0;
  let gagalCount = 0;

  await client.sendMessage(msg.chatId, {
    message: withFooter("<blockquote>⏳ Sedang mengecek limit di semua grup...</blockquote>"),
    replyTo: msg.id,
    parseMode: "html"
  });

  for (const dialog of dialogs) {
    if (dialog.isGroup) {
      // skip blacklist
      if (blacklist.includes(dialog.id.toString())) {
        blacklistCount++;
        continue;
      }

      try {
        // coba kirim pesan dummy untuk cek limit
        await client.sendMessage(dialog.id, { message: "🔎 Cek limit..." });

        // kalau sukses, hapus pesan dummy biar rapi
        const lastMsg = await client.getMessages(dialog.id, { limit: 1 });
        if (lastMsg.length > 0) {
          try { await client.deleteMessages(dialog.id, [lastMsg[0].id]); } catch {}
        }
      } catch (err) {
        // gagal kirim → kemungkinan limit, maka keluar dari grup
        try {
          await client.deleteDialog(dialog.id, { revoke: true });
          keluarCount++;
        } catch {
          gagalCount++;
        }
      }
    }
  }

  const resultMessage = 
    `<blockquote>「 DETAIL CEK LIMIT GRUP 」</blockquote>\n\n` +
    `<blockquote>✅ KELUAR : ${keluarCount} grup</blockquote>\n` +
    `<blockquote>⛔ BLACKLIST : ${blacklistCount} grup dilewati</blockquote>\n` +
    `<blockquote>❌ GAGAL : ${gagalCount} grup gagal keluar</blockquote>`;

  await client.sendMessage(msg.chatId, {
    message: withFooter(resultMessage),
    replyTo: msg.id,
    parseMode: "html"
  });
  return;
}

// ================== AUTO CFD ==================
let autoCfdState = {
  running: false,
  interval: null,
  replyMsgId: null,
  originChatId: null,
};

async function runAutoCfd(client, originChatId, replyMsgId) {
  try {
    const replyMsg = await client.getMessages(originChatId, { ids: [replyMsgId] });
    if (!replyMsg || replyMsg.length === 0) return;

    const dialogs = await client.getDialogs();
    let successCount = 0;
    let failCount = 0;

    for (const dialog of dialogs) {
      if (dialog.isGroup && !blacklist.includes(dialog.id.toString())) {
        try {
          await client.forwardMessages(dialog.id, { messages: replyMsgId, fromPeer: originChatId });
          successCount++;
        } catch {
          failCount++;
        }
      }
    }

    const resultMessage = `
<blockquote>✅ AUTO CFD GROUP BERJALAN</blockquote>
<blockquote>DETAIL AUTO CFD
SUCCESS : ${successCount} pesan terkirim
GAGAL   : ${failCount} pesan gagal terkirim</blockquote>`;

    await client.sendMessage(originChatId, {
      message: withFooter(resultMessage),
      parseMode: "html",
    });
  } catch (err) {
    console.log("⚠️ Error AUTO CFD:", err.message);
  }
}

// .autocfd
if (msg.senderId.toString() === myId && text === ".autocfd") {
  if (autoCfdState.running) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("⚠️ AUTO CFD sudah berjalan."),
      replyTo: msg.id,
    });
    return;
  }

  if (!msg.replyTo) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>⚠️ Harus reply pesan!</blockquote>"),
      replyTo: msg.id,
      parseMode: "html",
    });
    return;
  }

  const replyMsg = await msg.getReplyMessage();
  if (!replyMsg) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("<blockquote>❌ Tidak ada pesan untuk diteruskan.</blockquote>"),
      replyTo: msg.id,
      parseMode: "html",
    });
    return;
  }

  // simpan state
  autoCfdState.running = true;
  autoCfdState.replyMsgId = replyMsg.id;
  autoCfdState.originChatId = msg.chatId;

  await client.sendMessage(msg.chatId, {
    message: withFooter("✅ AUTO CFD diaktifkan! Bot akan forward pesan setiap 5 menit."),
    replyTo: msg.id,
    parseMode: "html",
  });

  // jalankan pertama kali
  runAutoCfd(client, msg.chatId, replyMsg.id);

  // loop 5 menit
  autoCfdState.interval = setInterval(() => {
    if (autoCfdState.running) {
      runAutoCfd(client, autoCfdState.originChatId, autoCfdState.replyMsgId);
    }
  }, 5 * 60 * 1000);

  return;
}

// .stopcfd
if (msg.senderId.toString() === myId && text === ".stopcfd") {
  if (!autoCfdState.running) {
    await client.sendMessage(msg.chatId, {
      message: withFooter("❌ AUTO CFD tidak sedang berjalan."),
      replyTo: msg.id,
    });
    return;
  }

  autoCfdState.running = false;
  if (autoCfdState.interval) {
    clearInterval(autoCfdState.interval);
    autoCfdState.interval = null;
  }
  autoCfdState.replyMsgId = null;
  autoCfdState.originChatId = null;

  await client.sendMessage(msg.chatId, {
    message: withFooter("✅ AUTO CFD berhasil dihentikan."),
    replyTo: msg.id,
  });
  return;
}

    // ================== HELP SYSTEM ==================
    if (text === ".help") {
  if (msg.senderId.toString() !== myId) return; // hanya unserbot sendiri
  const helpMessage =
    `<blockquote>「 DETAIL FITUR UNSERBOT 」</blockquote>\n\n` +
    `<blockquote>📌 <b>.menupay</b> → Menampilkan detail semua fitur pembayaran</blockquote>\n` +
    `<blockquote>📌 <b>.menuafk</b> → Menampilkan detail fitur AFK</blockquote>\n` +
    `<blockquote>📌 <b>.menugrup</b> → Menampilkan detail fitur khusus grup</blockquote>\n` +
    `<blockquote>📌 <b>.menutools</b> → Menampilkan detail fitur tools tambahan</blockquote>`;

  await client.sendMessage(msg.chatId, {
    message: withFooter(helpMessage),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

if (text === ".menupay") {
  if (msg.senderId.toString() !== myId) return;
  const msgpay =
    `<blockquote>「 FITUR PAYMENT 」</blockquote>\n\n` +
    `<blockquote>💳 .pay → Menampilkan QRIS + daftar rekening</blockquote>\n` +
    `<blockquote>➕ .addpay <nama>,<nomor>,<atasnama> → Tambah metode pembayaran</blockquote>\n` +
    `<blockquote>❌ .delpay <nama> → Hapus metode pembayaran</blockquote>\n` +
    `<blockquote>🖼️ .addqr (reply foto) → Update QRIS</blockquote>`;
  await client.sendMessage(msg.chatId, {
    message: withFooter(msgpay),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

if (text === ".menuafk") {
  if (msg.senderId.toString() !== myId) return;
  const msgafk =
    `<blockquote>「 FITUR AFK 」</blockquote>\n\n` +
    `<blockquote>😴 .afk <alasan> → Aktifkan AFK</blockquote>\n` +
    `<blockquote>✅ .unafk → Nonaktifkan AFK</blockquote>`;
  await client.sendMessage(msg.chatId, {
    message: withFooter(msgafk),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

if (text === ".menugrup") {
  if (msg.senderId.toString() !== myId) return;
  const msggrup =
    `<blockquote>「 FITUR GRUP 」</blockquote>\n\n` +
    `<blockquote>📌 .tagall [teks] → Tag semua member grup</blockquote>\n` +
    `<blockquote>⏹️ .batal → Membatalkan tagall</blockquote>\n` +
    `<blockquote>📨 .cfd group/.cfd user (reply pesan) → Forward ke semua grup/user</blockquote>\n` +
    `<blockquote>📋 .gikes group/.gikes user(reply pesan) → Copy teks ke semua grup/user</blockquote>\n` +
    `<blockquote>🚫 .addbl → Tambah grup ke blacklist</blockquote>\n` +
    `<blockquote>♻️ .deladdbl → Hapus grup dari blacklist</blockquote>\n` +
    `<blockquote>💥 .spam <jumlah> (reply) → Spam pesan</blockquote>`;
  await client.sendMessage(msg.chatId, {
    message: withFooter(msggrup),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
}

if (text === ".menutools") {
  if (msg.senderId.toString() !== myId) return;
  const msgtools =
    `<blockquote>「 FITUR TOOLS 」</blockquote>\n\n` +
    `<blockquote>🏓 .ping → Cek respon bot</blockquote>\n` +
    `<blockquote>📱 .id [username/reply] → Detail user</blockquote>\n` +
    `<blockquote>🎥 .tiktok <url> → Download TikTok</blockquote>\n` +
    `<blockquote>📝 .done → Format transaksi selesai</blockquote>\n` +
    `<blockquote>🔗 .tourl → Ubah Foto/Video Jadi Link</blockquote>\n` +
    `<blockquote>👥 .joingb → Otomatis Join Link Group</blockquote>\n` +
    `<blockquote>🧹 .cleargb → Otomatis Keluar Dari Group Telegram</blockquote>\n` +
    `<blockquote>✅ .save → Kirimkan Ke Chat Pribadi</blockquote>`;
  await client.sendMessage(msg.chatId, {
    message: withFooter(msgtools),
    replyTo: msg.id,
    parseMode: "html",
  });
  return;
  }
  }, new NewMessage({}));
})();