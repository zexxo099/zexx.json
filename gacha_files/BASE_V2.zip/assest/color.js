/*

 Base Sasuke Gen 7 Erlangga Official New Eraa!!🐉〽️
 Instagram : @errlngggaaa.rr
 Github : https://github.com/erlangga050809
 Telegram : t.me/langgxyz2
 
  ( don't delete the creator's name, please respect it!! )
  
            Kata Kata Hari Ini
      - "Bila kegagalan itu hujan, dan keberhasilan bagaikan matahari, maka butuh keduanya untuk melihat pelangi"
      
      - "Kesuksesan berawal dari misi dan tantangan, bukan berawal dari zona nyaman"
  
      ~Erlangga 12/04/2025
*/


const chalk = require('chalk')

const color = (text, color) => {
    return !color ? chalk.green(text) : chalk.keyword(color)(text)
}

const bgcolor = (text, bgcolor) => {
  return !bgcolor ? chalk.green(text) : chalk.bgKeyword(bgcolor)(text)
}

const Lognyong = (text, color) => {
  return !color ? chalk.yellow('[ ! ] ') + chalk.green(text) : chalk.yellow('=> ') + chalk.keyword(color)(text)
}

module.exports = {
  color,
  bgcolor,
  Lognyong
}
