import dotenv from 'dotenv';
dotenv.config();

export const config = {
  BOT_NAME: "Bot-Gacha-New",
  BOT_VERSION: "1.0 (Refactored Edition)",
  TELEGRAM_TOKEN: process.env.TELEGRAM_TOKEN,
  ADMIN_ID: process.env.ADMIN_ID,
  BOT_USERNAME: process.env.BOT_USERNAME,
  DEV_CONTACT: "t.me/AvailableNoName",

  GITHUB_TOKEN: process.env.GITHUB_TOKEN,
  REPO: process.env.GITHUB_REPO,
  BRANCH: process.env.GITHUB_BRANCH,

  TRIPAY_API_KEY: process.env.TRIPAY_API_KEY,
  TRIPAY_PRIVATE_KEY: process.env.TRIPAY_PRIVATE_KEY,
  TRIPAY_MERCHANT_CODE: process.env.TRIPAY_MERCHANT_CODE,

  DATA_FILES: {
    USERS: "data/users.json",
    GACHA_POOL: "data/gacha_pool.json",
    REDEEM_CODES: "data/redeem_codes.json",
    GACHA_UPLOADS: "gacha_files/",
  },

  GACHA_SETTINGS: {
    DEFAULT_LIMIT: 10,
    PREMIUM_LIMIT: 50,
    GROUP_BONUS_THRESHOLD: 50,
    GROUP_BONUS_AMOUNT: 5,
    PITY_THRESHOLD: 75, // Guarantee a rare/legendary after this many non-rare rolls
    WEIGHTS: {
      common: 70,
      rare: 25,
      legendary: 5,
    },
  },

  PREMIUM_PRICE: 50000,
  PREMIUM_DURATION_DAYS: 30,
};

export const EMOJI = {
    loading: ['⣾', '⣽', '⣻', '⢿', '⡿', '⣟', '⣯', '⣷'],
    success: '✅',
    error: '❌',
    admin: '👑',
    gacha: '🎰',
    money: '💰',
    stat: '📊',
    history: '📜',
    star: '⭐',
    gift: '🎁',
    info: 'ℹ️',
    users: '👥',
    broadcast: '📣',
    code: '🎟️',
};
