module.exports = {
  tokens: "7971018631:AAE5ZRUxT3am1Lo89VAeaRRiEHR61kb3_eo",  // Ubah Jadi Token Bot Mu !!!
  owner: "7901712927", // Ubah Jadi Id Mu !!!
  port: "2002", // Ubah Jadi Port Panel Mu !!!
  ipvps: "152.42.226.186" // Ubah Jadi Ip Vps Mu !!!
};