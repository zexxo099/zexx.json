/*
</> Script Vortunix Infinity Create Mt Band V1 Project </>
Developer : @GyzenVtx
Tiktok : tiktok.com/@gyzenisback_1
Chanel Telegram : https://t.me/+vrcjCorO1Hw0N2Q1
Chanel WhatsApp : https://whatsapp.com/channel/0029VbB1IchCcW4rWYFbwt1S

Note : Script Ini Dibagikan Free Oleh Gw ( @GyzenVtx ) Jadi Mohon Untuk Tidak Untuk Memperjual/Belilan Script Ini!! 
*/

const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require("form-data");

const bot = new Telegraf('8250159330:AAHl232ge27SHBgm0QJk_N5pCGbbW2bGoOQ'); // ganti sama token bot lo

// =============================== //
// Path file
// =============================== //
const promoFolder = path.join(__dirname, 'promosi');
const premiumFile = path.join(__dirname, 'premium.json');
const usersFile = path.join(__dirname, 'users.json');

// Owner ID
const OWNER_ID = 7557865171;

// =============================== //
// Fungsi helper
// =============================== //
function loadPremium() {
  if (!fs.existsSync(premiumFile)) fs.writeFileSync(premiumFile, '[]');
  return JSON.parse(fs.readFileSync(premiumFile));
}
function savePremium(data) {
  fs.writeFileSync(premiumFile, JSON.stringify(data, null, 2));
}

function loadUsers() {
  if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');
  return JSON.parse(fs.readFileSync(usersFile));
}
function saveUsers(data) {
  fs.writeFileSync(usersFile, JSON.stringify(data, null, 2));
}
function saveUserId(userId) {
  let users = loadUsers();
  if (!users.includes(userId)) {
    users.push(userId);
    saveUsers(users);
  }
}

// Ambil isi file promo sesuai nomor
function loadPromoFile(n) {
  const filePath = path.join(promoFolder, `promo${n}.txt`);
  if (!fs.existsSync(filePath)) return null;
  return fs.readFileSync(filePath, 'utf8');
}

// =============================== //
// Start
// =============================== //
bot.start(async ctx => {
  saveUserId(ctx.from.id);
  const chatId = ctx.chat.id;

  // Step 1: Animasi Loading Progress
  let total = 10;
  let barLength = 10;

  let animMsg = await ctx.reply("Loading Bot...\n[░░░░░░░░░░] 0%").catch(() => {});

  for (let i = 1; i <= total; i++) {
    let progress = i * (100 / total);
    let filled = "█".repeat(i);
    let empty = "░".repeat(barLength - i);
    let bar = `[${filled}${empty}] ${progress.toFixed(0)}%`;

    await new Promise(r => setTimeout(r, 300));
    await ctx.telegram.editMessageText(chatId, animMsg.message_id, null, `Loading Bot...\n${bar}`).catch(() => {});
  }

  // selesai
  await new Promise(r => setTimeout(r, 500));
  await ctx.telegram.editMessageText(chatId, animMsg.message_id, null, "Succes Loading Bot...").catch(() => {});

  await new Promise(r => setTimeout(r, 500));
  await ctx.deleteMessage(animMsg.message_id).catch(() => {});

  // Step 2: Menu utama (Foto + Caption + Button)
  await ctx.replyWithPhoto(
    { url: 'https://files.catbox.moe/peqs0h.jpg' }, // ganti link foto lo
    {
      caption: `- ( 👋 ) ${ctx.from.first_name || 'User'}! 
こんにちは私の名前は Vortunix Infinity です。私は Gyzen Official によって作られました。そして、あなたを危害から守り、WhatsApp のシステムを根絶する任務を与えられました。#マーク・ズプレク

# 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 𝗕𝗢𝗧
========================
⌬ Developer : @GyzenVtx
⌬ Botname : Vortunix CreatMt
⌬ Version : 1.0.0
⌬ Status : Vvip Buy Only!! 
========================
# 𝗖𝗔𝗠𝗠𝗔𝗡𝗗 𝗖𝗥𝗘𝗔𝗧𝗘 𝗠𝗧
========================
/createmt1 <slot> <link>
/createmt2 <slot> <link>
/createmt3 <slot> <link>
/createmt4 <slot> <link>
/createmt5 <slot> <link>
/createmt6 <slot> <link>
/createmt7 <slot> <link>
/createmt8 <slot> <link>
/createmt9 <slot> <link>
/createmt10 <slot> <link>
/createmt11 <slot> <link>
/createmt12 <slot> <link>
/createmt13 <slot> <link>
/createmt14 <slot> <link>
/createmt15 <slot> <link>
/createmt16 <slot> <link>
/createmt17 <slot> <link>
/createmt18 <slot> <link>
/createmt19 <slot> <link>
/createmt20 <slot> <link>
/createmt21 <slot> <link>
/createmt22 <slot> <link>
/createmt23 <slot> <link>
/createmt24 <slot> <link>
/createmt25 <slot> <link>
/createmt26 <slot> <link>
/createmt27 <slot> <link>
/createmt28 <slot> <link>
/createmt29 <slot> <link>
/createmt30 <slot> <link>
/createmt32 <slot> <link>
========================
# 𝗖𝗔𝗠𝗠𝗔𝗡𝗗 𝗙𝗨𝗡𝗡
========================
/tiktok
/tourl
/cekid
========================
# 𝗖𝗔𝗠𝗠𝗔𝗡𝗗 𝗢𝗪𝗡𝗘𝗥
========================
/addprem
/delprem
/pengumuman
========================
ℹ️ Ketik /tqto untuk liat TQTO`,
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.url('☀ Developer', 'https://t.me/GyzenVtx')],
        [Markup.button.url('⚡ Channel', 'https://t.me/+vrcjCorO1Hw0N2Q1')],
      ])
    }
  );
});

// =============================== //
// command about
// =============================== //
bot.command('tqto', ctx => {
  ctx.reply(
    `========================
# 𝗧𝗛𝗔𝗡𝗞𝗦 𝗧𝗢𝗢
========================
Gyzen Official ( Developer ) 
Orang Tua ( Suport ) 
Allah Swt ( My Good ) 
========================`,
    { parse_mode: 'Markdown' }
  );
});

// =============================== //
// createmt1 - createmt30
// =============================== //
for (let i = 1; i <= 30; i++) {
  bot.command(`createmt${i}`, ctx => {
    const userId = ctx.from.id;
    const premiumUsers = loadPremium();

    if (!premiumUsers.includes(userId)) {
      ctx.reply('❌ Kamu bukan user premium!');
      return;
    }

    const args = ctx.message.text.split(' ');
    if (args.length < 3) {
      ctx.reply(
        `❌ Format salah!\nContoh: /createmt${i} Zeus https://link.com`,
        { parse_mode: 'Markdown' }
      );
      return;
    }

    const slotName = args[1];
    const link = args[2];

    const template = loadPromoFile(i);
    if (!template) {
      ctx.reply(`⚠ File promo${i}.txt belum ada di folder promosi`);
      return;
    }

    let text = template
      .replace(/{slot}/gi, slotName)
      .replace(/{link}/gi, link);

    ctx.reply(text, { parse_mode: 'Markdown' });
  });
}

// =============================== //
// Premium Add/Del
// =============================== //
bot.command('addprem', ctx => {
  const userId = ctx.from.id;
  if (userId !== OWNER_ID) return ctx.reply('⚠ Kamu tidak punya izin.');

  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply('❌ Contoh: /addprem 123456');

  const idToAdd = parseInt(args[1]);
  const premiumUsers = loadPremium();

  if (!premiumUsers.includes(idToAdd)) {
    premiumUsers.push(idToAdd);
    savePremium(premiumUsers);
    ctx.reply(`✅ User ${idToAdd} ditambahkan ke premium.`);
  } else {
    ctx.reply(`⚠ User ${idToAdd} sudah premium.`);
  }
});

bot.command('delprem', ctx => {
  const userId = ctx.from.id;
  if (userId !== OWNER_ID) return ctx.reply('⚠ Kamu tidak punya izin.');

  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply('❌ Contoh: /delprem 123456');

  const idToRemove = parseInt(args[1]);
  let premiumUsers = loadPremium();

  if (premiumUsers.includes(idToRemove)) {
    premiumUsers = premiumUsers.filter(id => id !== idToRemove);
    savePremium(premiumUsers);
    ctx.reply(`🗑 User ${idToRemove} dihapus dari premium.`);
  } else {
    ctx.reply(`⚠ User ${idToRemove} tidak ada di daftar premium.`);
  }
});

// =============================== //
// Broadcast
// =============================== //
bot.command('pengumuman', async ctx => {
  const userId = ctx.from.id;
  if (userId !== OWNER_ID) return ctx.reply('⚠ Kamu tidak punya izin.');

  const message = ctx.message.text.split(' ').slice(1).join(' ');
  if (!message) return ctx.reply('❌ Contoh: /pengumuman Promo besar-besaran sekarang!');

  const users = loadUsers();
  let success = 0, fail = 0;

  for (const id of users) {
    try {
      await bot.telegram.sendMessage(
        id,
        `📢 *Pengumuman:*\n${message}`,
        { parse_mode: 'Markdown' }
      );
      success++;
    } catch {
      fail++;
    }
  }

  ctx.reply(`✅ Terkirim ke ${success} user.\n⚠ Gagal ke ${fail} user.`);
});

bot.command("tiktok", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) {
    return ctx.reply("📌 Contoh: /tiktok https://vt.tiktok.com/xxxx");
  }

  try {
    const api = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`;
    const res = await axios.get(api);
    const videoUrl = res.data.data.play;

    if (!videoUrl) return ctx.reply("❌ Gagal ambil video.");

    const filePath = "tiktok.mp4";
    const video = await axios.get(videoUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(filePath, video.data);

    await ctx.replyWithVideo({ source: filePath }, { caption: "✅ Nih videonya" });
    fs.unlinkSync(filePath); // hapus setelah dikirim
  } catch (err) {
    console.error(err);
    ctx.reply("❌ Error ambil video TikTok.");
  }
});

bot.command("tourl", async (ctx) => {
  try {
    const reply = ctx.message.reply_to_message;
    if (!reply) {
      return ctx.reply("Reply media (foto/video/dokumen) dulu pake /tourl");
    }

    let fileId;

    if (reply.photo) {
      // Foto (ambil resolusi terbesar)
      fileId = reply.photo.slice(-1)[0].file_id;
    } else if (reply.video) {
      // Video
      fileId = reply.video.file_id;
    } else if (reply.document) {
      // Dokumen (misalnya zip, pdf, mp4, dll)
      fileId = reply.document.file_id;
    } else {
      return ctx.reply("Media tidak didukung. Coba reply foto/video/dokumen.");
    }

    // Ambil link file dari Telegram
    const fileLink = await ctx.telegram.getFileLink(fileId);

    // Upload ke Catbox
    const form = new FormData();
    form.append("reqtype", "urlupload");
    form.append("userhash", "");
    form.append("url", fileLink.href);

    const upload = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders(),
    });

    ctx.reply(`✅ Media berhasil diupload:\n${upload.data}`);
  } catch (e) {
    console.error(e);
    ctx.reply("❌ Gagal upload ke Catbox.");
  }
});

bot.command("cekid", async (ctx) => {
  try {
    const args = ctx.message.text.split(" ").slice(1);
    let target, nama, username, id;

    if (args[0] === "gc") {
      target = ctx.chat;
      nama = target.title;
      username = target.username ? `@${target.username}` : "-";
      id = target.id;
    } else if (ctx.message.reply_to_message) {
      target = ctx.message.reply_to_message.from;
      nama = target.first_name;
      username = target.username ? `@${target.username}` : "-";
      id = target.id;
    } else if (args[0]) {
      const user = await ctx.telegram.getChat(args[0]);
      nama = user.first_name || user.title;
      username = user.username ? `@${user.username}` : "-";
      id = user.id;
    } else {
      target = ctx.from;
      nama = target.first_name;
      username = target.username ? `@${target.username}` : "-";
      id = target.id;
    }

    await ctx.reply(
`╭────⟡
│ 👤 Nama: ${nama}
│ 🆔 ID: ${id}
│ 🔗 Username: ${username}
╰────⟡`
    );
  } catch (e) {
    ctx.reply("❌sementara bot akan segera di fix❌");
  }
});
// =============================== //
// Run
// =============================== //
bot.launch();
console.log('🤖 Bot berjalan...');