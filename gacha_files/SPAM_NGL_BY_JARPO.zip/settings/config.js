module.exports = {
    BOT_TOKEN: '7966549991:AAHLqDMUExF2XZhG_wIJzlRwIA7iEzjv9Fc'
};