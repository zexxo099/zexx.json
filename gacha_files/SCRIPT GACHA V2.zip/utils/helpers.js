import { Markup } from 'telegraf';
import { EMOJI } from '../config.js';

export async function animateMessage(ctx, messageId, baseText, duration = 2000) {
    let frame = 0;
    const interval = setInterval(() => {
        const text = `\`${EMOJI.loading[frame]}\` ${baseText}`;
        ctx.telegram.editMessageText(ctx.chat.id, messageId, null, text, { parse_mode: 'Markdown' })
           .catch(() => clearInterval(interval));
        frame = (frame + 1) % EMOJI.loading.length;
    }, 150);

    return new Promise(resolve => setTimeout(() => {
        clearInterval(interval);
        resolve(interval);
    }, duration));
}

export function formatBox(title, content) {
    const lines = content.split('\n');
    const fullTitle = ` ${title} `;
    const maxWidth = Math.max(...lines.map(l => l.length), fullTitle.length);
    const border = '─'.repeat(maxWidth + 2);
    const top = `┌${border}┐`;
    const bottom = `└${border}┘`;
    
    const titleLine = `│ ${fullTitle.padEnd(maxWidth, ' ')} │`;
    const paddedLines = lines.map(line => `│ ${line.padEnd(maxWidth, ' ')} │`);
    
    return `\`\`\`\n${top}\n${titleLine}\n${paddedLines.join('\n')}\n${bottom}\n\`\`\``;
}

export const keyboards = {
    main: Markup.inlineKeyboard([
        [Markup.button.callback(`${EMOJI.gacha} Gacha!`, 'gacha:roll')],
        [Markup.button.callback(`${EMOJI.stat} Statistik Saya`, 'user:stats'), Markup.button.callback(`${EMOJI.history} Riwayat`, 'user:history')],
        [Markup.button.callback(`${EMOJI.gift} Bonus Harian`, 'user:daily'), Markup.button.callback(`${EMOJI.code} Redeem Kode`, 'user:redeem')],
        [Markup.button.callback(`${EMOJI.money} Beli Premium`, 'premium:buy')],
        [Markup.button.callback(`${EMOJI.info} Hubungi Dev`, 'user:contact')],
    ]),
    admin: Markup.inlineKeyboard([
        [Markup.button.callback(`${EMOJI.broadcast} Broadcast`, 'admin:broadcast'), Markup.button.callback(`${EMOJI.users} Cek User`, 'admin:user_info')],
        [Markup.button.callback('➕ Tambah Item Gacha', 'admin:add_item'), Markup.button.callback('➖ Hapus Item Gacha', 'admin:del_item')],
        [Markup.button.callback(`${EMOJI.code} Buat Kode Redeem`, 'admin:gen_code')],
        [Markup.button.callback('🔄 Reload Data', 'admin:reload')],
    ])
};
