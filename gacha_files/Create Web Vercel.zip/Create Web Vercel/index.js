const { Telegraf, Markup } = require('telegraf');
const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const AdmZip = require('adm-zip');
const config = require('./config');

const bot = new Telegraf(config.BOT_TOKEN);

// Database & State Management
const users = new Map();
const userStates = new Map(); 

const createMainMenu = (ctx) => ({
    caption: `
<blockquote>
<b>🚀 Bot Deployment Vercel 🚀</b>
Oleh: <b>Aldo+XVCT</b>

Selamat datang, <b>${ctx.from.first_name}</b>!
Bot ini siap mengubah kodemu menjadi website live.

Pilih metode deploy di bawah ini:</blockquote>`,
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
        [
            Markup.button.callback('📦 Deploy dari ZIP', 'deploy_zip'),
            Markup.button.callback('🌐 Deploy dari GitHub', 'deploy_github')
        ],
        [Markup.button.callback('📂 Proyek Saya', 'my_projects')],
        [Markup.button.callback('👨‍💻 Developer', 'developer_info')]
    ])
});

bot.start(async (ctx) => {
    const userId = ctx.from.id;
    if (!users.has(userId)) {
        users.set(userId, {
            id: userId,
            username: ctx.from.username,
            deployedProjects: []
        });
    }
    await ctx.replyWithPhoto(config.THUMBNAIL_URL, createMainMenu(ctx));
});

bot.action('back_to_menu', async (ctx) => {
    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: config.THUMBNAIL_URL,
        }, createMainMenu(ctx));
    } catch (e) {
        await ctx.replyWithPhoto(config.THUMBNAIL_URL, createMainMenu(ctx));
        await ctx.deleteMessage();
    }
    await ctx.answerCbQuery();
});

bot.action('deploy_zip', async (ctx) => {
    await ctx.editMessageCaption(`
<blockquote>
<b>📦 Deploy dari File .zip</b>

1. Siapkan proyek Anda (HTML, CSS, JS) dalam satu file <code>.zip</code>.
2. Pastikan ada file <code>index.html</code>.
3. Reply pesan ini dengan file <code>.zip</code> tersebut, lalu ketik command /createweb</blockquote>`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('Kembali', 'back_to_menu')]])
    });
});

bot.action('deploy_github', async (ctx) => {
    userStates.set(ctx.from.id, 'awaiting_github_url');
    await ctx.editMessageCaption(`
<blockquote>
<b>🌐 Deploy dari GitHub</b>

Kirimkan URL repository <b>publik</b> GitHub Anda.

Contoh:
<code>https://github.com/username/nama-repo</code></blockquote>`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('Batal', 'back_to_menu')]])
    });
});

bot.action('my_projects', async (ctx) => {
    const user = users.get(ctx.from.id);
    if (!user || user.deployedProjects.length === 0) {
        await ctx.answerCbQuery('Anda belum mendeploy proyek apapun.', { show_alert: true });
        return;
    }

    let message = '<blockquote><b>📂 Proyek yang Telah Anda Deploy</b>\n\n';
    user.deployedProjects.slice(-5).reverse().forEach((p, i) => {
        message += `${i + 1}. <b>${p.name}</b>\n   <code>${p.url}</code>\n`;
    });
    message += '</blockquote>';

    await ctx.editMessageCaption(message, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('Kembali', 'back_to_menu')]])
    });
});

bot.command('myprojects', (ctx) => ctx.telegram.sendMessage(ctx.chat.id, "Silakan gunakan tombol 'Proyek Saya' di menu utama."));

const deployFromGit = async (ctx, url) => {
    const urlPattern = /https?:\/\/github\.com\/([^\/]+)\/([^\/]+)(\.git)?/;
    const match = url.match(urlPattern);
    if (!match) {
        return ctx.reply('❌ URL GitHub tidak valid. Pastikan formatnya benar.');
    }
    const repo = `${match[1]}/${match[2]}`;
    const processingMsg = await ctx.reply('🚀 Memulai deploy dari GitHub...');

    try {
        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, undefined, '🔍 Menghubungkan ke repository...');
        const payload = {
            name: repo.split('/')[1],
            gitSource: {
                type: 'github',
                repo,
                ref: 'main', // atau 'master', sesuaikan dengan default branch
            }
        };
        if (config.VERCEL_TEAM_ID) payload.teamId = config.VERCEL_TEAM_ID;

        const deployResponse = await axios.post('https://api.vercel.com/v13/deployments', payload, {
            headers: { 'Authorization': `Bearer ${config.VERCEL_TOKEN}` }
        });
        
        const deploymentUrl = `https://${deployResponse.data.url}`;
        const user = users.get(ctx.from.id);
        user?.deployedProjects.push({ name: repo, url: deploymentUrl, date: new Date() });

        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, undefined,
            `<blockquote><b>✅ Deploy Berhasil!</b>\n\nRepositori <code>${repo}</code> berhasil di-deploy.\n\n🌐 <b>URL:</b> <code>${deploymentUrl}</code></blockquote>`, {
            parse_mode: 'HTML',
            ...Markup.inlineKeyboard([
                [Markup.button.url('🚀 Buka Website', deploymentUrl)],
                [Markup.button.callback('📋 Salin URL', `copy_url|${deploymentUrl}`)],
                [Markup.button.callback('Kembali ke Menu', 'back_to_menu')]
            ])
        });

    } catch (error) {
        console.error('Git Deploy Error:', error.response ? error.response.data : error.message);
        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, undefined, '❌ Gagal deploy. Pastikan repository publik dan token Vercel valid.');
    }
};

bot.on('text', async (ctx, next) => {
    if (userStates.get(ctx.from.id) === 'awaiting_github_url') {
        userStates.delete(ctx.from.id);
        await deployFromGit(ctx, ctx.message.text);
    } else {
        return next();
    }
});

const deployFromZip = async (ctx, file) => {
    if (!file.file_name.endsWith('.zip')) {
        return ctx.reply('❌ Hanya file `.zip` yang didukung untuk metode ini.');
    }

    const tempDir = path.join(__dirname, 'temp', `${ctx.from.id}_${Date.now()}`);
    const zipPath = path.join(tempDir, file.file_name);
    const extractPath = path.join(tempDir, 'extracted');
    let processingMsg;

    try {
        processingMsg = await ctx.reply('🚀 Memulai proses deploy...');
        await fs.ensureDir(tempDir);
        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, undefined, '📥 Mengunduh file...');
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        const response = await axios.get(fileLink.href, { responseType: 'stream' });
        const writer = fs.createWriteStream(zipPath);
        response.data.pipe(writer);
        await new Promise((resolve, reject) => { writer.on('finish', resolve); writer.on('error', reject); });

        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, undefined, '📦 Mengekstrak arsip...');
        const zip = new AdmZip(zipPath);
        zip.extractAllTo(extractPath, true);

        const getFiles = async (dir) => {
            const dirents = await fs.readdir(dir, { withFileTypes: true });
            const files = await Promise.all(dirents.map(async (dirent) => {
                const res = path.resolve(dir, dirent.name);
                const relativePath = path.relative(extractPath, res).replace(/\\/g, '/');
                return dirent.isDirectory() ? getFiles(res) : {
                    file: relativePath,
                    data: await fs.readFile(res)
                };
            }));
            return Array.prototype.concat(...files);
        };

        const fileList = await getFiles(extractPath);
        if (!fileList.some(f => f.file.includes('.html'))) {
            throw new Error('Arsip .zip tidak mengandung file .html apapun.');
        }

        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, undefined, '☁️ Mengunggah ke Vercel...');
        const payload = {
            name: `zip-deploy-${ctx.from.id}`,
            files: fileList,
        };
        if (config.VERCEL_TEAM_ID) payload.teamId = config.VERCEL_TEAM_ID;
        
        const deployResponse = await axios.post('https://api.vercel.com/v13/deployments', payload, {
            headers: { 'Authorization': `Bearer ${config.VERCEL_TOKEN}` },
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
        });

        const deploymentUrl = `https://${deployResponse.data.url}`;
        const user = users.get(ctx.from.id);
        user?.deployedProjects.push({ name: file.file_name.replace('.zip', ''), url: deploymentUrl, date: new Date() });

        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg.message_id, undefined,
            `<blockquote><b>✅ Deploy Berhasil!</b>\n\nProyek <code>${file.file_name}</code> berhasil di-deploy.\n\n🌐 <b>URL:</b> <code>${deploymentUrl}</code></blockquote>`, {
            parse_mode: 'HTML',
            ...Markup.inlineKeyboard([
                [Markup.button.url('🚀 Buka Website', deploymentUrl)],
                [Markup.button.callback('📋 Salin URL', `copy_url|${deploymentUrl}`)],
                [Markup.button.callback('Kembali ke Menu', 'back_to_menu')]
            ])
        });

    } catch (error) {
        console.error('ZIP Deploy Error:', error.response ? error.response.data : error.message);
        await ctx.telegram.editMessageText(ctx.chat.id, processingMsg?.message_id, undefined, `❌ Gagal deploy. ${error.message}`);
    } finally {
        await fs.remove(tempDir);
    }
};

bot.command('createweb', (ctx) => {
    const repliedMessage = ctx.message.reply_to_message;
    if (!repliedMessage || !repliedMessage.document) {
        return ctx.reply('❌ Perintah Salah! Harap reply file `.zip` dengan command ini.');
    }
    deployFromZip(ctx, repliedMessage.document);
});

bot.action(/copy_url\|(.+)/, (ctx) => {
    const url = ctx.match[1];
    ctx.reply(`<code>${url}</code>`, { parse_mode: 'HTML' });
    ctx.answerCbQuery('URL siap disalin!');
});

bot.action('developer_info', async (ctx) => {
    await ctx.editMessageCaption(
    `<blockquote><b>👨‍💻 Informasi Developer 👨‍💻</b>
Bot ini dikembangkan oleh <b>Aldo+XVCT</b>
Terinspirasi untuk membuat bot yang mempermudah proses deployment.

<b>Framework:</b> Telegraf.js
<b>Platform:</b> Vercel</blockquote>`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('Kembali', 'back_to_menu')]])
    });
});

bot.catch((err, ctx) => {
    console.error(`Error untuk ${ctx.updateType}:`, err);
    ctx.reply('❌ Terjadi kesalahan tak terduga. Tim developer sudah diberitahu.');
});

bot.launch().then(() => {
    console.log('Bot by Aldo+XVCT started successfully!');
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
