import fetch from 'node-fetch';
import { Buffer } from 'buffer';
import { config } from '../config.js';

const GITHUB_API_BASE = `https://api.github.com/repos/${config.REPO}/contents`;
const GITHUB_RAW_BASE = `https://raw.githubusercontent.com/${config.REPO}/${config.BRANCH}`;

const GITHUB_HEADERS = {
    'Authorization': `token ${config.GITHUB_TOKEN}`,
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': `Telegraf-${config.BOT_NAME}`
};

async function getFileSha(filePath) {
    try {
        const response = await fetch(`${GITHUB_API_BASE}/${filePath}?ref=${config.BRANCH}`, { headers: GITHUB_HEADERS });
        if (response.status === 404) return null;
        if (!response.ok) throw new Error(`GitHub API error: ${response.statusText}`);
        const data = await response.json();
        return data.sha;
    } catch (error) {
        console.error(`Error getting file SHA for ${filePath}:`, error);
        return null;
    }
}

export async function getFileContent(filePath) {
    try {
        const response = await fetch(`${GITHUB_RAW_BASE}/${filePath}?timestamp=${Date.now()}`, { headers: GITHUB_HEADERS });
        if (response.status === 404) return null;
        if (!response.ok) throw new Error(`GitHub Raw API error: ${response.statusText}`);
        return await response.json();
    } catch (error) {
        console.error(`Error getting file content for ${filePath}:`, error);
        return null;
    }
}

/**
 * Creates a new file or updates an existing one in the GitHub repository.
 * @param {string} filePath The path to the file in the repository.
 * @param {object|string} content The content to write to the file.
 * @param {string} commitMessage A descriptive commit message.
 */
export async function createOrUpdateFile(filePath, content, commitMessage) {
    const sha = await getFileSha(filePath);
    const contentString = typeof content === 'object' ? JSON.stringify(content, null, 2) : content;
    const base64Content = Buffer.from(contentString).toString('base64');

    const body = {
        message: commitMessage,
        content: base64Content,
        branch: config.BRANCH
    };
    if (sha) body.sha = sha;

    const response = await fetch(`${GITHUB_API_BASE}/${filePath}`, {
        method: 'PUT',
        headers: { ...GITHUB_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`GitHub API error on updating ${filePath}: ${errorData.message}`);
    }
}

/**
 * Uploads a file buffer to GitHub.
 * @param {Buffer} fileBuffer The file content as a buffer.
 * @param {string} remotePath The destination path in the repository.
 * @returns {Promise<{download_url: string}>} Object containing the raw download URL.
 */
export async function uploadFile(fileBuffer, remotePath) {
    const sha = await getFileSha(remotePath);
    const base64Content = fileBuffer.toString('base64');

    const body = {
        message: `[BOT] Upload file: ${remotePath.split('/').pop()}`,
        content: base64Content,
        branch: config.BRANCH
    };
    if (sha) body.sha = sha;

    const response = await fetch(`${GITHUB_API_BASE}/${remotePath}`, {
        method: 'PUT',
        headers: { ...GITHUB_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`GitHub file upload error: ${errorData.message}`);
    }
    
    return { download_url: `${GITHUB_RAW_BASE}/${remotePath}` };
}
