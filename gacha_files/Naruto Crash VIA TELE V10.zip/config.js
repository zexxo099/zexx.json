module.exports = {
  BOT_TOKEN: '8268875439:AAFtq5cPxU58rbUd4julTxkWycOZR2r-4Zc', 
  OWNER_ID: ['7895033118']
};
