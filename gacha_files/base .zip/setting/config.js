module.exports = {
  BOT_TOKEN: "", // isi token bot lu
};