module.exports = {
  // Token bot Anda dari @BotFather di Telegram
  BOT_TOKEN: 'ISI_DENGAN_TOKEN_BOT_ANDA',

  // Token API dari akun Vercel Anda.
  // Buka Vercel > Settings > Tokens > Create.
  VERCEL_TOKEN: 'ISI_DENGAN_TOKEN_VERCEL_ANDA',

  // (Opsional) Team ID Vercel Anda jika proyek dideploy di bawah tim.
  // Buka Vercel > Pilih Tim > Settings > General > Salin Team ID.
  // Kosongkan jika Anda menggunakan akun personal: ''
  VERCEL_TEAM_ID: 'ISI_DENGAN_TEAM_ID_JIKA_ADA',

  // URL gambar thumbnail yang akan muncul di menu utama.
  // Cari gambar di Telegram, klik kanan, salin link gambar.
  THUMBNAIL_URL: 'https://telegra.ph/file/18725f16e3c5b4e7b8f95.jpg',

  // Username Telegram Anda untuk halaman info developer.
  DEVELOPER_USERNAME: '@username_anda'
};
