/*
DI EDIT ULANG BY IFAA X RAHMAN
*/
exports.first_chat = "Hello"
