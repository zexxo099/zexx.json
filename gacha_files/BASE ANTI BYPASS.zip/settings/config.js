module.exports = {
  tokenBot: "TOKEN_BOT",
  ownerID: "ID_OWNER",
};