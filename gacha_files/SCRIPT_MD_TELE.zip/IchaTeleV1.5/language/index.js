/*
DI EDIT ULANG BY IFAA X RAHMAN
*/
exports.indonesia = require('./indonesia')
exports.english = require('./english')
