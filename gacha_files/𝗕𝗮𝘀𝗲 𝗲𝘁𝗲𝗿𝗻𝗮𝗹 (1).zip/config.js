module.exports = {
  BOT_TOKEN: "7228212153:AAEZemtuvUX8f9HBbdLFyq4I-B_IwnfysGY",
    allowedDevelopers: ['7681171661'], // ID
};