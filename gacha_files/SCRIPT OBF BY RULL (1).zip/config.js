// config.js
//Welcome obf by rull 
module.exports = {
    BOT_TOKEN: "token", 
    ADMIN_ID: 7612475043  
};