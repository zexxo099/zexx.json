/*
Base Ori Rendzz cukimai

SETTINGS COMMAND IN @BotFather
menu - Menu
runtime - Speed runtime
cekid - Cek id user
status - Status Premium
listram - List Ram
domainmenu - Domain Menu
privacy - Keamanan pengguna Bot

Note : don't remove copyright of this script!
*/
const fs = require("fs");
const chalk = require('chalk')
const {
   indonesia
} = require("./language");

//language 
global.language = indonesia //change indonesia to english if you don't understand the language used by the bot
//Simbol YT
global.simbolYT = "📁"
global.userTelelu = "rendczx"


global.BOT_TOKEN = "8430114704:AAEFrWdf7L-7GRXNlC5ugUyLBp7U3Zs35XE" // buat bot di sini https://t.me/Botfather dan dapatkan token bot
global.apikey = "cad9fc6564a1390bba34fb5f" // CREATE API LOLHUMAN PAKAI APIKEY SENDIRI YY
global.BOT_NAME = "Rendzz Bots" //your bot name
global.OWNER_NAME = "Rendzz Bots" //your name
global.OWNER_NUMBER = "l" //your telegram number
global.OWNER = ["https://t.me/rendzzxchz"] // pastikan username sudah sesuai agar fitur khusus owner bisa di pakai
global.OWNERID = "8106553511" // Change your owner id, btw jgn di apus ntr error
global.owneridlu = "8106553511" // Change your owner id
global.pp = "./image/ifaaja.jpg" // ini lol.jpg adalah nama foto di folder image. untuk foto bot
// SETTING LAINNYA
global.linkGrup = "https://t.me/" // taroh link tele lu disini
global.linkCh = "https://t.me/" // taroh link ch lu disini
global.linkLuu = "https://t.me/" // taroh link lu yang asli
// Name Grup Anda atau grup lain
global.setName1 = "Rendzz Bots" // SETNAME1 / LINK GRUP
global.setName2 = "Rendzz Bots" // SETNAME2 / LINK CH
global.setName3 = "Rendzz Bots" // SETNAME3 / LINK LUU
// TAMAT🗿
global.DONASI = false // "./image/donasi.jpg" // foto donasi di folder image
global.lang = language
    //SERVER 1
  global.domain = '', // ISI DOMAIN LU SAT 
  global.plta = 'ptla_G9d7meYAT58RvLnn2jFRB5s2CjB0URMJDJjZNIHW92f', // Isi dengan nilai plta yang sesuai
  global.pltc = 'ptlc_CIjBtmICZNSGe6jHnWHXX8K92NMXn5EC5EXuFT5Ve1W', // Isi dengan nilai pltc yang sesuai
  
  //CREATE PANEL
  global.loc = '1', // Isi dengan lokasi yang diinginkan
  global.eggs = '15'
  
  //=========== Api Domain ===========//
global.zone1 = "f43ae9a651f02649a55eb57e1f3611ba"
global.apitoken1 = "nNCbqQwR2Sn13XBCaqq4L1I6Gz_f1R-37YbgZyAB"
global.tld1 = "aar-offc.web.id"

//========== Api Domain 2 ==========//
global.zone2 = "475b59feb30ac9ab490eb78d4e9b32a3";
global.apitoken2 = "nNCbqQwR2Sn13XBCaqq4L1I6Gz_f1R-37YbgZyAB";
global.tld2 = "risma.web.id";
//========== Api Domain 3 ==========//
global.zone3 = "5304c3b0f9c6ef463b15e53fa0f528b6";
global.apitoken3 = "nNCbqQwR2Sn13XBCaqq4L1I6Gz_f1R-37YbgZyAB";
global.tld3 = "idstore74.pw";
//========== Api Domain 4 ==========//
global.zone4 = "d41a17e101c0f89f0aec609c31137f91";
global.apitoken4 = "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi";
global.tld4 = "panellstore.net";
//========== Api Domain 5 ==========//
global.zone5 = "d41a17e101c0f89f0aec609c31137f91";
global.apitoken5 = "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi";
global.tld5 = "panellstore.net";
//━━━━━━━━━━━━━━━[ BATAS SETTING ]━━━━━━━━━━━━━━━━━//
  
  
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})