/*
Script Create By Jarpo Jawanice
- https://t.me/jarpoae -
- NodeJS 18 -
- Gunakan dengan bijak -
*/
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const config = require('./settings/config');

const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });

function XemzzsendMenu(chatId) {
    const fotoUrl = 'https://files.catbox.moe/95bsuf.jpg';
    
    const menuText = 
`<blockquote>┏━━〘 TENTANG 〙
┃ ▢ Author : @Jarpoae
┃ ▢ Version : 1.0
┕━━━━━━━━━━━━━━━━━━━
┏━━〔 TOOLS 〕
╽ ▢ /ngl &lt;link-ngl&gt; &lt;total pesan&gt; (balas teks)
┕━━━━━━━━━━━━━━━━━━━</blockquote>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: "DEVELOPER", url: "https://t.me/jarpoae" }]
            ]
        }
    };

    bot.sendPhoto(chatId, fotoUrl, {
        caption: menuText,
        parse_mode: 'HTML',
        reply_markup: keyboard.reply_markup
    }).catch(error => {
        console.log('Error mengirim foto:', error.message);
        bot.sendMessage(chatId, menuText, {
            parse_mode: 'HTML',
            reply_markup: keyboard.reply_markup
        });
    });
}

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    XemzzsendMenu(chatId);
});

bot.onText(/\/ngl (.+) (\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const nglLink = match[1].trim();
    const totalPesan = parseInt(match[2]);

    if (totalPesan > 100) {
        return bot.sendMessage(chatId, '<blockquote>❌ Maksimal pesan untuk NGL adalah 100 pesan!</blockquote>', {
            parse_mode: 'HTML'
        });
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '<blockquote>❌ Silakan reply pesan yang ingin dikirim ke NGL!</blockquote>', {
            parse_mode: 'HTML'
        });
    }

    const messageText = msg.reply_to_message.text || msg.reply_to_message.caption || '';
    
    if (!messageText) {
        return bot.sendMessage(chatId, '<blockquote>❌ Pesan yang di-reply tidak mengandung teks!</blockquote>', {
            parse_mode: 'HTML'
        });
    }

    let nglUsername;
    try {
        const url = new URL(nglLink);
        nglUsername = url.pathname.split('/').filter(part => part.length > 0)[0];
    } catch (error) {
        nglUsername = nglLink.replace(/^@/, '');
    }

    if (!nglUsername) {
        return bot.sendMessage(chatId, '<blockquote>❌ Format link NGL tidak valid!\nContoh: /ngl https://ngl.link/username 10</blockquote>', {
            parse_mode: 'HTML'
        });
    }

    try {
        bot.sendMessage(chatId, `<blockquote>🚀 Memulai mengirim ${totalPesan} pesan anonim ke ${nglUsername}...</blockquote>`, {
            parse_mode: 'HTML'
        });

        let successCount = 0;
        let failedCount = 0;

        for (let i = 1; i <= totalPesan; i++) {
            try {
                const response = await axios.post(`https://ngl.link/api/submit`, {
                    username: nglUsername,
                    question: messageText,
                    deviceId: XemzzgenerateDeviceId(),
                    gameSlug: '',
                    referrer: ''
                }, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'Origin': 'https://ngl.link',
                        'Referer': `https://ngl.link/${nglUsername}`,
                        'Sec-Fetch-Dest': 'empty',
                        'Sec-Fetch-Mode': 'cors',
                        'Sec-Fetch-Site': 'same-origin'
                    },
                    timeout: 10000
                });

                if (response.status === 200) {
                    successCount++;
                    bot.sendMessage(chatId, `<blockquote>✅ Pesan ${i}/${totalPesan} berhasil dikirim!</blockquote>`, {
                        parse_mode: 'HTML'
                    });
                } else {
                    failedCount++;
                    bot.sendMessage(chatId, `<blockquote>❌ Pesan ${i}/${totalPesan} gagal dikirim!</blockquote>`, {
                        parse_mode: 'HTML'
                    });
                }

                const delay = Math.floor(Math.random() * 3000) + 2000;
                await new Promise(resolve => setTimeout(resolve, delay));

            } catch (error) {
                failedCount++;
                console.error(`Error mengirim pesan ${i}:`, error.message);
                
                if (error.response && error.response.status === 404) {
                    bot.sendMessage(chatId, `<blockquote>❌ Username "${nglUsername}" tidak ditemukan di NGL!</blockquote>`, {
                        parse_mode: 'HTML'
                    });
                    break;
                } else if (error.response && error.response.status === 429) {
                    bot.sendMessage(chatId, `<blockquote>⏳ Terlalu banyak request, tunggu beberapa saat...</blockquote>`, {
                        parse_mode: 'HTML'
                    });
                    await new Promise(resolve => setTimeout(resolve, 10000));
                }
            }
        }

        const resultText = 
`<blockquote>📊 HASIL PENGIRIMAN NGL

👤 Target: ${nglUsername}
📨 Total pesan: ${totalPesan}
✅ Berhasil: ${successCount}
❌ Gagal: ${failedCount}
📊 Success Rate: ${((successCount / totalPesan) * 100).toFixed(1)}%</blockquote>`;

        bot.sendMessage(chatId, resultText, { parse_mode: 'HTML' });

    } catch (error) {
        console.error('Error NGL:', error);
        bot.sendMessage(chatId, `<blockquote>❌ Error: ${error.message}</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
});

function XemzzgenerateDeviceId() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let deviceId = '';
    for (let i = 0; i < 16; i++) {
        deviceId += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return deviceId;
}

bot.on('message', (msg) => {
    if (msg.text && !msg.text.startsWith('/')) {
        XemzzsendMenu(msg.chat.id);
    }
});

bot.on('error', (error) => {
    console.error('Bot error:', error);
});

console.log('SAMPUN YAK');