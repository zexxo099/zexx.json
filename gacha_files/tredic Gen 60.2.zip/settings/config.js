module.exports = {
  tokenBot: "7946667658:AAFxxTD7gD08KhAk6HJRep55QtJ-TLgM3qI",
  ownerID: "OWNER_ID"
};