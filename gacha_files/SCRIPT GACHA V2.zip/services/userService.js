import { createOrUpdateFile, getFileContent } from '../utils/github.js';
import { config } from '../config.js';
import crypto from 'crypto';

let usersCache = {};
let redeemCodesCache = {};
let totalGroups = 0;

/**
 * Loads all user, group, and redeem code data from GitHub.
 */
export async function loadAllData() {
    console.log('[DATA] Loading all user and code data from GitHub...');
    const usersData = await getFileContent(config.DATA_FILES.USERS) || {};
    const codesData = await getFileContent(config.DATA_FILES.REDEEM_CODES) || {};
    
    usersCache = usersData.users || {};
    totalGroups = usersData.totalGroups || 0;
    redeemCodesCache = codesData.codes || {};
    
    console.log(`[DATA] Loaded ${Object.keys(usersCache).length} users and ${Object.keys(redeemCodesCache).length} redeem codes.`);
}

/**
 * Saves the current user data cache to GitHub.
 * @param {string} commitMessage A descriptive commit message.
 */
async function saveUsers(commitMessage) {
    const data = {
        last_updated: new Date().toISOString(),
        totalGroups: totalGroups,
        users: usersCache
    };
    await createOrUpdateFile(config.DATA_FILES.USERS, data, `[BOT] ${commitMessage}`);
}

/**
 * Saves the current redeem code cache to GitHub.
 * @param {string} commitMessage A descriptive commit message.
 */
async function saveRedeemCodes(commitMessage) {
    const data = {
        last_updated: new Date().toISOString(),
        codes: redeemCodesCache
    };
    await createOrUpdateFile(config.DATA_FILES.REDEEM_CODES, data, `[BOT] ${commitMessage}`);
}

/**
 * Retrieves a user's data, creating it if it doesn't exist. Also handles daily resets.
 * @param {number} userId The user's Telegram ID.
 * @param {string} username The user's username.
 * @returns {object} The user data object.
 */
export function getUser(userId, username = 'N/A') {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    let isNewUser = false;

    if (!usersCache[userId]) {
        isNewUser = true;
        usersCache[userId] = {
            id: userId,
            username: username,
            is_premium: false,
            premium_expires: null,
            gacha_count: 0,
            gacha_limit: config.GACHA_SETTINGS.DEFAULT_LIMIT,
            bonus_gacha: 0,
            gacha_history: [],
            total_gacha_lifetime: 0,
            rare_drops_count: 0,
            pity_counter: 0,
            last_gacha_reset: today,
            last_daily_claim: null,
            invited_by: null,
            referrals: 0,
        };
    }
    
    const user = usersCache[userId];
    user.username = username; // Always update username

    // Daily reset logic
    if (user.last_gacha_reset !== today) {
        user.last_gacha_reset = today;
        user.gacha_count = 0;
        user.pity_counter = 0;
    }
    
    // Premium status check
    if (user.is_premium && user.premium_expires && new Date(user.premium_expires) < now) {
        user.is_premium = false;
        user.premium_expires = null;
        user.gacha_limit = config.GACHA_SETTINGS.DEFAULT_LIMIT;
    }

    if (isNewUser) {
        saveUsers(`New user joined: ${userId}`);
    }

    return user;
}

/**
 * Finds a user by their username (case-insensitive).
 * @param {string} username The username to search for.
 * @returns {object|null} The user object or null if not found.
 */
export function findUserByUsername(username) {
    const lowerCaseUsername = username.toLowerCase().replace('@', '');
    for (const id in usersCache) {
        if (usersCache[id].username?.toLowerCase() === lowerCaseUsername) {
            return usersCache[id];
        }
    }
    return null;
}

/**
 * Generates a new redeem code.
 * @param {string} type The type of reward ('premium' or 'bonus').
 * @param {number} value The value (days for premium, amount for bonus).
 * @param {number} uses The number of times the code can be used.
 * @returns {string} The generated code.
 */
export function generateRedeemCode(type, value, uses) {
    const code = `XVCT-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    redeemCodesCache[code] = {
        type: type,
        value: value,
        max_uses: uses,
        used_by: [],
    };
    saveRedeemCodes(`Generated new code: ${code}`);
    return code;
}

/**
 * Attempts to redeem a code for a user.
 * @param {number} userId The user's ID.
 * @param {string} code The redeem code.
 * @returns {{success: boolean, message: string}} The result of the redemption.
 */
export function redeemCode(userId, code) {
    const codeData = redeemCodesCache[code];
    if (!codeData) {
        return { success: false, message: 'Kode tidak valid atau tidak ditemukan.' };
    }
    if (codeData.used_by.length >= codeData.max_uses) {
        return { success: false, message: 'Kode ini sudah habis batas pemakaiannya.' };
    }
    if (codeData.used_by.includes(userId)) {
        return { success: false, message: 'Anda sudah pernah menggunakan kode ini.' };
    }

    const user = getUser(userId);
    let rewardMessage = '';

    if (codeData.type === 'premium') {
        user.is_premium = true;
        const now = new Date();
        const currentExpiry = user.premium_expires ? new Date(user.premium_expires) : now;
        const newExpiry = new Date(Math.max(now, currentExpiry));
        newExpiry.setDate(newExpiry.getDate() + codeData.value);
        user.premium_expires = newExpiry.toISOString();
        user.gacha_limit = config.GACHA_SETTINGS.PREMIUM_LIMIT;
        rewardMessage = `Selamat! Anda berhasil mendapatkan ${codeData.value} hari Premium.`;
    } else if (codeData.type === 'bonus') {
        user.bonus_gacha += codeData.value;
        rewardMessage = `Selamat! Anda berhasil mendapatkan ${codeData.value} bonus gacha.`;
    }

    codeData.used_by.push(userId);
    saveUsers(`User ${userId} redeemed code`);
    saveRedeemCodes(`Code ${code} used`);
    
    return { success: true, message: rewardMessage };
}


/**
 * Processes a new user referral.
 * @param {object} newUser The new user object.
 * @param {number} referrerId The ID of the user who referred them.
 */
export function processReferral(newUser, referrerId) {
    if (newUser.id === referrerId || newUser.invited_by) return;

    const referrer = usersCache[referrerId];
    if (!referrer) return;

    newUser.invited_by = referrerId;
    
    const bonus = 5; // 5 bonus gacha for both
    referrer.bonus_gacha += bonus;
    referrer.referrals = (referrer.referrals || 0) + 1;
    newUser.bonus_gacha += bonus;

    saveUsers(`Referral processed for new user ${newUser.id} by ${referrerId}`);
}

export { usersCache, saveUsers, saveRedeemCodes };
