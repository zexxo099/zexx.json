import { getFileContent, createOrUpdateFile } from '../utils/github.js';
import { config } from '../config.js';

let gachaPool = [];

/**
 * Loads the gacha item pool from GitHub.
 */
export async function loadGachaPool() {
    console.log('[GACHA] Loading gacha pool from GitHub...');
    const poolData = await getFileContent(config.DATA_FILES.GACHA_POOL);
    gachaPool = Array.isArray(poolData) ? poolData : [];
    console.log(`[GACHA] Loaded ${gachaPool.length} items into the pool.`);
}

/**
 * Saves the current gacha pool to GitHub.
 */
async function saveGachaPool() {
    await createOrUpdateFile(config.DATA_FILES.GACHA_POOL, gachaPool, '[BOT] Update gacha pool');
}

/**
 * Performs a gacha roll based on configured weights.
 * @param {object} user The user object, used for the pity system.
 * @returns {object} The rolled gacha item.
 */
export function rollGacha(user) {
    if (gachaPool.length === 0) {
        throw new Error("Gacha pool is empty. Please add items first.");
    }
    
    // Pity System: If user hits the threshold, guarantee a non-common item
    if (user.pity_counter >= config.GACHA_SETTINGS.PITY_THRESHOLD) {
        const rareOrLegendaryPool = gachaPool.filter(item => item.rarity !== 'common');
        if (rareOrLegendaryPool.length > 0) {
            user.pity_counter = 0; // Reset pity
            return rareOrLegendaryPool[Math.floor(Math.random() * rareOrLegendaryPool.length)];
        }
    }

    const totalWeight = Object.values(config.GACHA_SETTINGS.WEIGHTS).reduce((sum, weight) => sum + weight, 0);
    let random = Math.random() * totalWeight;

    let selectedRarity = 'common';
    for (const rarity in config.GACHA_SETTINGS.WEIGHTS) {
        random -= config.GACHA_SETTINGS.WEIGHTS[rarity];
        if (random < 0) {
            selectedRarity = rarity;
            break;
        }
    }

    const availableItems = gachaPool.filter(item => item.rarity === selectedRarity);
    if (availableItems.length === 0) {
        // Fallback to any item if a rarity pool is empty
        return gachaPool[Math.floor(Math.random() * gachaPool.length)];
    }
    
    const result = availableItems[Math.floor(Math.random() * availableItems.length)];

    // Update pity counter
    if (result.rarity === 'common') {
        user.pity_counter++;
    } else {
        user.pity_counter = 0;
    }
    
    return result;
}

/**
 * Adds a new item to the gacha pool.
 * @param {object} item The item to add.
 * @returns {Promise<void>}
 */
export async function addItem(item) {
    gachaPool.push(item);
    await saveGachaPool();
}

/**
 * Deletes an item from the gacha pool by its name (case-insensitive).
 * @param {string} itemName The name of the item to delete.
 * @returns {Promise<string>} A message indicating the result.
 */
export async function deleteItem(itemName) {
    const initialLength = gachaPool.length;
    gachaPool = gachaPool.filter(item => item.name.toLowerCase() !== itemName.toLowerCase());
    
    if (gachaPool.length < initialLength) {
        await saveGachaPool();
        return `Item "${itemName}" berhasil dihapus.`;
    } else {
        return `Item "${itemName}" tidak ditemukan di pool.`;
    }
}

/**
 * Retrieves the full gacha pool.
 * @returns {Array} The gacha pool array.
 */
export function getGachaPool() {
    return gachaPool;
}
