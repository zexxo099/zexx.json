import { Telegraf } from 'telegraf';
import LocalSession from 'telegraf-session-local';
import { config } from './config.js';
import { loadAllData } from './services/userService.js';
import { loadGachaPool } from './services/gachaService.js';
import { registerUserHandlers } from './handlers/userHandlers.js';

console.log(`[SYS] Initializing ${config.BOT_NAME} v${config.BOT_VERSION}...`);

if (!config.TELEGRAM_TOKEN) {
    console.error("[FATAL] TELEGRAM_TOKEN is not defined in the .env file. Exiting.");
    process.exit(1);
}

const bot = new Telegraf(config.TELEGRAM_TOKEN);
const localSession = new LocalSession({ database: 'session_db.json' });

// Hapus bot.use(session());
bot.use(localSession.middleware());

bot.catch((err, ctx) => {
    console.error(`[ERROR] Unhandled error for ${ctx.updateType}`, err);
    ctx.reply('❌ Maaf, terjadi kesalahan internal. Saya sudah memberitahu developer.').catch(e => console.error("Failed to send error message to user:", e));
});

async function launch() {
    try {
           await Promise.all([
            loadAllData(),
            loadGachaPool()
        ]);

        registerUserHandlers(bot);
        
        await bot.telegram.setMyCommands([
            { command: 'start', description: '🚀 lihat menu utama' },
            { command: 'gacha', description: '🎰 gacha premium' },
            { command: 'mystats', description: '📊 statistik you profile' },
            { command: 'history', description: '📜 riwayat gacha' },
            { command: 'daily', description: '🎁 klaim bonus' },
            { command: 'redeem', description: '🎟️ rendem kode' },
            { command: 'contact', description: '👨‍💻 hubungin developer script' },
            { command: 'admin', description: '👑 buat admin script' },
        ]);

        // Luncurkan bot
        bot.launch(() => {
            console.log(`[SUCCESS] ${config.BOT_NAME} is now online as @${config.BOT_USERNAME}!`);
        });

    } catch (error) {
        console.error('[FATAL] Bot failed to launch:', error);
        process.exit(1);
    }
}

launch();

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
