import { Markup } from 'telegraf';
import { config, EMOJI } from '../config.js';
import { keyboards, formatBox, animateMessage } from '../utils/helpers.js';
import { getUser, saveUsers, redeemCode, processReferral, usersCache, findUserByUsername, generateRedeemCode } from '../services/userService.js';
import { rollGacha, addItem, deleteItem, loadGachaPool } from '../services/gachaService.js';
import { getPaymentMethods, createTransaction } from '../utils/tripay.js';
import { uploadFile } from '../utils/github.js';
import fetch from 'node-fetch';

// Middleware Sederhana untuk memeriksa Admin
const isAdmin = (ctx) => String(ctx.from?.id) === config.ADMIN_ID;
const adminOnly = (ctx, next) => {
    if (isAdmin(ctx)) {
        return next();
    }
};

// Fungsi Pembantu untuk Upload File Universal
async function handleFileUpload(ctx, itemData) {
    const file = ctx.message.document || ctx.message.photo?.[ctx.message.photo.length - 1] || ctx.message.audio || ctx.message.video;
    if (!file) {
        throw new Error("Tipe file tidak didukung atau tidak ada file terdeteksi.");
    }

    const fileId = file.file_id;
    const fileName = ctx.message.document?.file_name || `${Date.now()}_upload`; // Gunakan nama file jika ada
    const remotePath = `${config.DATA_FILES.GACHA_UPLOADS}${fileName}`;

    const progressMsg = await ctx.reply('Mengupload file ke GitHub...');
    
    try {
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await fetch(fileLink.href);
        const buffer = await response.buffer();
        
        const result = await uploadFile(buffer, remotePath);

        itemData.type = 'file';
        itemData.content = result.download_url;
        await addItem(itemData);
        await loadGachaPool();
        
        await ctx.telegram.editMessageText(ctx.chat.id, progressMsg.message_id, null, `${EMOJI.success} File berhasil diupload dan item **${itemData.name}** ditambahkan!`);
    } catch (e) {
        await ctx.telegram.editMessageText(ctx.chat.id, progressMsg.message_id, null, `${EMOJI.error} Gagal mengupload file: ${e.message}`);
    }
}

export function registerUserHandlers(bot) {

    // COMMAND: /start
    bot.start(async (ctx) => {
        const startPayload = ctx.startPayload;
        const user = getUser(ctx.from.id, ctx.from.username);
        
        // Handle referral
        if (startPayload && startPayload.startsWith('ref_')) {
            const referrerId = startPayload.split('_')[1];
            if (referrerId !== String(user.id)) {
                processReferral(user, referrerId);
                ctx.reply(`${EMOJI.success} Anda dirujuk oleh teman dan kalian berdua mendapatkan bonus 5 gacha!`);
            }
        }

        const remainingLimit = Math.max(0, user.gacha_limit - user.gacha_count);
        const infoContent = `PENGGUNA: @${user.username || 'N/A'}\nSTATUS  : ${user.is_premium ? 'Premium ✨' : 'Regular'}\nLIMIT   : ${remainingLimit}x\nBONUS   : ${user.bonus_gacha}x`;
        const box = formatBox(`${config.BOT_NAME} v${config.BOT_VERSION}`, infoContent);
        
        let welcomeMessage = `Selamat datang di **${config.BOT_NAME}**.\n${box}\nSilakan pilih menu di bawah.`;
        
        // Cek Admin dan tampilkan menu Admin
        let replyMarkup = keyboards.main;
        if (isAdmin(ctx)) {
            welcomeMessage += `\n\n${EMOJI.admin} *Anda adalah Admin*. Gunakan /admin untuk panel kontrol khusus.`;
        }

        await ctx.replyWithMarkdown(welcomeMessage, replyMarkup);
    });
    
    // COMMAND: /admin (Handler Admin)
    bot.command('admin', adminOnly, (ctx) => {
        ctx.replyWithMarkdown(`${EMOJI.admin} **Selamat Datang di Panel Admin**\n\nSilakan pilih salah satu opsi di bawah.`, keyboards.admin);
    });
    
    // CALLBACK QUERY ROUTER (Gabungan User dan Admin)
    bot.on('callback_query', async (ctx) => {
        const action = ctx.callbackQuery.data;
        const [category, command] = action.split(':');
        
        // --- LOGIKA CALLBACK ADMIN (Hanya diproses jika Admin) ---
        if (isAdmin(ctx)) {
             
            // WIZARD CALLBACK HANDLER (untuk gen_code)
            if (action.startsWith('admin_wiz:') && ctx.session.wizard) {
                 ctx.answerCbQuery();
                 const wizard = ctx.session.wizard;
                 const command = action.split(':')[1];
                 
                 if (wizard.step === 'code_type') {
                     wizard.data = { type: command };
                     wizard.step = 'code_value';
                     const prompt = command === 'premium' ? 'Masukkan durasi premium (dalam hari):' : 'Masukkan jumlah bonus gacha:';
                     await ctx.editMessageText(`**[2/3]** ${prompt}`);
                     return; 
                 }
            }

            // ADMIN CALLBACK ROUTER
            if (category === 'admin') {
                ctx.answerCbQuery();
                
                switch (command) {
                    case 'broadcast':
                        ctx.session.awaiting_broadcast = true;
                        await ctx.reply('Silakan ketik pesan yang ingin di-broadcast ke semua pengguna. Gunakan /cancel untuk membatalkan.');
                        break;
                    case 'user_info':
                        ctx.session.awaiting_user_query = true;
                        await ctx.reply('Masukkan ID atau @username pengguna yang ingin Anda cek.');
                        break;
                    case 'add_item':
                        ctx.session.wizard = { step: 'name' };
                        await ctx.reply('**[1/4]** Masukkan nama untuk item gacha baru:');
                        break;
                    case 'del_item':
                        ctx.session.wizard = { step: 'delete_name' };
                        await ctx.reply('Masukkan nama item yang ingin dihapus (case-insensitive):');
                        break;
                    case 'gen_code':
                         ctx.session.wizard = { step: 'code_type' };
                         const typeKeyboard = Markup.inlineKeyboard([
                             Markup.button.callback('Premium', 'admin_wiz:premium'),
                             Markup.button.callback('Bonus Gacha', 'admin_wiz:bonus'),
                         ]);
                         await ctx.reply('**[1/3]** Pilih tipe kode redeem:', typeKeyboard);
                         break;
                    case 'reload':
                         await ctx.reply('Memuat ulang data dari GitHub...');
                         await loadGachaPool();
                         await ctx.reply(`${EMOJI.success} Semua data berhasil dimuat ulang!`);
                         break;
                }
                return; // Hentikan eksekusi jika itu adalah aksi Admin
            }
        }
        // --- END LOGIKA CALLBACK ADMIN ---

        // Logika Callback USER
        const msg = await ctx.replyWithMarkdown(`\`${EMOJI.loading[0]}\` Memproses...`);
        await animateMessage(ctx, msg.message_id, 'Memulai permintaan Anda...');

        try {
            switch (category) {
                case 'gacha':
                    await handleGachaRoll(ctx, msg.message_id);
                    break;
                case 'user':
                    if (command === 'stats') await handleMyStats(ctx, msg.message_id);
                    if (command === 'history') await handleHistory(ctx, msg.message_id);
                    if (command === 'daily') await handleDailyClaim(ctx, msg.message_id);
                    if (command === 'redeem') {
                        ctx.session.awaiting_redeem_code = true;
                        await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, `${EMOJI.code} Silakan kirim kode redeem Anda.`);
                    }
                    if (command === 'contact') {
                         // Menggunakan kontak developer yang lebih bersih
                         const devInfo = `Untuk bantuan, saran, atau laporan bug, silakan hubungi developer: **${config.DEV_CONTACT}**`;
                         await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, devInfo, { parse_mode: 'Markdown'});
                    }
                    break;
                case 'premium':
                    if (command === 'buy') await handleBuyPremium(ctx, msg.message_id);
                    break;
                case 'tripay':
                    await handleTripaySelection(ctx, msg.message_id, command);
                    break;
            }
        } catch (error) {
            console.error(`Error in user callback handler: ${error}`);
            await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, `${EMOJI.error} Terjadi kesalahan: ${error.message}`);
        }
    });

    // TEXT & DOCUMENT HANDLER (Gabungan untuk Redeem Code dan Admin Wizards)
    bot.on(['text', 'document', 'photo', 'audio', 'video'], async (ctx) => {
        
        const messageIsText = ctx.message.text;

        // --- LOGIKA ADMIN WIZARDS & Broadcast (Hanya diproses jika Admin) ---
        if (isAdmin(ctx)) {
            
            // Cancel logic
            if (messageIsText === '/cancel') {
                ctx.session = {};
                return ctx.reply('Operasi dibatalkan.');
            }

            // Broadcast Handler
            if (ctx.session.awaiting_broadcast) {
                // ... (Logika broadcast) ...
                const message = ctx.message.text;
                delete ctx.session.awaiting_broadcast;
                
                await ctx.reply(`Mengirim broadcast ke ${Object.keys(usersCache).length} pengguna... Ini mungkin memakan waktu.`);
                let successCount = 0;
                let failureCount = 0;
                
                for (const userId in usersCache) {
                    try {
                        if (String(userId) !== String(config.BOT_ID)) { 
                            await bot.telegram.sendMessage(userId, message);
                            successCount++;
                        }
                    } catch (e) {
                        failureCount++;
                    }
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
                await ctx.reply(`${EMOJI.success} Broadcast selesai!\nBerhasil: ${successCount}\nGagal: ${failureCount}`);
                return;
            }

            // User Info Handler
            if (ctx.session.awaiting_user_query) {
                 const query = messageIsText.trim();
                 delete ctx.session.awaiting_user_query;
                 const user = usersCache[query] || findUserByUsername(query);
                 
                 if (!user) return ctx.reply('Pengguna tidak ditemukan.');
                 
                 const stats = JSON.stringify(user, null, 2);
                 const userIdentifier = user.username ? `@${user.username}` : user.id;
                 await ctx.replyWithMarkdown(`**Data Pengguna: ${userIdentifier}**\n\`\`\`json\n${stats}\n\`\`\``);
                 return;
            }

            // Wizard Handler
            if (ctx.session.wizard) {
                const wizard = ctx.session.wizard;
                
                // Add Item Wizard
                if (wizard.step === 'name' && messageIsText) {
                    wizard.data = { name: messageIsText };
                    wizard.step = 'rarity';
                    await ctx.reply('**[2/4]** Masukkan rarity (common, rare, legendary):');
                } else if (wizard.step === 'rarity' && messageIsText) {
                    const rarity = messageIsText.toLowerCase();
                    if (!['common', 'rare', 'legendary'].includes(rarity)) return ctx.reply('Rarity tidak valid. Coba lagi.');
                    wizard.data.rarity = rarity;
                    wizard.step = 'type_or_file';
                    await ctx.reply('**[3/4]** Masukkan tipe item (text, script) atau kirim **FILE/GAMBAR/AUDIO** untuk diupload:');
                } else if (wizard.step === 'type_or_file') {
                    if (ctx.message.document || ctx.message.photo || ctx.message.audio || ctx.message.video) { // File upload
                        await handleFileUpload(ctx, wizard.data);
                        delete ctx.session.wizard;
                    } else if (messageIsText) {
                        const type = messageIsText.toLowerCase();
                        if (!['text', 'script'].includes(type)) return ctx.reply('Tipe tidak valid. Coba lagi.');
                        wizard.data.type = type;
                        wizard.step = 'content';
                        await ctx.reply(`**[4/4]** Masukkan konten untuk item ${type} ini:`);
                    }
                } else if (wizard.step === 'content' && messageIsText) {
                    wizard.data.content = messageIsText;
                    await addItem(wizard.data);
                    await loadGachaPool();
                    await ctx.reply(`${EMOJI.success} Item **${wizard.data.name}** berhasil ditambahkan!`);
                    delete ctx.session.wizard;
                }
                
                // Delete Item Wizard
                else if (wizard.step === 'delete_name' && messageIsText) {
                     const itemName = messageIsText.trim();
                     const result = await deleteItem(itemName);
                     await loadGachaPool();
                     await ctx.reply(result);
                     delete ctx.session.wizard;
                }

                // Generate Code Wizard 
                else if (wizard.step === 'code_value' && messageIsText) {
                    const value = parseInt(messageIsText);
                    if (isNaN(value) || value <= 0) return ctx.reply('Nilai tidak valid.');
                    wizard.data.value = value;
                    wizard.step = 'code_uses';
                    await ctx.reply('**[3/3]** Masukkan jumlah maksimal pemakaian:');
                } else if (wizard.step === 'code_uses' && messageIsText) {
                     const uses = parseInt(messageIsText);
                     if (isNaN(uses) || uses <= 0) return ctx.reply('Jumlah tidak valid.');
                     const code = generateRedeemCode(wizard.data.type, wizard.data.value, uses);
                     await ctx.replyWithMarkdown(`${EMOJI.success} Kode berhasil dibuat!\n\n\`${code}\`\n\nTipe: ${wizard.data.type}\nValue: ${wizard.data.value}\nUses: ${uses}`);
                     delete ctx.session.wizard;
                }
                
                // Hentikan eksekusi jika Admin sedang dalam wizard
                return;
            }
        }
        // --- END LOGIKA ADMIN WIZARDS ---

        // Logika Redeem Code (Hanya jika pesan adalah teks)
        if (ctx.session.awaiting_redeem_code && messageIsText) {
            const code = messageIsText.trim();
            const result = redeemCode(ctx.from.id, code);
            
            await ctx.reply(`${result.success ? EMOJI.success : EMOJI.error} ${result.message}`);
            
            delete ctx.session.awaiting_redeem_code;
            if (result.success) {
                 await ctx.reply('Statistik Anda telah diperbarui!', keyboards.main);
            }
            return;
        }
    });
}

// Action Handlers
async function handleGachaRoll(ctx, messageId) {
    const user = getUser(ctx.from.id);
    const availableGacha = (user.gacha_limit - user.gacha_count) + user.bonus_gacha;

    if (availableGacha <= 0) {
        return ctx.telegram.editMessageText(ctx.chat.id, messageId, null, `${EMOJI.error} Gacha limit Anda hari ini sudah habis. Kembali besok atau beli premium untuk limit lebih banyak!`);
    }

    const result = rollGacha(user);
    
    user.total_gacha_lifetime += 1;
    if (user.bonus_gacha > 0) {
        user.bonus_gacha -= 1;
    } else {
        user.gacha_count += 1;
    }

    let message = `${EMOJI.star} **GACHA BERHASIL!** ${EMOJI.star}\n\nAnda mendapatkan:\nItem: **${result.name}**\nRarity: **${result.rarity.toUpperCase()}**`;
    if (result.rarity === 'rare' || result.rarity === 'legendary') {
        user.rare_drops_count += 1;
        message += `\n\n**✨ RARE DROP!** Anda sangat beruntung!`;
    }
    
    if (result.type === 'file' || result.type === 'script') {
        message += `\nLink: [DOWNLOAD](${result.content})`;
    } else {
        message += `\nKonten: \`${result.content}\``;
    }

    user.gacha_history.push({ name: result.name, rarity: result.rarity, date: new Date().toISOString() });
    if (user.gacha_history.length > 50) user.gacha_history.shift();

    await saveUsers(`Gacha by ${user.id}`);
    const remaining = (user.gacha_limit - user.gacha_count) + user.bonus_gacha;
    message += `\n\nSisa Gacha: \`${Math.max(0, remaining)}\`x`;

    await ctx.telegram.editMessageText(ctx.chat.id, messageId, null, message, { parse_mode: 'Markdown', reply_markup: keyboards.main.reply_markup, disable_web_page_preview: true });
}

async function handleMyStats(ctx, messageId) {
    const user = getUser(ctx.from.id);
    const premiumStatus = user.is_premium
        ? `${EMOJI.star} Premium (Aktif hingga: ${new Date(user.premium_expires).toLocaleDateString('id-ID')})`
        : 'Regular';
    
    const referralLink = `https://t.me/${config.BOT_USERNAME}?start=ref_${user.id}`;

    let message = `
${EMOJI.stat} **STATISTIK ANDA**
ID: \`${user.id}\`
Username: @${user.username || 'N/A'}
Status: **${premiumStatus}**

--- **Gacha** ---
Limit Harian: ${Math.max(0, user.gacha_limit - user.gacha_count)}/${user.gacha_limit}
Bonus Gacha: ${user.bonus_gacha}x
Total Gacha Seumur Hidup: ${user.total_gacha_lifetime}x
Rare/Legendary Drops: ${user.rare_drops_count}x
Pity Counter: ${user.pity_counter}/${config.GACHA_SETTINGS.PITY_THRESHOLD}

--- **Referral** ---
Total Undangan: ${user.referrals || 0}
Link Undangan Anda: \`${referralLink}\`
    `;
    await ctx.telegram.editMessageText(ctx.chat.id, messageId, null, message, { parse_mode: 'Markdown', reply_markup: keyboards.main.reply_markup, disable_web_page_preview: true });
}

async function handleHistory(ctx, messageId) {
    const user = getUser(ctx.from.id);
    if (!user.gacha_history || user.gacha_history.length === 0) {
        return ctx.telegram.editMessageText(ctx.chat.id, messageId, null, `${EMOJI.history} Anda belum pernah melakukan gacha.`);
    }
    let message = `${EMOJI.history} **Riwayat Gacha (15 Terbaru)**\n\n`;
    user.gacha_history.slice(-15).reverse().forEach((item, index) => {
        const date = new Date(item.date).toLocaleString('id-ID');
        message += `\`${index + 1}.\` [${item.rarity.toUpperCase()}] **${item.name}** - _${date}_\n`;
    });
    await ctx.telegram.editMessageText(ctx.chat.id, messageId, null, message, { parse_mode: 'Markdown', reply_markup: keyboards.main.reply_markup });
}

async function handleDailyClaim(ctx, messageId) {
    const user = getUser(ctx.from.id);
    const today = new Date().toISOString().split('T')[0];

    // Cek apakah sudah klaim hari ini
    if (user.last_daily_claim === today) {
        return ctx.telegram.editMessageText(ctx.chat.id, messageId, null, `${EMOJI.error} Anda sudah mengklaim bonus harian hari ini. Kembali lagi besok!`);
    }

    const bonusAmount = 2; // Jumlah bonus gacha
    user.bonus_gacha += bonusAmount;
    user.last_daily_claim = today;
    await saveUsers(`Daily claim by ${user.id}`); // Simpan perubahan

    // Pesan konfirmasi yang lebih rapi
    await ctx.telegram.editMessageText(ctx.chat.id, messageId, null, 
        `${EMOJI.gift} **Klaim Harian Berhasil!**\n\nAnda mendapatkan **${bonusAmount}x gacha tambahan**!\nTotal Bonus Gacha Anda sekarang: \`${user.bonus_gacha}x\``, 
        { parse_mode: 'Markdown', reply_markup: keyboards.main.reply_markup }
    );
}

async function handleBuyPremium(ctx, messageId) {
    const user = getUser(ctx.from.id);
    if (user.is_premium) {
        return ctx.telegram.editMessageText(ctx.chat.id, messageId, null, `${EMOJI.success} Anda sudah menjadi pengguna Premium!`);
    }

    const methods = await getPaymentMethods();
    if (!methods || methods.length === 0) {
        return ctx.telegram.editMessageText(ctx.chat.id, messageId, null, `${EMOJI.error} Maaf, metode pembayaran sedang tidak tersedia.`);
    }

    const keyboard = methods.map(method => Markup.button.callback(method.name, `tripay:${method.code}`));
    const rows = [];
    while (keyboard.length > 0) rows.push(keyboard.splice(0, 2));

    const message = `${EMOJI.money} **PEMBELIAN PREMIUM**
Harga: **Rp ${config.PREMIUM_PRICE.toLocaleString('id-ID')}** untuk **${config.PREMIUM_DURATION_DAYS} hari**.

Keuntungan Premium:
- Limit gacha harian menjadi **${config.GACHA_SETTINGS.PREMIUM_LIMIT}x**
- Akses ke item gacha eksklusif (jika ada)
- Badge premium di profil

Silakan pilih metode pembayaran:`;
    await ctx.telegram.editMessageText(ctx.chat.id, messageId, null, message, { parse_mode: 'Markdown', reply_markup: Markup.inlineKeyboard(rows).reply_markup });
}

async function handleTripaySelection(ctx, messageId, methodCode) {
    const userId = ctx.from.id;
    const user = getUser(userId, ctx.from.username);
    
    try {
        const transaction = await createTransaction({
            amount: config.PREMIUM_PRICE,
            method: methodCode,
            email: `${userId}@xvct.bot`,
            phone: '081234567890', // Placeholder
            reference: `XVCT-${userId}-${Date.now()}`,
            name: user.username || `User ${userId}`
        });

        const instructions = transaction.instructions.map(inst => `*${inst.title}*\n${inst.steps.join('\n')}`).join('\n\n');
        const message = `
${EMOJI.money} **DETAIL PEMBAYARAN**
Metode: *${transaction.payment_name}*
Total Bayar: *Rp ${transaction.amount.toLocaleString('id-ID')}*
Kode Bayar/VA: \`${transaction.pay_code}\`
Batas Waktu: *${new Date(transaction.expired_time * 1000).toLocaleString('id-ID')}*

---
**INSTRUKSI**
${instructions}
---

_Harap selesaikan pembayaran sebelum batas waktu. Bot akan otomatis mengupdate status premium Anda setelah pembayaran berhasil._`;

        await ctx.telegram.editMessageText(ctx.chat.id, messageId, null, message, { parse_mode: 'Markdown' });
    } catch (e) {
        await ctx.telegram.editMessageText(ctx.chat.id, messageId, null, `${EMOJI.error} Gagal membuat transaksi: ${e.message}`);
    }
}
