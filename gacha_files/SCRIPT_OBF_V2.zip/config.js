// config.js
module.exports = {
    BOT_TOKEN: "8151057274:AAFeMDXH_cMcbNmqoreLz_vLKu_cbE4jtBI", 
    ADMIN_ID: 7112830272  
};