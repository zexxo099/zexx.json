import fetch from 'node-fetch';
import crypto from 'crypto';
import { config } from '../config.js';

const TRIPAY_BASE_URL = 'https://tripay.co.id/api-sandbox'; // Use 'api' for production

/**
 * Generates the required signature for Tripay API calls.
 * @param {string} merchantRef The unique reference for the transaction.
 * @param {number} amount The transaction amount.
 * @returns {string} The SHA256 signature.
 */
function generateSignature(merchantRef, amount) {
    const data = `${config.TRIPAY_MERCHANT_CODE}${merchantRef}${amount}${config.TRIPAY_PRIVATE_KEY}`;
    return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Fetches active payment methods from Tripay.
 * @returns {Promise<Array|null>} A list of payment methods or null on failure.
 */
export async function getPaymentMethods() {
    try {
        const response = await fetch(`${TRIPAY_BASE_URL}/merchant/payment-channel`, {
            headers: { 'Authorization': `Bearer ${config.TRIPAY_API_KEY}` }
        });
        if (!response.ok) return null;
        const data = await response.json();
        return data.data.filter(method => method.active);
    } catch (error) {
        console.error("Tripay payment methods error:", error);
        return null;
    }
}

/**
 * Creates a new payment transaction with Tripay.
 * @param {object} details - The transaction details.
 * @param {number} details.amount - The amount.
 * @param {string} details.method - The payment method code.
 * @param {string} details.email - Customer email.
 * @param {string} details.phone - Customer phone.
 * @param {string} details.reference - The unique merchant reference.
 * @param {string} details.name - The customer name.
 * @returns {Promise<object>} The transaction data from Tripay.
 */
export async function createTransaction({ amount, method, email, phone, reference, name }) {
    const signature = generateSignature(reference, amount);
    const body = {
        method: method,
        merchant_ref: reference,
        amount: amount,
        customer_name: name,
        customer_email: email,
        customer_phone: phone,
        order_items: [{
            name: `Aktivasi Premium ${config.BOT_NAME} (${config.PREMIUM_DURATION_DAYS} Hari)`,
            price: amount,
            quantity: 1
        }],
        expired_time: Math.floor((Date.now() / 1000) + (24 * 60 * 60)), // 24 hours expiry
        signature: signature
    };

    const response = await fetch(`${TRIPAY_BASE_URL}/transaction/create`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${config.TRIPAY_API_KEY}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
    });
    
    const data = await response.json();
    if (!response.ok || !data.success) {
        throw new Error(data.message || 'Failed to create Tripay transaction.');
    }
    return data.data;
}
