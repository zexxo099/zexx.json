require("./system/module.js")

//==============================================//
global.owner = "6282186731670"
global.namabot = "𝘐𝘕𝘚𝘛𝘈𝘓𝘓𝘗𝘈𝘕𝘌𝘓" 
global.versi = "1.0.0"
global.namaOwner = "𝘚𝘠𝘈𝘏"
global.namaowner = "𝘚𝘠𝘈𝘏"
global.packname = "𝘚𝘠𝘈𝘏"
global.author = "𝘚𝘠𝘈𝘏"
global.botname = "𝘐𝘕𝘚𝘛𝘈𝘓𝘓𝘗𝘈𝘕𝘌𝘓"
global.botname2 = "𝘐𝘕𝘚𝘛𝘈𝘓𝘓𝘗𝘈𝘕𝘌𝘓"
global.thumbbot = "https://files.catbox.moe/5p42ps.jpg"
global.urlfoto = 'https://files.catbox.moe/5p42ps.jpg'

global.image = {
reply: "https://files.catbox.moe/d11c1y.jpeg", 
menu: "https://files.catbox.moe/d11c1y.jpeg", 
qris: "https://files.catbox.moe/jwbuae.jpg",   
};
//==============================================//
//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "085883796028"
global.gopay = "085883796028"
global.ovo = "08388907868"
global.linksaluran = "https://whatsapp.com/channel/0029VbBDuLFEKyZQFWVOtd24"
global.linkweb = "-"

global.idsaluran = "120363400565794836@newsletter"
global.namasaluran = "SYAHV2DOFFC"
global.channel = "https://whatsapp.com/channel/0029VbBDuLFEKyZQFWVOtd24"
global.linkgrub = "",
//======================
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "-"
global.apikey = "-" //ptla
global.capikey = "-"
//======================
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain2 = "-"
global.apikey2 = "-" //ptla
global.capikey2 = "-"
//======================
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain3 = "-"
global.apikey3 = "-" //ptla
global.capikey3 = "-"
//======================
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain4 = "-"
global.apikey4 = "-" //ptla
global.capikey4 = "-"
//======================
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain5 = "-"
global.apikey5 = "-" //ptla
global.capikey5 = "-"
//==============================================//


global.mess = {
wait: "Memproses . . .", 
prem: "❌ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜 𝗧𝗢𝗟𝗔𝗞\nFitur ini khusus premium‼️",
owner: "❌ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜 𝗧𝗢𝗟𝗔𝗞\nFitur ini khusus owner‼️",
group: "❌ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜 𝗧𝗢𝗟𝗔𝗞\n Fitur ini hanya bisa digunakan di dalam *Grup*!",
admin: "❌ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜 𝗧𝗢𝗟𝗔𝗞\nFitur ini hanya bisa digunakan oleh *Admin Grup*!",
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})