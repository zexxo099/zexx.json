module.exports = {
  botToken: "TOKEN_ELU",
  vercelToken: "TOKEN_VERCEL_KAMU_BEB",
  groupName: "@roompublicJianOffc",
  groupLink: "https://t.me/roompublicJianOffc",
  channelName: "@informationJianOffc"
};